import SwiftUI

/// Busca nuevas versiones de AZASing en las Releases de GitHub y se actualiza a sí misma:
/// descarga el IPA, lo firma con el certificado elegido (mismo Bundle ID) y lo instala.
@MainActor
final class UpdateManager: ObservableObject {
    struct Release: Equatable {
        var tag: String
        var build: Int
        var notes: String
        var browserURL: URL
        var apiURL: URL?
    }

    @Published var available: Release?
    @Published var busy = false
    @Published var state = ""
    @Published var lastMessage: String?

    static var currentBuild: Int { Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "") ?? 0 }
    static var currentVersion: String {
        let v = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        return "\(v) (\(currentBuild))"
    }
    static var repo: String { UserDefaults.standard.string(forKey: "updateRepo") ?? "Zepeda27/Singaza" }
    static var token: String { Keychain.get("updateToken") ?? "" }

    private var lastCheck = Date.distantPast

    private func request(_ url: URL, octet: Bool = false) -> URLRequest {
        var r = URLRequest(url: url)
        r.timeoutInterval = 60
        r.setValue(octet ? "application/octet-stream" : "application/vnd.github+json", forHTTPHeaderField: "Accept")
        r.setValue("AZASing", forHTTPHeaderField: "User-Agent")
        if !Self.token.isEmpty { r.setValue("Bearer \(Self.token)", forHTTPHeaderField: "Authorization") }
        return r
    }

    /// `force` = botón manual: informa del resultado. Si no, comprueba como mucho cada 30 minutos.
    func check(force: Bool = false) async {
        if !force && Date().timeIntervalSince(lastCheck) < 1800 { return }
        lastCheck = Date()
        guard let url = URL(string: "https://api.github.com/repos/\(Self.repo)/releases/latest") else { return }
        do {
            let (data, resp) = try await URLSession.shared.data(for: request(url))
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            guard code == 200 else {
                if force { lastMessage = code == 404 ? "No encontré versiones publicadas en \(Self.repo). Si el repositorio es privado, añade un token." : "GitHub respondió con el código \(code)." }
                return
            }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let tag = json["tag_name"] as? String,
                  let assets = json["assets"] as? [[String: Any]],
                  let asset = assets.first(where: { ($0["name"] as? String)?.lowercased().hasSuffix(".ipa") == true }),
                  let dl = (asset["browser_download_url"] as? String).flatMap(URL.init(string:)) else {
                if force { lastMessage = "La última versión no trae ningún IPA." }
                return
            }
            let digits = tag.split(whereSeparator: { !$0.isNumber }).last.flatMap { Int($0) } ?? 0
            if digits > Self.currentBuild {
                available = Release(tag: tag, build: digits, notes: (json["body"] as? String) ?? "",
                                    browserURL: dl, apiURL: (asset["url"] as? String).flatMap(URL.init(string:)))
                if force { lastMessage = "Hay una versión nueva: \(tag)." }
            } else {
                available = nil
                if force { lastMessage = "Ya tienes la última versión (\(Self.currentVersion))." }
            }
        } catch {
            if force { lastMessage = "No se pudo comprobar: \(error.localizedDescription)" }
        }
    }

    func install(certs: CertStore) async {
        guard let rel = available, !busy else { return }
        let certID = UserDefaults.standard.string(forKey: "updateCert").flatMap(UUID.init(uuidString:)) ?? certs.defaultID
        guard let cert = certs.items.first(where: { $0.id == certID }) ?? certs.items.first else {
            lastMessage = "Añade un certificado en Ajustes › Certificados para poder actualizar."; return
        }
        if cert.isExpired { lastMessage = "El certificado “\(cert.name)” está caducado. Elige otro en Ajustes › Actualizaciones."; return }
        busy = true
        defer { busy = false; state = "" }
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("update-\(UUID().uuidString)")
        try? fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }
        do {
            state = "Descargando…"
            let useAPI = !Self.token.isEmpty && rel.apiURL != nil
            let (tmp, resp) = try await URLSession.shared.download(for: request(useAPI ? rel.apiURL! : rel.browserURL, octet: useAPI))
            if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) {
                lastMessage = "No se pudo descargar la actualización (código \(h.statusCode))."; return
            }
            let ipa = work.appendingPathComponent("AZASing-update.ipa")
            try fm.moveItem(at: tmp, to: ipa)

            state = "Firmando…"
            let opts = SignOptions(ipa: ipa, cert: cert, tweaks: [], bundleID: "", displayName: "", version: "",
                                   outputName: "AZASing", suffix: "", ext: "ipa")
            let out = work.appendingPathComponent("out")
            try fm.createDirectory(at: out, withIntermediateDirectories: true)
            let signed = try await Signer.run(opts, outputFolder: out) { _ in }

            state = "Instalando…"
            // El instalador necesita el archivo hasta terminar: se copia a un sitio que no se borra al salir.
            let keep = fm.temporaryDirectory.appendingPathComponent("AZASing-update-signed.ipa")
            try? fm.removeItem(at: keep)
            try fm.copyItem(at: signed, to: keep)
            // Al terminar la descarga, iOS ya tiene el IPA: se cierra la app para que se reemplace por la nueva.
            let err = await LocalInstall.run(ipa: keep, afterDownload: {
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 800_000_000)
                    AppCloser.goHomeThenQuit()
                }
            })
            if let err { lastMessage = err }
        } catch {
            lastMessage = "No se pudo actualizar: \(error.localizedDescription)"
        }
    }
}

/// Aviso en la parte de arriba cuando hay una versión nueva.
struct UpdateBanner: View {
    @EnvironmentObject var updater: UpdateManager
    @ObservedObject var certs: CertStore
    @AppStorage("dismissedUpdate") private var dismissed = ""

    var body: some View {
        if let rel = updater.available, dismissed != rel.tag {
            HStack(spacing: 12) {
                Image(systemName: "arrow.down.circle.fill").font(.title2).foregroundColor(.gold)
                VStack(alignment: .leading, spacing: 2) {
                    Text(updater.busy ? updater.state : "Actualización disponible").font(.headline)
                    if updater.busy {
                        Text("No cierres la app.").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 4)
                if updater.busy { ProgressView() }
                else {
                    Button("Actualizar") { Task { await updater.install(certs: certs) } }
                        .buttonStyle(.borderedProminent).tint(.gold).foregroundColor(.black)
                        .font(.footnote.weight(.bold))
                    Button { dismissed = rel.tag } label: { Image(systemName: "xmark").foregroundStyle(.secondary) }
                        .buttonStyle(.plain)
                }
            }
            .padding(14)
            .glassCard(cornerRadius: 22)
            .padding(.horizontal).padding(.top, 6)
            .alert("Actualización", isPresented: Binding(get: { updater.lastMessage != nil }, set: { if !$0 { updater.lastMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(updater.lastMessage ?? "") }
        }
    }

    private func firstLine(_ s: String) -> String {
        let t = s.split(separator: "\n").first.map(String.init) ?? ""
        return t.isEmpty ? "Toca Actualizar para instalarla." : t
    }
}

/// Sección de Ajustes.
struct UpdateSettingsSection: View {
    @EnvironmentObject var updater: UpdateManager
    @ObservedObject var certs: CertStore
    @AppStorage("updateRepo") private var repo = "Zepeda27/Singaza"
    @AppStorage("updateCert") private var certID = ""
    @State private var token = Keychain.get("updateToken") ?? ""

    var body: some View {
        Section("Actualizaciones") {
            LabeledContent("Versión instalada") { Text(UpdateManager.currentVersion).foregroundStyle(.secondary) }
            Button("Buscar actualizaciones") { Task { await updater.check(force: true) } }
            if updater.available != nil {
                Button("Actualizar ahora") { Task { await updater.install(certs: certs) } }.disabled(updater.busy)
            }
        }
    }
}
