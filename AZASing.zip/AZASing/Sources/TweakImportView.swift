import SwiftUI

/// Elegir cualquier archivo o carpeta de Tweaks (png, plist, dylib, framework, bundle, deb…)
/// para importarlo a la carpeta actual. Se puede entrar en las carpetas, como en Archivos.
struct TweakImportView: View {
    var onImport: ([URL]) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var selection = Set<URL>()

    var body: some View {
        NavigationStack {
            TweakFolderList(dir: Folder.tweaks.url, selection: $selection, title: "Tweaks")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { Button("Cancelar") { dismiss() } }
                }
                .safeAreaInset(edge: .bottom) {
                    Button {
                        onImport(Array(selection)); dismiss()
                    } label: { Text(selection.isEmpty ? "Importar" : "Importar (\(selection.count))") }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(selection.isEmpty)
                        .padding(.horizontal).padding(.vertical, 8)
                }
        }
    }
}

struct TweakFolderList: View {
    let dir: URL
    @Binding var selection: Set<URL>
    let title: String
    @State private var items: [URL] = []

    var body: some View {
        List {
            if items.isEmpty {
                Text("Esta carpeta está vacía.").foregroundStyle(.secondary)
            }
            ForEach(items, id: \.self) { u in
                HStack(spacing: 8) {
                    Toggle(isOn: Binding(get: { selection.contains(u) },
                                         set: { on in if on { selection.insert(u) } else { selection.remove(u) } })) {
                        HStack(spacing: 10) {
                            Image(systemName: icon(u)).foregroundColor(.gold).frame(width: 24)
                            Text(u.lastPathComponent).lineLimit(2)
                        }
                    }
                    if isDir(u) {
                        NavigationLink {
                            TweakFolderList(dir: u, selection: $selection, title: u.lastPathComponent)
                        } label: { EmptyView() }
                        .frame(width: 20)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: load)
    }

    private func isDir(_ u: URL) -> Bool {
        (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
    }

    private func icon(_ u: URL) -> String {
        if isDir(u) {
            switch u.pathExtension.lowercased() {
            case "framework": return "shippingbox"
            case "bundle", "app": return "shippingbox.fill"
            default: return "folder"
            }
        }
        switch u.pathExtension.lowercased() {
        case "deb": return "archivebox"
        case "dylib": return "puzzlepiece.extension"
        case "png", "jpg", "jpeg", "heic", "gif", "car": return "photo"
        case "plist", "entitlements", "json", "xml", "strings": return "doc.text"
        default: return "doc"
        }
    }

    private func load() {
        let fm = FileManager.default
        let list = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
        items = list.sorted {
            let a = isDir($0), b = isDir($1)
            if a != b { return a }
            return $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
        }
    }
}
