import SwiftUI

/// Elegir elementos de la carpeta Tweaks para importarlos a la carpeta actual.
struct TweakImportView: View {
    var onImport: ([URL]) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var groups: [(title: String, items: [URL])] = []
    @State private var selection = Set<URL>()

    var body: some View {
        NavigationStack {
            List {
                if groups.isEmpty {
                    Text("La carpeta Tweaks está vacía.").foregroundStyle(.secondary)
                }
                ForEach(groups, id: \.title) { g in
                    Section(g.title) {
                        ForEach(g.items, id: \.self) { u in
                            Toggle(isOn: Binding(get: { selection.contains(u) },
                                                 set: { on in if on { selection.insert(u) } else { selection.remove(u) } })) {
                                HStack(spacing: 10) {
                                    Image(systemName: icon(u)).foregroundColor(.gold)
                                    Text(u.lastPathComponent)
                                }
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Importar desde Tweaks")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Cancelar") { dismiss() } }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    onImport(Array(selection)); dismiss()
                } label: { Text(selection.isEmpty ? "Importar" : "Importar (\(selection.count))") }
                    .buttonStyle(GoldButtonStyle())
                    .disabled(selection.isEmpty)
                    .padding(.horizontal).padding(.vertical, 8)
            }
            .onAppear(perform: load)
        }
    }

    private func icon(_ u: URL) -> String {
        switch u.pathExtension.lowercased() {
        case "deb": return "archivebox"
        case "dylib": return "puzzlepiece.extension"
        case "framework": return "shippingbox"
        default: return "shippingbox.fill"
        }
    }

    private func load() {
        var out: [(String, [URL])] = []
        for f in TweakScanner.folders() {
            let items = TweakScanner.items(in: f)
            if !items.isEmpty { out.append((f.lastPathComponent, items)) }
        }
        let loose = TweakScanner.items(in: Folder.tweaks.url, recursive: false)
        if !loose.isEmpty { out.insert(("Tweaks (sueltos)", loose), at: 0) }
        groups = out
    }
}
