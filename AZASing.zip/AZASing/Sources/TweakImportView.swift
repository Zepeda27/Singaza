import SwiftUI

/// Elegir cualquier archivo o carpeta de Tweaks (png, plist, dylib, framework, bundle, deb…)
/// para importarlo a la carpeta actual. Se puede entrar en las carpetas, como en Archivos.
struct TweakImportView: View {
    var onImport: ([URL]) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var selection = Set<URL>()

    var body: some View {
        NavigationStack {
            TweakFolderList(dir: Folder.tweaks.url, selection: $selection, title: "Tweaks")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { Button("Cancelar") { dismiss() } }
                }
                .safeAreaInset(edge: .bottom) {
                    Button {
                        onImport(Array(selection)); dismiss()
                    } label: { Text(selection.isEmpty ? "Importar" : "Importar (\(selection.count))") }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(selection.isEmpty)
                        .padding(.horizontal).padding(.vertical, 8)
                }
        }
    }
}

struct TweakFolderList: View {
    let dir: URL
    @Binding var selection: Set<URL>
    let title: String
    @State private var items: [URL] = []

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                if items.isEmpty {
                    Text("Esta carpeta está vacía.").foregroundStyle(.secondary).padding(.top, 40)
                }
                ForEach(items, id: \.self) { u in
                    if isDir(u) {
                        HStack(spacing: 14) {
                            Button { toggle(u) } label: { check(u) }.buttonStyle(.plain)
                            NavigationLink {
                                TweakFolderList(dir: u, selection: $selection, title: u.lastPathComponent)
                            } label: {
                                HStack(spacing: 14) {
                                    content(u)
                                    Image(systemName: "chevron.right").foregroundStyle(.secondary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(12).glassCard(cornerRadius: 18)
                    } else {
                        Button { toggle(u) } label: {
                            HStack(spacing: 14) { check(u); content(u) }
                                .padding(12).glassCard(cornerRadius: 18)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal).padding(.vertical, 8)
        }
        .background(AppBackground())
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                let all = !items.isEmpty && items.allSatisfy { selection.contains($0) }
                Button(all ? "Ninguno" : "Todo") {
                    if all { items.forEach { selection.remove($0) } } else { items.forEach { selection.insert($0) } }
                }
                .disabled(items.isEmpty)
            }
        }
        .onAppear(perform: load)
    }

    private func toggle(_ u: URL) {
        if selection.contains(u) { selection.remove(u) } else { selection.insert(u) }
    }

    private func check(_ u: URL) -> some View {
        Image(systemName: selection.contains(u) ? "checkmark.circle.fill" : "circle")
            .font(.title3).foregroundColor(selection.contains(u) ? .gold : .secondary)
    }

    private func content(_ u: URL) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon(u)).font(.title2).foregroundColor(.gold).frame(width: 34)
            VStack(alignment: .leading, spacing: 3) {
                Text(u.lastPathComponent).font(.headline).foregroundStyle(.primary).lineLimit(1)
                Text(subtitle(u)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
    }

    private func subtitle(_ u: URL) -> String {
        if isDir(u) {
            let n = (try? FileManager.default.contentsOfDirectory(atPath: u.path).count) ?? 0
            return "\(n) elementos"
        }
        let size = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        return ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    private func isDir(_ u: URL) -> Bool {
        (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
    }

    private func icon(_ u: URL) -> String {
        if isDir(u) {
            switch u.pathExtension.lowercased() {
            case "framework": return "shippingbox"
            case "bundle", "app": return "shippingbox.fill"
            default: return "folder.fill"
            }
        }
        switch u.pathExtension.lowercased() {
        case "deb": return "archivebox"
        case "dylib": return "puzzlepiece.extension"
        case "png", "jpg", "jpeg", "heic", "gif", "car": return "photo"
        case "plist", "entitlements", "json", "xml", "strings": return "curlybraces.square"
        default: return "doc"
        }
    }

    private func load() {
        let fm = FileManager.default
        let list = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
        items = list.sorted {
            let a = isDir($0), b = isDir($1)
            if a != b { return a }
            return $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
        }
    }
}
