import Foundation
import Network
import Security
import SafariServices
import UIKit

enum ServerError: LocalizedError {
    case noIdentity
    var errorDescription: String? { "No se pudo cargar el certificado del servidor local." }
}

/// Servidor HTTPS en el propio iPhone (solo loopback) que sirve el IPA firmado
/// y su manifest para instalarlo con itms-services. Un segundo puerto HTTP sirve
/// el perfil con la CA local, que se instala una sola vez.
final class LocalServer {
    static let shared = LocalServer()

    private var tlsListener: NWListener?
    private var httpListener: NWListener?
    private(set) var tlsPort: UInt16 = 0
    private(set) var httpPort: UInt16 = 0
    private let queue = DispatchQueue(label: "azasing.localserver")

    private var ipaURL: URL?
    private var manifest = Data()
    var onDownloaded: (() -> Void)?
    private var bgTask: UIBackgroundTaskIdentifier = .invalid

    // MARK: Arranque

    func startIfNeeded() async throws {
        if tlsListener == nil { tlsListener = try await makeListener(tls: true) }
        if httpListener == nil { httpListener = try await makeListener(tls: false) }
        tlsPort = tlsListener?.port?.rawValue ?? 0
        httpPort = httpListener?.port?.rawValue ?? 0
    }

    private func makeListener(tls: Bool) async throws -> NWListener {
        let params: NWParameters
        if tls {
            guard let identity = Self.loadIdentity(), let secID = sec_identity_create(identity) else { throw ServerError.noIdentity }
            let opts = NWProtocolTLS.Options()
            sec_protocol_options_set_local_identity(opts.securityProtocolOptions, secID)
            params = NWParameters(tls: opts)
        } else {
            params = .tcp
        }
        params.requiredInterfaceType = .loopback   // nunca expuesto a la red
        let listener = try NWListener(using: params)
        listener.newConnectionHandler = { [weak self] conn in self?.handle(conn) }
        return try await withCheckedThrowingContinuation { cont in
            var done = false
            listener.stateUpdateHandler = { state in
                guard !done else { return }
                switch state {
                case .ready: done = true; cont.resume(returning: listener)
                case .failed(let e): done = true; cont.resume(throwing: e)
                default: break
                }
            }
            listener.start(queue: queue)
        }
    }

    private static func loadIdentity() -> SecIdentity? {
        guard let url = Bundle.main.url(forResource: "localhost", withExtension: "p12"),
              let data = try? Data(contentsOf: url) else { return nil }
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, [kSecImportExportPassphrase as String: "azasing"] as CFDictionary, &items)
        guard status == errSecSuccess, let arr = items as? [[String: Any]],
              let first = arr.first, let id = first[kSecImportItemIdentity as String] else { return nil }
        return (id as! SecIdentity)
    }

    // MARK: Contenido

    func prepare(ipa: URL, bundleID: String, version: String, name: String) async throws {
        try await startIfNeeded()
        ipaURL = ipa
        let esc: (String) -> String = {
            $0.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
        }
        manifest = Data("""
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0"><dict><key>items</key><array><dict>
        <key>assets</key><array><dict><key>kind</key><string>software-package</string>
        <key>url</key><string>https://localhost:\(tlsPort)/app.ipa</string></dict></array>
        <key>metadata</key><dict>
        <key>bundle-identifier</key><string>\(esc(bundleID))</string>
        <key>bundle-version</key><string>\(esc(version.isEmpty ? "1.0" : version))</string>
        <key>kind</key><string>software</string>
        <key>title</key><string>\(esc(name))</string>
        </dict></dict></array></dict></plist>
        """.utf8)
    }

    /// ¿El iPhone confía en nuestra CA? Hace una petición HTTPS real con la validación normal.
    func isTrusted() async -> Bool {
        guard tlsPort != 0, let url = URL(string: "https://localhost:\(tlsPort)/ping") else { return false }
        var req = URLRequest(url: url)
        req.timeoutInterval = 4
        req.cachePolicy = .reloadIgnoringLocalCacheData
        do { _ = try await URLSession.shared.data(for: req); return true } catch { return false }
    }

    @MainActor func beginBackground() {
        if bgTask != .invalid { UIApplication.shared.endBackgroundTask(bgTask) }
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "azasing-install") { [weak self] in self?.endBackground() }
    }

    private func endBackground() {
        DispatchQueue.main.async {
            if self.bgTask != .invalid { UIApplication.shared.endBackgroundTask(self.bgTask); self.bgTask = .invalid }
        }
    }

    // MARK: HTTP

    private func handle(_ conn: NWConnection) {
        conn.start(queue: queue)
        conn.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] data, _, _, error in
            guard let self, let data, error == nil, let text = String(data: data, encoding: .utf8) else { conn.cancel(); return }
            let line = text.components(separatedBy: "\r\n").first ?? ""
            let parts = line.split(separator: " ").map(String.init)
            let head = parts.first == "HEAD"
            let path = (parts.count > 1 ? parts[1] : "/").components(separatedBy: "?")[0]
            self.route(path, head: head, conn)
        }
    }

    private func route(_ path: String, head: Bool, _ conn: NWConnection) {
        switch path {
        case "/ping":
            send(conn, type: "text/plain", body: Data("ok".utf8), head: head)
        case "/install":
            let manifestURL = "https://localhost:\(tlsPort)/manifest.plist"
            let link = "itms-services://?action=download-manifest&url=\(manifestURL)"
            send(conn, type: "text/html; charset=utf-8", body: Data(page("Instalando…", "Si no empieza sola, toca el botón.", link, "Instalar").utf8), head: head)
        case "/manifest.plist":
            send(conn, type: "text/xml", body: manifest, head: head)
        case "/app.ipa":
            streamIPA(conn, head: head)
        case "/ca":
            send(conn, type: "text/html; charset=utf-8", body: Data(page("Certificado local", "Permite la descarga del perfil y luego instálalo en Ajustes.", "/ca.mobileconfig", "Descargar perfil").utf8), head: head)
        case "/ca.mobileconfig":
            if let url = Bundle.main.url(forResource: "AZASingCA", withExtension: "mobileconfig"), let d = try? Data(contentsOf: url) {
                send(conn, type: "application/x-apple-aspen-config", body: d, head: head)
            } else { send(conn, status: "404 Not Found", type: "text/plain", body: Data("no profile".utf8), head: head) }
        default:
            send(conn, status: "404 Not Found", type: "text/plain", body: Data("not found".utf8), head: head)
        }
    }

    private func page(_ title: String, _ text: String, _ link: String, _ button: String) -> String {
        """
        <!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="refresh" content="0;url=\(link)">
        <style>body{background:#000;color:#fff;font-family:-apple-system,sans-serif;text-align:center;padding:60px 24px}
        a{display:inline-block;margin-top:28px;padding:16px 34px;border-radius:16px;background:#FFC733;color:#000;font-weight:700;text-decoration:none}</style>
        </head><body><h2>\(title)</h2><p>\(text)</p><a href="\(link)">\(button)</a></body></html>
        """
    }

    private func send(_ conn: NWConnection, status: String = "200 OK", type: String, body: Data, head: Bool) {
        var out = Data("HTTP/1.1 \(status)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n".utf8)
        if !head { out.append(body) }
        conn.send(content: out, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() })
    }

    private func streamIPA(_ conn: NWConnection, head: Bool) {
        guard let url = ipaURL,
              let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value else {
            send(conn, status: "404 Not Found", type: "text/plain", body: Data("no ipa".utf8), head: head); return
        }
        let header = Data("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: \(size)\r\nConnection: close\r\n\r\n".utf8)
        if head { conn.send(content: header, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() }); return }
        guard let handle = try? FileHandle(forReadingFrom: url) else { conn.cancel(); return }
        conn.send(content: header, completion: .contentProcessed { [weak self] _ in self?.pump(conn, handle) })
    }

    private func pump(_ conn: NWConnection, _ handle: FileHandle) {
        let chunk = handle.readData(ofLength: 256 * 1024)
        if chunk.isEmpty {
            try? handle.close()
            conn.send(content: nil, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { [weak self] _ in
                conn.cancel()
                DispatchQueue.main.async { self?.onDownloaded?() }
                self?.endBackground()
            })
            return
        }
        conn.send(content: chunk, completion: .contentProcessed { [weak self] error in
            if error != nil { try? handle.close(); conn.cancel(); return }
            self?.pump(conn, handle)
        })
    }
}

// MARK: - Safari dentro de la app (mantiene viva la app y el servidor)

enum SafariPresenter {
    static func present(_ url: URL) {
        guard let top = UIKitBridge.topViewController() else { return }
        top.present(SFSafariViewController(url: url), animated: true)
    }
}

/// Flujo completo de instalación local.
@MainActor
enum LocalInstall {
    /// Devuelve un mensaje de error, o nil si la instalación se lanzó.
    static func run(ipa: URL, afterDownload: (() -> Void)? = nil) async -> String? {
        guard let meta = IPAReader.read(ipa) else { return "No pude leer el IPA firmado." }
        let server = LocalServer.shared
        do { try await server.prepare(ipa: ipa, bundleID: meta.bundleID, version: meta.version, name: meta.name) }
        catch { return "No se pudo iniciar el servidor local: \(error.localizedDescription)" }
        guard await server.isTrusted() else {
            return "Falta confiar en el certificado local. Ve a Ajustes › Instalación local y sigue los pasos."
        }
        server.onDownloaded = afterDownload
        server.beginBackground()
        SafariPresenter.present(URL(string: "https://localhost:\(server.tlsPort)/install")!)
        return nil
    }

    static func setupCertificate() async -> String? {
        let server = LocalServer.shared
        do { try await server.startIfNeeded() } catch { return error.localizedDescription }
        SafariPresenter.present(URL(string: "http://localhost:\(server.httpPort)/ca")!)
        return nil
    }
}
