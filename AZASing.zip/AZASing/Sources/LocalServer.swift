import Foundation
import Network
import Security
import SafariServices
import AVFoundation
import UIKit

enum ServerError: LocalizedError {
    case noIdentity
    var errorDescription: String? { "No se pudo cargar el certificado del servidor local." }
}

/// Mantiene la app viva en segundo plano (audio silencioso) mientras iOS instala
/// un perfil o descarga un IPA desde el servidor local.
@MainActor
final class KeepAlive {
    static let shared = KeepAlive()
    private var player: AVAudioPlayer?
    private var watchdog: Task<Void, Never>?
    private var bgTask: UIBackgroundTaskIdentifier = .invalid
    private var observers: [NSObjectProtocol] = []

    /// (Re)activa la sesión de audio mezclable y el audio silencioso. Se puede llamar varias veces.
    private func activate() {
        let session = AVAudioSession.sharedInstance()
        // mixWithOthers: no le quita el sonido a la música que ya suena (Spotify, Música…).
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)
        if player == nil, let url = Bundle.main.url(forResource: "silence", withExtension: "wav") {
            player = try? AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = -1
            player?.volume = 0.05      // con volumen 0 iOS puede no contarlo como audio activo
            player?.prepareToPlay()
        }
        if player?.isPlaying != true { player?.play() }
    }

    func start(maxSeconds: UInt64 = 240) {
        watchdog?.cancel()
        activate()
        if bgTask == .invalid {
            bgTask = UIApplication.shared.beginBackgroundTask(withName: "azasing.install") { [weak self] in
                Task { @MainActor in self?.endBackgroundTask() }
            }
        }
        if observers.isEmpty {
            let nc = NotificationCenter.default
            observers.append(nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] _ in
                Task { @MainActor in self?.activate() }
            })
            observers.append(nc.addObserver(forName: AVAudioSession.mediaServicesWereResetNotification, object: nil, queue: .main) { [weak self] _ in
                Task { @MainActor in self?.player = nil; self?.activate() }
            })
        }
        // Si otra app (música, llamadas) pausa nuestro audio, se vuelve a arrancar.
        watchdog = Task { [weak self] in
            var elapsed: UInt64 = 0
            while !Task.isCancelled, elapsed < maxSeconds {
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                elapsed += 1
                if Task.isCancelled { return }
                if self?.player?.isPlaying != true { self?.activate() }
            }
            if !Task.isCancelled { self?.stop() }
        }
    }

    private func endBackgroundTask() {
        if bgTask != .invalid { UIApplication.shared.endBackgroundTask(bgTask); bgTask = .invalid }
    }

    func stop() {
        watchdog?.cancel()
        player?.stop()
        player = nil
        observers.forEach { NotificationCenter.default.removeObserver($0) }
        observers = []
        endBackgroundTask()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}

/// Servidor local (solo loopback): HTTPS para instalar IPAs con itms-services y
/// HTTP para entregar los perfiles (CA local y detección de UDID).
final class LocalServer {
    static let shared = LocalServer()
    static let host = "127-0-0-1.my.local-ip.co"

    private var tlsListener: NWListener?
    private(set) var tlsPort: UInt16 = 0
    private let queue = DispatchQueue(label: "azasing.localserver")

    private var ipaURL: URL?
    private var manifest = Data()
    var onDownloaded: (() -> Void)?

    // MARK: Arranque

    func startIfNeeded() async throws {
        if tlsListener == nil { tlsListener = try await makeListener(tls: true) }
        tlsPort = tlsListener?.port?.rawValue ?? 0
    }

    private func makeListener(tls: Bool) async throws -> NWListener {
        let params: NWParameters
        if tls {
            guard let p12 = Self.loadP12(), let secID = sec_identity_create(p12.identity) else { throw ServerError.noIdentity }
            let opts = NWProtocolTLS.Options()
            sec_protocol_options_set_local_identity(opts.securityProtocolOptions, secID)
            params = NWParameters(tls: opts)
        } else {
            params = .tcp
        }
        params.requiredInterfaceType = .loopback   // nunca expuesto a la red
        let listener = try NWListener(using: params)
        listener.newConnectionHandler = { [weak self] conn in self?.accept(conn) }
        return try await withCheckedThrowingContinuation { cont in
            var done = false
            listener.stateUpdateHandler = { state in
                guard !done else { return }
                switch state {
                case .ready: done = true; cont.resume(returning: listener)
                case .failed(let e): done = true; cont.resume(throwing: e)
                default: break
                }
            }
            listener.start(queue: queue)
        }
    }

    private static func loadP12() -> (identity: SecIdentity, chain: [SecCertificate])? {
        // Certificado público de *.my.local-ip.co (apunta a 127.0.0.1): iOS ya confía en él.
        // Si existe una versión más nueva en Application Support se usa esa.
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("public.p12")
        var source: URL? = FileManager.default.fileExists(atPath: support.path) ? support : nil
        if source == nil { source = Bundle.main.url(forResource: "public", withExtension: "p12") }
        guard let url = source, let data = try? Data(contentsOf: url) else { return nil }
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, [kSecImportExportPassphrase as String: "azasing"] as CFDictionary, &items)
        guard status == errSecSuccess, let arr = items as? [[String: Any]], let first = arr.first,
              let id = first[kSecImportItemIdentity as String] else { return nil }
        let chain = (first[kSecImportItemCertChain as String] as? [SecCertificate]) ?? []
        return ((id as! SecIdentity), chain)
    }

    // MARK: Confianza

    /// Evalúa la cadena igual que iOS lo haría para una conexión a https://localhost.
    func trustReport() -> (ok: Bool, reason: String) {
        guard let p12 = Self.loadP12(), !p12.chain.isEmpty else { return (false, "No se pudo leer el certificado incluido en la app.") }
        let policy = SecPolicyCreateSSL(true, LocalServer.host as CFString)
        var trust: SecTrust?
        guard SecTrustCreateWithCertificates(p12.chain as CFArray, policy, &trust) == errSecSuccess, let trust else {
            return (false, "No se pudo crear la evaluación de confianza.")
        }
        var error: CFError?
        if SecTrustEvaluateWithError(trust, &error) { return (true, "") }
        return (false, (error as Error?)?.localizedDescription ?? "El certificado no es de confianza.")
    }

    func isTrusted() async -> Bool { trustReport().ok }

    // MARK: Contenido

    func prepare(ipa: URL, bundleID: String, version: String, name: String) async throws {
        try await startIfNeeded()
        ipaURL = ipa
        let esc: (String) -> String = {
            $0.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
        }
        manifest = Data("""
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0"><dict><key>items</key><array><dict>
        <key>assets</key><array><dict><key>kind</key><string>software-package</string>
        <key>url</key><string>https://\(LocalServer.host):\(tlsPort)/app.ipa</string></dict></array>
        <key>metadata</key><dict>
        <key>bundle-identifier</key><string>\(esc(bundleID))</string>
        <key>bundle-version</key><string>\(esc(version.isEmpty ? "1.0" : version))</string>
        <key>kind</key><string>software</string>
        <key>title</key><string>\(esc(name))</string>
        </dict></dict></array></dict></plist>
        """.utf8)
    }

    // MARK: HTTP

    private func accept(_ conn: NWConnection) {
        conn.start(queue: queue)
        readRequest(conn, buffer: Data())
    }

    /// Lee la petición completa (cabeceras + cuerpo), necesaria para el POST del UDID.
    private func readRequest(_ conn: NWConnection, buffer: Data) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if error != nil { conn.cancel(); return }
            var buf = buffer
            if let data { buf.append(data) }
            guard let end = buf.range(of: Data("\r\n\r\n".utf8)) else {
                if isComplete || buf.count > 1_000_000 { conn.cancel() } else { self.readRequest(conn, buffer: buf) }
                return
            }
            let headerText = String(decoding: buf[buf.startIndex..<end.lowerBound], as: UTF8.self)
            let lines = headerText.components(separatedBy: "\r\n")
            let parts = (lines.first ?? "").split(separator: " ").map(String.init)
            let method = parts.first ?? "GET"
            let path = (parts.count > 1 ? parts[1] : "/").components(separatedBy: "?")[0]
            var length = 0
            for l in lines.dropFirst() where l.lowercased().hasPrefix("content-length:") {
                length = Int(l.dropFirst(15).trimmingCharacters(in: .whitespaces)) ?? 0
            }
            let body = Data(buf[end.upperBound...])
            if body.count < length && !isComplete { self.readRequest(conn, buffer: buf); return }
            self.route(path, method: method, body: body, conn)
        }
    }

    private func route(_ path: String, method: String, body: Data, _ conn: NWConnection) {
        let head = method == "HEAD"
        switch path {
        case "/ping":
            send(conn, type: "text/plain", body: Data("ok".utf8), head: head)
        case "/manifest.plist":
            send(conn, type: "text/xml", body: manifest, head: head)
        case "/app.ipa":
            streamIPA(conn, head: head)
        default:
            notFound(conn, head)
        }
    }

    private func notFound(_ conn: NWConnection, _ head: Bool) {
        send(conn, status: "404 Not Found", type: "text/plain", body: Data("not found".utf8), head: head)
    }

    private func send(_ conn: NWConnection, status: String = "200 OK", type: String, body: Data, head: Bool) {
        var out = Data("HTTP/1.1 \(status)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n".utf8)
        if !head { out.append(body) }
        conn.send(content: out, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() })
    }

    private func streamIPA(_ conn: NWConnection, head: Bool) {
        guard let url = ipaURL,
              let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value else {
            notFound(conn, head); return
        }
        let header = Data("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: \(size)\r\nConnection: close\r\n\r\n".utf8)
        if head { conn.send(content: header, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() }); return }
        guard let handle = try? FileHandle(forReadingFrom: url) else { conn.cancel(); return }
        conn.send(content: header, completion: .contentProcessed { [weak self] _ in self?.pump(conn, handle) })
    }

    private func pump(_ conn: NWConnection, _ handle: FileHandle) {
        let chunk = handle.readData(ofLength: 256 * 1024)
        if chunk.isEmpty {
            try? handle.close()
            conn.send(content: nil, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { [weak self] _ in
                conn.cancel()
                Task { @MainActor in
                    self?.onDownloaded?()
                    KeepAlive.shared.stop()
                }
            })
            return
        }
        conn.send(content: chunk, completion: .contentProcessed { [weak self] error in
            if error != nil { try? handle.close(); conn.cancel(); return }
            self?.pump(conn, handle)
        })
    }
}

// MARK: - Instalación

@MainActor
enum LocalInstall {
    /// Devuelve un mensaje de error, o nil si la instalación se lanzó (iOS muestra su aviso).
    static func run(ipa: URL, afterDownload: (() -> Void)? = nil) async -> String? {
        guard let meta = IPAReader.read(ipa) else { return "No pude leer el IPA firmado." }
        let server = LocalServer.shared
        do { try await server.prepare(ipa: ipa, bundleID: meta.bundleID, version: meta.version, name: meta.name) }
        catch { return "No se pudo iniciar el servidor local: \(error.localizedDescription)" }
        let trust = server.trustReport()
        guard trust.ok else {
            return "El certificado de instalación no es válido (\(trust.reason)). Puede haber caducado: actualiza AZASing."
        }
        server.onDownloaded = {
            afterDownload?()
            // Con la descarga terminada, AZASing se cierra (con la animación de ir a inicio)
            // para que se vea la app instalándose en la pantalla de inicio.
            if UserDefaults.standard.bool(forKey: "closeOnInstall") {
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 800_000_000)
                    AppCloser.goHomeThenQuit()
                }
            }
        }
        KeepAlive.shared.start()
        let direct = "itms-services://?action=download-manifest&url=https://\(LocalServer.host):\(server.tlsPort)/manifest.plist"
        if let url = URL(string: direct), await UIApplication.shared.open(url, options: [:]) { return nil }
        return "iOS no abrió el aviso de instalación. Comprueba que tienes internet e inténtalo de nuevo."
    }
}
