import Foundation
import Network
import Security
import SafariServices
import AVFoundation
import UIKit

enum ServerError: LocalizedError {
    case noIdentity
    var errorDescription: String? { "No se pudo cargar el certificado del servidor local." }
}

/// Mantiene la app viva en segundo plano (audio silencioso) mientras iOS instala
/// un perfil o descarga un IPA desde el servidor local.
@MainActor
final class KeepAlive {
    static let shared = KeepAlive()
    private var player: AVAudioPlayer?
    private var stopTask: Task<Void, Never>?

    func start(maxSeconds: UInt64 = 240) {
        stopTask?.cancel()
        if player == nil, let url = Bundle.main.url(forResource: "silence", withExtension: "wav") {
            try? AVAudioSession.sharedInstance().setCategory(.playback, options: [.mixWithOthers])
            try? AVAudioSession.sharedInstance().setActive(true)
            player = try? AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = -1
            player?.volume = 0
            player?.play()
        }
        stopTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: maxSeconds * 1_000_000_000)
            if !Task.isCancelled { self?.stop() }
        }
    }

    func stop() {
        stopTask?.cancel()
        player?.stop()
        player = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}

/// Servidor local (solo loopback): HTTPS para instalar IPAs con itms-services y
/// HTTP para entregar los perfiles (CA local y detección de UDID).
final class LocalServer {
    static let shared = LocalServer()

    private var tlsListener: NWListener?
    private var httpListener: NWListener?
    private(set) var tlsPort: UInt16 = 0
    private(set) var httpPort: UInt16 = 0
    private let queue = DispatchQueue(label: "azasing.localserver")

    private var ipaURL: URL?
    private var manifest = Data()
    var onDownloaded: (() -> Void)?
    var onUDID: ((String) -> Void)?

    // MARK: Arranque

    func startIfNeeded() async throws {
        if tlsListener == nil { tlsListener = try await makeListener(tls: true) }
        if httpListener == nil { httpListener = try await makeListener(tls: false) }
        tlsPort = tlsListener?.port?.rawValue ?? 0
        httpPort = httpListener?.port?.rawValue ?? 0
    }

    private func makeListener(tls: Bool) async throws -> NWListener {
        let params: NWParameters
        if tls {
            guard let p12 = Self.loadP12(), let secID = sec_identity_create(p12.identity) else { throw ServerError.noIdentity }
            let opts = NWProtocolTLS.Options()
            sec_protocol_options_set_local_identity(opts.securityProtocolOptions, secID)
            params = NWParameters(tls: opts)
        } else {
            params = .tcp
        }
        params.requiredInterfaceType = .loopback   // nunca expuesto a la red
        let listener = try NWListener(using: params)
        listener.newConnectionHandler = { [weak self] conn in self?.accept(conn) }
        return try await withCheckedThrowingContinuation { cont in
            var done = false
            listener.stateUpdateHandler = { state in
                guard !done else { return }
                switch state {
                case .ready: done = true; cont.resume(returning: listener)
                case .failed(let e): done = true; cont.resume(throwing: e)
                default: break
                }
            }
            listener.start(queue: queue)
        }
    }

    private static func loadP12() -> (identity: SecIdentity, chain: [SecCertificate])? {
        guard let url = Bundle.main.url(forResource: "localhost", withExtension: "p12"),
              let data = try? Data(contentsOf: url) else { return nil }
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, [kSecImportExportPassphrase as String: "azasing"] as CFDictionary, &items)
        guard status == errSecSuccess, let arr = items as? [[String: Any]], let first = arr.first,
              let id = first[kSecImportItemIdentity as String] else { return nil }
        let chain = (first[kSecImportItemCertChain as String] as? [SecCertificate]) ?? []
        return ((id as! SecIdentity), chain)
    }

    // MARK: Confianza

    /// Evalúa la cadena igual que iOS lo haría para una conexión a https://localhost.
    func trustReport() -> (ok: Bool, reason: String) {
        guard let p12 = Self.loadP12(), !p12.chain.isEmpty else { return (false, "No se pudo leer el certificado incluido en la app.") }
        let policy = SecPolicyCreateSSL(true, "localhost" as CFString)
        var trust: SecTrust?
        guard SecTrustCreateWithCertificates(p12.chain as CFArray, policy, &trust) == errSecSuccess, let trust else {
            return (false, "No se pudo crear la evaluación de confianza.")
        }
        var error: CFError?
        if SecTrustEvaluateWithError(trust, &error) { return (true, "") }
        return (false, (error as Error?)?.localizedDescription ?? "El certificado no es de confianza.")
    }

    func isTrusted() async -> Bool { trustReport().ok }

    // MARK: Contenido

    func prepare(ipa: URL, bundleID: String, version: String, name: String) async throws {
        try await startIfNeeded()
        ipaURL = ipa
        let esc: (String) -> String = {
            $0.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
        }
        manifest = Data("""
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0"><dict><key>items</key><array><dict>
        <key>assets</key><array><dict><key>kind</key><string>software-package</string>
        <key>url</key><string>https://localhost:\(tlsPort)/app.ipa</string></dict></array>
        <key>metadata</key><dict>
        <key>bundle-identifier</key><string>\(esc(bundleID))</string>
        <key>bundle-version</key><string>\(esc(version.isEmpty ? "1.0" : version))</string>
        <key>kind</key><string>software</string>
        <key>title</key><string>\(esc(name))</string>
        </dict></dict></array></dict></plist>
        """.utf8)
    }

    // MARK: HTTP

    private func accept(_ conn: NWConnection) {
        conn.start(queue: queue)
        readRequest(conn, buffer: Data())
    }

    /// Lee la petición completa (cabeceras + cuerpo), necesaria para el POST del UDID.
    private func readRequest(_ conn: NWConnection, buffer: Data) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if error != nil { conn.cancel(); return }
            var buf = buffer
            if let data { buf.append(data) }
            guard let end = buf.range(of: Data("\r\n\r\n".utf8)) else {
                if isComplete || buf.count > 1_000_000 { conn.cancel() } else { self.readRequest(conn, buffer: buf) }
                return
            }
            let headerText = String(decoding: buf[buf.startIndex..<end.lowerBound], as: UTF8.self)
            let lines = headerText.components(separatedBy: "\r\n")
            let parts = (lines.first ?? "").split(separator: " ").map(String.init)
            let method = parts.first ?? "GET"
            let path = (parts.count > 1 ? parts[1] : "/").components(separatedBy: "?")[0]
            var length = 0
            for l in lines.dropFirst() where l.lowercased().hasPrefix("content-length:") {
                length = Int(l.dropFirst(15).trimmingCharacters(in: .whitespaces)) ?? 0
            }
            let body = Data(buf[end.upperBound...])
            if body.count < length && !isComplete { self.readRequest(conn, buffer: buf); return }
            self.route(path, method: method, body: body, conn)
        }
    }

    private func route(_ path: String, method: String, body: Data, _ conn: NWConnection) {
        let head = method == "HEAD"
        switch path {
        case "/ping":
            send(conn, type: "text/plain", body: Data("ok".utf8), head: head)
        case "/install":
            let link = "itms-services://?action=download-manifest&url=https://localhost:\(tlsPort)/manifest.plist"
            send(conn, type: "text/html; charset=utf-8", body: Data(page("Instalando…", "Si no empieza sola, toca el botón.", link, "Instalar").utf8), head: head)
        case "/manifest.plist":
            send(conn, type: "text/xml", body: manifest, head: head)
        case "/app.ipa":
            streamIPA(conn, head: head)
        case "/ca":
            send(conn, type: "text/html; charset=utf-8", body: Data(page("Certificado local", "Permite la descarga del perfil y luego instálalo en Ajustes.", "/ca.mobileconfig", "Descargar perfil").utf8), head: head)
        case "/ca.mobileconfig":
            if let url = Bundle.main.url(forResource: "AZASingCA", withExtension: "mobileconfig"), let d = try? Data(contentsOf: url) {
                send(conn, type: "application/x-apple-aspen-config", body: d, head: head)
            } else { notFound(conn, head) }
        case "/udid-install":
            send(conn, type: "text/html; charset=utf-8", body: Data(page("Detectar UDID", "Permite la descarga del perfil y luego instálalo en Ajustes.", "/udid.mobileconfig", "Descargar perfil").utf8), head: head)
        case "/udid.mobileconfig":
            send(conn, type: "application/x-apple-aspen-config", body: Data(udidProfile().utf8), head: head)
        case "/udid":
            if method == "POST", let udid = Self.extractUDID(body) {
                DispatchQueue.main.async { self.onUDID?(udid) }
            }
            let loc = "http://localhost:\(httpPort)/udid-done"
            conn.send(content: Data("HTTP/1.1 301 Moved Permanently\r\nLocation: \(loc)\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8),
                      contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() })
        case "/udid-done":
            send(conn, type: "text/html; charset=utf-8", body: Data(page("UDID detectado", "Vuelve a AZASing: ya aparece en Ajustes.", "", "").utf8), head: head)
        default:
            notFound(conn, head)
        }
    }

    private func notFound(_ conn: NWConnection, _ head: Bool) {
        send(conn, status: "404 Not Found", type: "text/plain", body: Data("not found".utf8), head: head)
    }

    /// Perfil "Profile Service": iOS envía el UDID al URL indicado cuando se instala.
    private func udidProfile() -> String {
        let secure = trustReport().ok && tlsPort != 0
        let url = secure ? "https://localhost:\(tlsPort)/udid" : "http://localhost:\(httpPort)/udid"
        return """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0"><dict>
        <key>PayloadContent</key><dict>
          <key>URL</key><string>\(url)</string>
          <key>DeviceAttributes</key><array><string>UDID</string><string>PRODUCT</string><string>VERSION</string></array>
        </dict>
        <key>PayloadOrganization</key><string>AZASing</string>
        <key>PayloadDisplayName</key><string>AZASing · Detectar UDID</string>
        <key>PayloadVersion</key><integer>1</integer>
        <key>PayloadUUID</key><string>\(UUID().uuidString)</string>
        <key>PayloadIdentifier</key><string>com.azasing.udid</string>
        <key>PayloadDescription</key><string>Envía el UDID de este iPhone a AZASing (solo en este dispositivo).</string>
        <key>PayloadType</key><string>Profile Service</string>
        </dict></plist>
        """
    }

    /// El cuerpo es un CMS que contiene un plist en texto claro.
    private static func extractUDID(_ body: Data) -> String? {
        guard let s = body.range(of: Data("<?xml".utf8)), let e = body.range(of: Data("</plist>".utf8)) else { return nil }
        let plist = body.subdata(in: s.lowerBound..<e.upperBound)
        let dict = (try? PropertyListSerialization.propertyList(from: plist, options: [], format: nil)) as? [String: Any]
        return dict?["UDID"] as? String
    }

    private func page(_ title: String, _ text: String, _ link: String, _ button: String) -> String {
        let refresh = link.isEmpty ? "" : "<meta http-equiv=\"refresh\" content=\"0;url=\(link)\">"
        let btn = link.isEmpty ? "" : "<a href=\"\(link)\">\(button)</a>"
        return """
        <!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        \(refresh)
        <style>body{background:#000;color:#fff;font-family:-apple-system,sans-serif;text-align:center;padding:60px 24px}
        a{display:inline-block;margin-top:28px;padding:16px 34px;border-radius:16px;background:#FFC733;color:#000;font-weight:700;text-decoration:none}</style>
        </head><body><h2>\(title)</h2><p>\(text)</p>\(btn)</body></html>
        """
    }

    private func send(_ conn: NWConnection, status: String = "200 OK", type: String, body: Data, head: Bool) {
        var out = Data("HTTP/1.1 \(status)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n".utf8)
        if !head { out.append(body) }
        conn.send(content: out, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() })
    }

    private func streamIPA(_ conn: NWConnection, head: Bool) {
        guard let url = ipaURL,
              let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value else {
            notFound(conn, head); return
        }
        let header = Data("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: \(size)\r\nConnection: close\r\n\r\n".utf8)
        if head { conn.send(content: header, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in conn.cancel() }); return }
        guard let handle = try? FileHandle(forReadingFrom: url) else { conn.cancel(); return }
        conn.send(content: header, completion: .contentProcessed { [weak self] _ in self?.pump(conn, handle) })
    }

    private func pump(_ conn: NWConnection, _ handle: FileHandle) {
        let chunk = handle.readData(ofLength: 256 * 1024)
        if chunk.isEmpty {
            try? handle.close()
            conn.send(content: nil, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { [weak self] _ in
                conn.cancel()
                Task { @MainActor in
                    self?.onDownloaded?()
                    KeepAlive.shared.stop()
                }
            })
            return
        }
        conn.send(content: chunk, completion: .contentProcessed { [weak self] error in
            if error != nil { try? handle.close(); conn.cancel(); return }
            self?.pump(conn, handle)
        })
    }
}

// MARK: - Safari dentro de la app (mantiene viva la app y el servidor)

enum SafariPresenter {
    static func present(_ url: URL) {
        guard let top = UIKitBridge.topViewController() else { return }
        top.present(SFSafariViewController(url: url), animated: true)
    }
}

/// Flujos que usan el servidor local.
@MainActor
enum LocalInstall {
    /// Devuelve un mensaje de error, o nil si la instalación se lanzó.
    static func run(ipa: URL, afterDownload: (() -> Void)? = nil) async -> String? {
        guard let meta = IPAReader.read(ipa) else { return "No pude leer el IPA firmado." }
        let server = LocalServer.shared
        do { try await server.prepare(ipa: ipa, bundleID: meta.bundleID, version: meta.version, name: meta.name) }
        catch { return "No se pudo iniciar el servidor local: \(error.localizedDescription)" }
        let trust = server.trustReport()
        guard trust.ok else {
            return "El iPhone aún no confía en el certificado local (\(trust.reason)). Ve a Ajustes › Instalación local."
        }
        server.onDownloaded = afterDownload
        KeepAlive.shared.start()
        SafariPresenter.present(URL(string: "https://localhost:\(server.tlsPort)/install")!)
        return nil
    }

    static func setupCertificate() async -> String? {
        let server = LocalServer.shared
        do { try await server.startIfNeeded() } catch { return error.localizedDescription }
        KeepAlive.shared.start(maxSeconds: 180)
        SafariPresenter.present(URL(string: "http://localhost:\(server.httpPort)/ca")!)
        return nil
    }

    /// Instala un perfil que hace que iOS envíe el UDID a la app.
    static func detectUDID(onDone: @escaping (String) -> Void) async -> String? {
        let server = LocalServer.shared
        do { try await server.startIfNeeded() } catch { return error.localizedDescription }
        server.onUDID = { udid in
            UserDefaults.standard.set(udid, forKey: "udid")
            KeepAlive.shared.stop()
            onDone(udid)
        }
        KeepAlive.shared.start(maxSeconds: 240)
        SafariPresenter.present(URL(string: "http://localhost:\(server.httpPort)/udid-install")!)
        return nil
    }
}
