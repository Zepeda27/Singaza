import Foundation

/// Crear y leer paquetes .deb (ar + tar + gzip) sin librerías externas.
enum DebKit {
    struct Failure: LocalizedError {
        let message: String
        init(_ m: String) { message = m }
        var errorDescription: String? { message }
    }

    // MARK: gzip

    private static let crcTable: [UInt32] = (0..<256).map { n -> UInt32 in
        var c = UInt32(n)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }

    static func crc32(_ data: Data) -> UInt32 {
        var c: UInt32 = 0xFFFFFFFF
        for b in data { c = crcTable[Int((c ^ UInt32(b)) & 0xFF)] ^ (c >> 8) }
        return c ^ 0xFFFFFFFF
    }

    static func gzip(_ data: Data) throws -> Data {
        let raw = try (data as NSData).compressed(using: .zlib) as Data   // DEFLATE sin cabecera
        var out = Data([0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 3])
        out.append(raw)
        var crc = crc32(data).littleEndian
        var size = UInt32(truncatingIfNeeded: data.count).littleEndian
        out.append(Data(bytes: &crc, count: 4))
        out.append(Data(bytes: &size, count: 4))
        return out
    }

    static func gunzip(_ data: Data) throws -> Data {
        guard data.count > 18, data[data.startIndex] == 0x1f, data[data.startIndex + 1] == 0x8b else { throw Failure("Datos gzip no válidos.") }
        let d = Data(data)
        let flags = d[3]
        var pos = 10
        if flags & 4 != 0 { pos += 2 + (Int(d[pos]) | Int(d[pos + 1]) << 8) }
        if flags & 8 != 0 { while d[pos] != 0 { pos += 1 }; pos += 1 }
        if flags & 16 != 0 { while d[pos] != 0 { pos += 1 }; pos += 1 }
        if flags & 2 != 0 { pos += 2 }
        let raw = d.subdata(in: pos..<(d.count - 8))
        return try (raw as NSData).decompressed(using: .zlib) as Data
    }

    // MARK: tar

    struct TarEntry {
        var path: String
        var data: Data?
        var isDir: Bool
        var mode: Int
    }

    private static func octal(_ v: Int, _ width: Int) -> String {
        let s = String(v, radix: 8)
        return String(repeating: "0", count: max(0, width - s.count)) + s
    }

    static func tar(_ entries: [TarEntry]) -> Data {
        var out = Data()
        for e in entries {
            var header = Data(count: 512)
            func put(_ s: String, _ off: Int, _ len: Int) {
                let b = Array(s.utf8.prefix(len))
                header.replaceSubrange(off..<(off + b.count), with: b)
            }
            var name = e.path + (e.isDir && !e.path.hasSuffix("/") ? "/" : "")
            var prefix = ""
            if name.utf8.count > 100, let cut = name.dropLast().lastIndex(of: "/") {
                prefix = String(name[..<cut])
                name = String(name[name.index(after: cut)...])
            }
            put(name, 0, 100)
            put(octal(e.mode, 7), 100, 8)
            put("0000000", 108, 8)
            put("0000000", 116, 8)
            put(octal(e.isDir ? 0 : (e.data?.count ?? 0), 11), 124, 12)
            put(octal(Int(Date().timeIntervalSince1970), 11), 136, 12)
            header.replaceSubrange(148..<156, with: Array("        ".utf8))
            header[156] = e.isDir ? UInt8(ascii: "5") : UInt8(ascii: "0")
            put("ustar", 257, 6)
            put("00", 263, 2)
            put(prefix, 345, 155)
            let sum = header.reduce(0) { $0 + Int($1) }
            put(octal(sum, 6), 148, 6)
            header[154] = 0
            header[155] = UInt8(ascii: " ")
            out.append(header)
            if let d = e.data, !e.isDir {
                out.append(d)
                out.append(Data(count: (512 - d.count % 512) % 512))
            }
        }
        out.append(Data(count: 1024))
        return out
    }

    static func untar(_ data: Data, to dest: URL) throws {
        let fm = FileManager.default
        var pos = 0
        var longName: String?
        while pos + 512 <= data.count {
            let h = data.subdata(in: pos..<(pos + 512))
            if h.allSatisfy({ $0 == 0 }) { break }
            func str(_ off: Int, _ len: Int) -> String {
                String(decoding: h.subdata(in: off..<(off + len)).prefix { $0 != 0 }, as: UTF8.self)
            }
            var name = str(0, 100)
            let prefix = str(345, 155)
            if !prefix.isEmpty { name = prefix + "/" + name }
            let size = Int(str(124, 12).trimmingCharacters(in: .whitespaces), radix: 8) ?? 0
            let type = h[156]
            pos += 512
            let body = data.subdata(in: pos..<min(pos + size, data.count))
            pos += ((size + 511) / 512) * 512
            if type == UInt8(ascii: "L") { longName = String(decoding: body.prefix { $0 != 0 }, as: UTF8.self); continue }
            if let ln = longName { name = ln; longName = nil }
            var rel = name
            while rel.hasPrefix("./") { rel.removeFirst(2) }
            rel = rel.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            guard !rel.isEmpty, !rel.contains("..") else { continue }
            let target = dest.appendingPathComponent(rel)
            if type == UInt8(ascii: "5") {
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
            } else if type == 0 || type == UInt8(ascii: "0") {
                try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                try body.write(to: target)
            }
        }
    }

    // MARK: ar

    static func ar(_ files: [(name: String, data: Data)]) -> Data {
        func pad(_ s: String, _ n: Int) -> [UInt8] {
            var b = Array(s.utf8.prefix(n))
            while b.count < n { b.append(0x20) }
            return b
        }
        var out = Data("!<arch>\n".utf8)
        for f in files {
            out.append(contentsOf: pad(f.name + "/", 16))
            out.append(contentsOf: pad("0", 12))
            out.append(contentsOf: pad("0", 6))
            out.append(contentsOf: pad("0", 6))
            out.append(contentsOf: pad("100644", 8))
            out.append(contentsOf: pad(String(f.data.count), 10))
            out.append(contentsOf: [0x60, 0x0A])
            out.append(f.data)
            if f.data.count % 2 == 1 { out.append(0x0A) }
        }
        return out
    }

    // MARK: crear .deb

    /// Empaqueta dylibs, frameworks y bundles en un .deb listo para inyectar.
    static func createDeb(name: String, items: [URL], output: URL) throws {
        let fm = FileManager.default
        var entries: [TarEntry] = []
        var dirs = Set<String>()

        func addDirs(for path: String) {
            let comps = path.split(separator: "/").dropLast().map(String.init)
            var acc: [String] = []
            for c in comps {
                acc.append(c)
                let p = acc.joined(separator: "/")
                if dirs.insert(p).inserted { entries.append(TarEntry(path: p, data: nil, isDir: true, mode: 0o755)) }
            }
        }
        func addFile(_ src: URL, as dest: String) throws {
            addDirs(for: dest)
            entries.append(TarEntry(path: dest, data: try Data(contentsOf: src), isDir: false, mode: 0o755))
        }
        func addTree(_ src: URL, as dest: String) throws {
            addDirs(for: dest + "/x")
            if dirs.insert(dest).inserted { entries.append(TarEntry(path: dest, data: nil, isDir: true, mode: 0o755)) }
            guard let en = fm.enumerator(at: src, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]) else { return }
            let base = src.path
            for case let u as URL in en {
                let v = try? u.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                if v?.isSymbolicLink == true { continue }
                let rel = String(u.path.dropFirst(base.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                if v?.isDirectory == true {
                    let p = dest + "/" + rel
                    if dirs.insert(p).inserted { entries.append(TarEntry(path: p, data: nil, isDir: true, mode: 0o755)) }
                } else {
                    try addFile(u, as: dest + "/" + rel)
                }
            }
        }
        func classify(_ u: URL) throws -> Bool {
            let ext = u.pathExtension.lowercased()
            switch ext {
            case "dylib": try addFile(u, as: "Library/MobileSubstrate/DynamicLibraries/" + u.lastPathComponent); return true
            case "framework": try addTree(u, as: "Library/Frameworks/" + u.lastPathComponent); return true
            case "bundle": try addTree(u, as: "Library/Application Support/" + u.lastPathComponent); return true
            default: return false
            }
        }

        var count = 0
        for item in items {
            if try classify(item) { count += 1; continue }
            // Una carpeta cualquiera: se toman los dylib/framework/bundle que contenga
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: item.path, isDirectory: &isDir), isDir.boolValue,
               let en = fm.enumerator(at: item, includingPropertiesForKeys: [.isDirectoryKey]) {
                for case let u as URL in en {
                    let ext = u.pathExtension.lowercased()
                    if ["framework", "bundle"].contains(ext) { en.skipDescendants() }
                    if ["dylib", "framework", "bundle"].contains(ext), try classify(u) { count += 1 }
                }
            }
        }
        guard count > 0 else { throw Failure("No encontré .dylib, .framework ni .bundle para empaquetar.") }

        let slug = name.lowercased().filter { $0.isLetter || $0.isNumber }
        let control = """
        Package: com.azasing.\(slug.isEmpty ? "tweak" : slug)
        Name: \(name)
        Version: 1.0
        Architecture: iphoneos-arm
        Description: Paquete creado con AZASing
        Maintainer: AZASing
        Author: AZASing
        Section: Tweaks

        """
        let controlTar = try gzip(tar([TarEntry(path: "control", data: Data(control.utf8), isDir: false, mode: 0o644)]))
        let dataTar = try gzip(tar(entries))
        let deb = ar([("debian-binary", Data("2.0\n".utf8)), ("control.tar.gz", controlTar), ("data.tar.gz", dataTar)])
        try? fm.removeItem(at: output)
        try deb.write(to: output)
    }

    // MARK: leer .deb

    static func extractDeb(_ url: URL, to dest: URL) throws {
        let data = try Data(contentsOf: url)
        guard data.count > 8, String(decoding: data.prefix(8), as: UTF8.self) == "!<arch>\n" else {
            throw Failure("“\(url.lastPathComponent)” no es un .deb válido.")
        }
        var pos = 8
        while pos + 60 <= data.count {
            let header = data.subdata(in: pos..<(pos + 60))
            let name = String(decoding: header.subdata(in: 0..<16), as: UTF8.self).trimmingCharacters(in: CharacterSet(charactersIn: " /"))
            let size = Int(String(decoding: header.subdata(in: 48..<58), as: UTF8.self).trimmingCharacters(in: .whitespaces)) ?? 0
            pos += 60
            let body = data.subdata(in: pos..<min(pos + size, data.count))
            pos += size + (size % 2)
            guard name.hasPrefix("data.tar") else { continue }
            if name == "data.tar" { try untar(body, to: dest) }
            else if name.hasSuffix(".gz") { try untar(try gunzip(body), to: dest) }
            else if name.hasSuffix(".lzma") { try untar(try LZMA.decodeAlone(body), to: dest) }
            else if name.hasSuffix(".xz") { try untar(try LZMA.decodeXZ(body), to: dest) }
            else { throw Failure("Este .deb usa compresión \(name.replacingOccurrences(of: "data.tar.", with: "")), que aún no se soporta (se soportan gzip, lzma y xz). Importa los .dylib sueltos.") }
            return
        }
        throw Failure("El .deb no contiene datos (data.tar).")
    }

    struct DebItem: Hashable { let name: String; let kind: String }

    /// Lista los dylib/framework/bundle que contiene un .deb (para elegir cuáles inyectar).
    static func listItems(_ deb: URL) -> [DebItem] {
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory.appendingPathComponent("deblist-\(UUID().uuidString)")
        defer { try? fm.removeItem(at: tmp) }
        do {
            try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
            try extractDeb(deb, to: tmp)
        } catch { return [] }
        let found = collect(in: tmp)
        return found.dylibs.map { DebItem(name: $0.lastPathComponent, kind: "dylib") }
            + found.frameworks.map { DebItem(name: $0.lastPathComponent, kind: "framework") }
            + found.bundles.map { DebItem(name: $0.lastPathComponent, kind: "bundle") }
    }

    /// Busca dylibs, frameworks y bundles dentro de una carpeta extraída.
    static func collect(in root: URL) -> (dylibs: [URL], frameworks: [URL], bundles: [URL]) {
        var d: [URL] = [], f: [URL] = [], b: [URL] = []
        guard let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]) else { return (d, f, b) }
        for case let u as URL in en {
            let v = try? u.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            if v?.isSymbolicLink == true { continue }
            let ext = u.pathExtension.lowercased()
            if v?.isDirectory == true {
                if ext == "framework" { f.append(u); en.skipDescendants() }
                else if ext == "bundle" { b.append(u); en.skipDescendants() }
            } else if ext == "dylib" { d.append(u) }
        }
        return (d, f, b)
    }
}
