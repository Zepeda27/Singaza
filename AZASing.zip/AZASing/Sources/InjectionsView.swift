import SwiftUI
import ZIPFoundation

// MARK: - Detección (por reglas de nombres)

struct InjFound: Identifiable, Hashable {
    enum Kind: String { case dylib = "Librerías (dylib)", framework = "Frameworks", bundle = "Bundles", icon = "Iconos", plist = "Info.plist" }
    let id = UUID()
    var kind: Kind
    var name: String
    var url: URL?
    var detail = ""
    var packable: Bool { url != nil && [.dylib, .framework, .bundle].contains(kind) }
}

struct InjectionResult {
    var found: [InjFound] = []
    var others: [InjFound] = []
}

enum InjectionScanner {
    static let hints = ["substrate", "substitute", "ellekit", "cephei", "orion", "tweak", "inject", "hook", "plus", "++",
                        "sideload", "cydia", "libhooker", "preferenceloader", "altlist", "rocketbootstrap", "xposed",
                        "frida", "gadget", "flex", "patch", "mod", "cheat", "azaicon"]
    static let plistKeys = ["UIFileSharingEnabled", "LSSupportsOpeningDocumentsInPlace", "GCSupportsGameMode",
                            "CADisableMinimumFrameDurationOnPhone", "LSApplicationCategoryType"]

    static func hinted(_ name: String) -> Bool {
        let l = name.lowercased()
        return hints.contains { l.contains($0) }
    }

    /// `appDir` es la carpeta .app ya descomprimida.
    static func scan(appDir: URL) -> InjectionResult {
        let fm = FileManager.default
        var res = InjectionResult()
        var stems = Set<String>()
        var usedPaths = Set<String>()

        let info = NSDictionary(contentsOf: appDir.appendingPathComponent("Info.plist"))
        let exec = (info?["CFBundleExecutable"] as? String).map { appDir.appendingPathComponent($0) }
        let loaded: [String] = {
            guard let exec, let data = try? Data(contentsOf: exec, options: .mappedIfSafe) else { return [] }
            return MachOInjector.dylibs(in: data)
        }()

        func resolve(_ p: String) -> URL? {
            var rel = p
            for pre in ["@executable_path/", "@loader_path/", "@rpath/"] where rel.hasPrefix(pre) { rel = String(rel.dropFirst(pre.count)) }
            var cands = [rel, "Frameworks/" + rel]
            if let r = rel.range(of: ".framework/") {
                let f = String(rel[..<r.upperBound].dropLast())
                cands = [f, "Frameworks/" + f]
            }
            for c in cands {
                let u = appDir.appendingPathComponent(c)
                if fm.fileExists(atPath: u.path) { return u }
            }
            return nil
        }

        // 1) Librerías cargadas por el ejecutable
        for p in loaded {
            let file = resolve(p)
            let nm = (p as NSString).lastPathComponent
            let isFramework = file?.pathExtension.lowercased() == "framework"
            let isDylib = nm.lowercased().hasSuffix(".dylib")
            guard isDylib || hinted(p) || hinted(nm) || p.hasPrefix("@executable_path/") else { continue }
            let target = file ?? URL(fileURLWithPath: "/")
            let kind: InjFound.Kind = isFramework ? .framework : .dylib
            res.found.append(InjFound(kind: kind, name: file?.lastPathComponent ?? nm, url: file, detail: p))
            if let file { usedPaths.insert(file.path); stems.insert(file.deletingPathExtension().lastPathComponent.lowercased()) }
            _ = target
        }

        // 2) dylib sueltos en cualquier parte de la app
        if let en = fm.enumerator(at: appDir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) {
            for case let u as URL in en {
                if u.path.contains("/PlugIns/") || u.path.contains("/Watch/") { en.skipDescendants(); continue }
                if u.pathExtension.lowercased() == "dylib", !usedPaths.contains(u.path) {
                    res.found.append(InjFound(kind: .dylib, name: u.lastPathComponent, url: u, detail: "dylib dentro de la app"))
                    usedPaths.insert(u.path); stems.insert(u.deletingPathExtension().lastPathComponent.lowercased())
                }
            }
        }

        // 3) Frameworks por nombre típico de tweak
        let fw = (try? fm.contentsOfDirectory(at: appDir.appendingPathComponent("Frameworks"), includingPropertiesForKeys: nil)) ?? []
        for u in fw where u.pathExtension.lowercased() == "framework" {
            if usedPaths.contains(u.path) { continue }
            if hinted(u.lastPathComponent) {
                res.found.append(InjFound(kind: .framework, name: u.lastPathComponent, url: u, detail: "nombre típico de tweak"))
                usedPaths.insert(u.path); stems.insert(u.deletingPathExtension().lastPathComponent.lowercased())
            } else {
                res.others.append(InjFound(kind: .framework, name: u.lastPathComponent, url: u))
            }
        }

        // 4) Bundles en la raíz
        let root = (try? fm.contentsOfDirectory(at: appDir, includingPropertiesForKeys: nil)) ?? []
        for u in root where u.pathExtension.lowercased() == "bundle" {
            let stem = u.deletingPathExtension().lastPathComponent.lowercased()
            if hinted(u.lastPathComponent) || stems.contains(stem) {
                res.found.append(InjFound(kind: .bundle, name: u.lastPathComponent, url: u,
                                          detail: stems.contains(stem) ? "coincide con una librería inyectada" : "nombre típico de tweak"))
            } else {
                res.others.append(InjFound(kind: .bundle, name: u.lastPathComponent, url: u))
            }
        }

        // 5) Iconos reemplazados por AZASing
        for u in root where u.lastPathComponent.hasPrefix("AZAIcon") {
            res.found.append(InjFound(kind: .icon, name: u.lastPathComponent, url: u, detail: "icono reemplazado"))
        }

        res.found.sort { ($0.kind.rawValue, $0.name.lowercased()) < ($1.kind.rawValue, $1.name.lowercased()) }
        res.others.sort { $0.name.lowercased() < $1.name.lowercased() }
        return res
    }
}

// MARK: - Pantalla

struct InjectionsView: View {
    let ipa: URL
    var title: String
    @Environment(\.dismiss) private var dismiss
    @State private var loading = true
    @State private var result = InjectionResult()
    @State private var selection = Set<UUID>()
    @State private var message: String?
    @State private var showDebName = false
    @State private var debName = ""
    @State private var working = false

    private var all: [InjFound] { result.found + result.others }
    private var chosen: [InjFound] { all.filter { selection.contains($0.id) } }

    var body: some View {
        NavigationStack {
            List {
                if loading {
                    HStack { ProgressView(); Text("Analizando…").foregroundStyle(.secondary) }
                } else {
                    Section {
                        Text("Detección por nombres y rutas, sin IPA original. Marca a mano en «Otros archivos» lo que falte.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if result.found.isEmpty {
                        Section { Text("No encontré nada inyectado.").foregroundStyle(.secondary) }
                    }
                    ForEach(groups, id: \.0) { kind, items in
                        Section(kind.rawValue + " (\(items.count))") {
                            ForEach(items) { row($0) }
                        }
                    }
                    if !result.others.isEmpty {
                        Section {
                            DisclosureGroup("Otros archivos de la app (\(result.others.count))") {
                                ForEach(result.others) { row($0) }
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Qué lleva inyectado")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(selection.count == selectable.count && !selectable.isEmpty ? "Ninguno" : "Todo") {
                        selection = selection.count == selectable.count ? [] : Set(selectable.map(\.id))
                    }.disabled(selectable.isEmpty)
                }
            }
            .safeAreaInset(edge: .bottom) {
                HStack(spacing: 10) {
                    Button { share() } label: {
                        Label("Compartir", systemImage: "square.and.arrow.up").font(.headline).foregroundColor(.gold)
                            .frame(maxWidth: .infinity).padding(.vertical, 14)
                    }
                    .buttonStyle(.plain).glassCard(cornerRadius: 18)
                    Button { debName = title; showDebName = true } label: { Text(working ? "Creando…" : "Crear deb") }
                        .buttonStyle(GoldButtonStyle())
                }
                .disabled(chosen.filter(\.packable).isEmpty || working)
                .padding(.horizontal).padding(.vertical, 8)
            }
            .alert("Nombre del deb", isPresented: $showDebName) {
                TextField("Nombre", text: $debName)
                Button("Crear") { makeDeb() }
                Button("Cancelar", role: .cancel) {}
            }
            .alert("Inyecciones", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
            .task { await load() }
        }
    }

    private var selectable: [InjFound] { result.found.filter(\.packable) }
    private var groups: [(InjFound.Kind, [InjFound])] {
        let order: [InjFound.Kind] = [.dylib, .framework, .bundle, .icon]
        return order.compactMap { k in
            let items = result.found.filter { $0.kind == k }
            return items.isEmpty ? nil : (k, items)
        }
    }

    @ViewBuilder private func row(_ f: InjFound) -> some View {
        let content = VStack(alignment: .leading, spacing: 2) {
            Text(f.name).font(.body)
            if !f.detail.isEmpty { Text(f.detail).font(.caption2).foregroundStyle(.secondary).lineLimit(2) }
        }
        if f.url != nil {
            Toggle(isOn: Binding(get: { selection.contains(f.id) },
                                 set: { on in if on { selection.insert(f.id) } else { selection.remove(f.id) } })) { content }
        } else { content }
    }

    private func load() async {
        loading = true
        let app: URL? = await {
            guard let folder = await WorkspaceOpener.prepare(ipa: ipa) else { return nil }
            let payload = folder.lastPathComponent == "Payload" ? folder : folder.appendingPathComponent("Payload")
            let names = (try? FileManager.default.contentsOfDirectory(atPath: payload.path)) ?? []
            return names.first { $0.hasSuffix(".app") }.map { payload.appendingPathComponent($0) }
        }()
        guard let app else { loading = false; message = "No se pudo abrir el IPA."; return }
        let r = await Task.detached { InjectionScanner.scan(appDir: app) }.value
        result = r
        selection = Set(r.found.filter(\.packable).map(\.id))
        loading = false
    }

    private func share() {
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent("inj-\(UUID().uuidString)")
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        var urls: [URL] = []
        for f in chosen {
            guard let u = f.url else { continue }
            var isDir: ObjCBool = false
            fm.fileExists(atPath: u.path, isDirectory: &isDir)
            if isDir.boolValue {
                let z = dir.appendingPathComponent(u.lastPathComponent + ".zip")
                if (try? fm.zipItem(at: u, to: z, shouldKeepParent: true)) != nil { urls.append(z) }
            } else {
                let c = dir.appendingPathComponent(u.lastPathComponent)
                if (try? fm.copyItem(at: u, to: c)) != nil { urls.append(c) }
            }
        }
        guard !urls.isEmpty else { message = "Selecciona al menos un archivo."; return }
        Share.present(urls)
    }

    private func makeDeb() {
        let n = debName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty else { return }
        let items = chosen.filter(\.packable).compactMap(\.url)
        var out = Folder.tweaks.url.appendingPathComponent(n + ".deb")
        var i = 2
        while FileManager.default.fileExists(atPath: out.path) {
            out = Folder.tweaks.url.appendingPathComponent("\(n) \(i).deb"); i += 1
        }
        working = true
        let target = out
        Task {
            do {
                try await Task.detached { try DebKit.createDeb(name: n, items: items, output: target) }.value
                message = "Deb creado en Tweaks: \(target.lastPathComponent). Ya puedes elegirlo al firmar."
            } catch { message = "Error: \(error.localizedDescription)" }
            working = false
        }
    }
}
