import SwiftUI

struct SettingsView: View {
    @AppStorage("installAfterSign") private var installAfter = true
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("appendSuffix") private var appendSuffix = true
    @AppStorage("accentHex") private var accentHex = "FFC733"

    @State private var trusted: Bool?
    @State private var message: String?
    @State private var currentIcon = UIApplication.shared.alternateIconName

    private let icons: [(title: String, name: String?, preview: String)] = [
        ("Dorado", nil, "PrevDorado"), ("Plata", "IconPlata", "PrevPlata"), ("Rosa", "IconRosa", "PrevRosa")
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("Instalación local") {
                    HStack(spacing: 10) {
                        Image(systemName: trusted == true ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                            .foregroundColor(trusted == true ? .green : .orange)
                        Text(trusted == nil ? "Comprobando…" : (trusted == true ? "Certificado local listo" : "Falta instalar y confiar en el certificado local"))
                            .font(.subheadline)
                    }
                    Button("Instalar certificado local") {
                        Task { message = await LocalInstall.setupCertificate() }
                    }
                    Button("Comprobar de nuevo") { Task { await check() } }
                    Text("1. Toca «Instalar certificado local» y permite la descarga.\n2. Abre Ajustes › Perfil descargado e instálalo.\n3. Ajustes › General › Información › Ajustes de confianza de certificados: activa «AZASing Local CA».\nSolo se hace una vez.")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("Firmado") {
                    Picker("Compresión", selection: $compression) {
                        Text("Rápida").tag(0)
                        Text("Estándar").tag(1)
                    }
                    .pickerStyle(.segmented)
                    Toggle("Instalar después de firmar", isOn: $installAfter)
                    Toggle("Borrar el IPA tras instalar", isOn: $autoDelete)
                    Toggle("Quitar esquemas URL", isOn: $removeURLs)
                    Toggle("Quitar Apple Watch", isOn: $removeWatch)
                    Toggle("Añadir sufijo -AZASing al archivo", isOn: $appendSuffix)
                }

                Section("Color de acento") {
                    ColorPicker("Color", selection: Binding(get: { Color(hex: accentHex) },
                                                            set: { accentHex = $0.hexString }), supportsOpacity: false)
                    Button("Restablecer") { accentHex = "FFC733" }
                }

                Section("Icono de la app") {
                    HStack(spacing: 18) {
                        ForEach(icons, id: \.title) { icon in
                            Button { setIcon(icon.name) } label: {
                                VStack(spacing: 6) {
                                    Image(icon.preview).resizable().scaledToFit().frame(width: 74, height: 74)
                                        .clipShape(RoundedRectangle(cornerRadius: 17))
                                        .overlay(RoundedRectangle(cornerRadius: 17)
                                            .stroke(currentIcon == icon.name ? Color.gold : .clear, lineWidth: 3))
                                    Text(icon.title).font(.caption)
                                        .foregroundColor(currentIcon == icon.name ? .gold : .secondary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Ajustes")
            .task { await check() }
            .alert("AZASing", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func check() async {
        trusted = nil
        do {
            try await LocalServer.shared.startIfNeeded()
            trusted = await LocalServer.shared.isTrusted()
        } catch {
            trusted = false
            message = error.localizedDescription
        }
    }

    private func setIcon(_ name: String?) {
        UIApplication.shared.setAlternateIconName(name) { error in
            DispatchQueue.main.async {
                if let error { message = "No se pudo cambiar el icono: \(error.localizedDescription)" }
                else { currentIcon = name }
            }
        }
    }
}
