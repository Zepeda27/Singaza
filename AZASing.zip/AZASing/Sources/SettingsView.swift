import SwiftUI

enum AboutInfo {
    /// Dirección de la página web de AZA (por ejemplo "https://tusitio.com"). Vacía = no se muestra.
    static let website = "https://azappgrupo.netlify.app"
}

struct SettingsView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming

    @AppStorage("udid") private var udid = ""
    @AppStorage("installAfterSign") private var installAfter = false
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("closeOnInstall") private var closeOnInstall = true
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("suffix") private var suffix = "-TGC"
    @AppStorage("exportFormat") private var exportFormat = "ipa"
    @AppStorage("injectPath") private var injectPath = "executable"
    @AppStorage("injectFolder") private var injectFolder = "frameworks"

    @State private var message: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    NavigationLink {
                        CertificatesView(certs: certs, incoming: incoming)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Certificados").font(.headline)
                            Text(udid.isEmpty ? "UDID sin definir" : "UDID: \(udid)")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                }

                Section("UDID de este iPhone") {
                    TextField("Pega aquí tu UDID", text: $udid)
                        .font(.system(.body, design: .monospaced))
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                    if !udid.isEmpty {
                        Button { UIPasteboard.general.string = udid; message = "UDID copiado." } label: {
                            Label("Copiar UDID", systemImage: "doc.on.doc")
                        }
                    }
                    Text("Con tu UDID, la app avisa si un certificado no incluye este iPhone.")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("General") {
                    NavigationLink { AppearanceView() } label: { Label("Apariencia e icono", systemImage: "circle.lefthalf.filled") }
                }

                UpdateSettingsSection(certs: certs)

                Section("Opciones de firma") {
                    SignModePicker()
                    SignToggles()
                }

                Section("Firmado") {
                    Picker("Compresión", selection: $compression) {
                        Text("Rápida").tag(0)
                        Text("Estándar").tag(1)
                    }
                    .pickerStyle(.segmented)
                    Picker("Formato de exportación", selection: $exportFormat) {
                        Text("IPA").tag("ipa")
                        Text("TIPA").tag("tipa")
                    }
                    .pickerStyle(.segmented)
                    Toggle("Borrar el IPA tras instalar", isOn: $autoDelete)
                    Toggle("Cerrar AZASing al instalar", isOn: $closeOnInstall)
                    LabeledContent("Sufijo") {
                        TextField("-TGC", text: $suffix).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                }

                Section("Avanzado") {
                  DisclosureGroup("Inyección de librerías") {
                    Picker("Ruta", selection: $injectPath) {
                        Text("@executable_path").tag("executable")
                        Text("@rpath").tag("rpath")
                    }
                    .pickerStyle(.segmented)
                    Picker("Carpeta", selection: $injectFolder) {
                        Text("/").tag("root")
                        Text("Frameworks/").tag("frameworks")
                    }
                    .pickerStyle(.segmented)
                  }
                }

                Section("Comunidad") {
                    if let url = URL(string: "https://t.me/Zfull27") {
                        Link(destination: url) {
                            Label("Telegram · @Zfull27", systemImage: "paperplane.fill")
                        }
                    }
                }

                Section("Acerca de") {
                    LabeledContent("Desarrollado por", value: "AZA")
                    if let url = URL(string: "https://t.me/taegc24") {
                        Link(destination: url) {
                            LabeledContent("Colaborador", value: "@taegc24")
                        }
                    }
                    if let url = URL(string: AboutInfo.website), !AboutInfo.website.isEmpty {
                        Link(destination: url) {
                            Label("Página web", systemImage: "globe")
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .keyboardDone()
            .background(AppBackground())
            .navigationTitle("Ajustes")
            .sheet(isPresented: $incoming.showAddCert) { AddCertificateView(certs: certs, incoming: incoming) }
            .alert("AZASing", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }
}

struct AppearanceView: View {
    @AppStorage("accentHex") private var accentHex = "FFC733"
    @AppStorage("appearance") private var appearance = 0
    @State private var currentIcon = UIApplication.shared.alternateIconName
    @State private var message: String?

    private let icons: [(title: String, name: String?, preview: String)] = [
        ("Dorado", nil, "PrevDorado"), ("Plata", "IconPlata", "PrevPlata"), ("Rosa", "IconRosa", "PrevRosa")
    ]

    var body: some View {
        Form {
            Section("Apariencia") {
                Picker("Tema", selection: $appearance) {
                    Text("Sistema").tag(0)
                    Text("Claro").tag(1)
                    Text("Oscuro").tag(2)
                }
                .pickerStyle(.segmented)
                Text("El fondo es negro en oscuro y blanco en claro. El icono dorado también cambia con el tema del iPhone.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Color de acento") {
                ColorPicker("Color", selection: Binding(get: { Color(hex: accentHex) },
                                                        set: { accentHex = $0.hexString }), supportsOpacity: false)
                Button("Restablecer") { accentHex = "FFC733" }
            }
            Section("Icono de la app") {
                HStack(spacing: 18) {
                    ForEach(icons, id: \.title) { icon in
                        Button { setIcon(icon.name) } label: {
                            VStack(spacing: 6) {
                                Image(icon.preview).resizable().scaledToFit().frame(width: 74, height: 74)
                                    .clipShape(RoundedRectangle(cornerRadius: 17))
                                    .overlay(RoundedRectangle(cornerRadius: 17)
                                        .stroke(currentIcon == icon.name ? Color.gold : .clear, lineWidth: 3))
                                Text(icon.title).font(.caption)
                                    .foregroundColor(currentIcon == icon.name ? .gold : .secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .frame(maxWidth: .infinity)
                Text("El dorado cambia solo entre claro, oscuro y tintado según el sistema. Plata y rosa son fijos.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .scrollContentBackground(.hidden)
        .keyboardDone()
        .background(AppBackground())
        .navigationTitle("Apariencia e icono")
        .alert("AZASing", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(message ?? "") }
    }

    private func setIcon(_ name: String?) {
        UIApplication.shared.setAlternateIconName(name) { error in
            DispatchQueue.main.async {
                if let error { message = "No se pudo cambiar el icono: \(error.localizedDescription)" }
                else { currentIcon = name }
            }
        }
    }
}
