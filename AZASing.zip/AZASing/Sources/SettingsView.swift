import SwiftUI

struct SettingsView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming

    @AppStorage("udid") private var udid = ""
    @AppStorage("installAfterSign") private var installAfter = true
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("appendSuffix") private var appendSuffix = true
    @AppStorage("exportFormat") private var exportFormat = "ipa"

    @State private var trustOK: Bool?
    @State private var trustReason = ""
    @State private var message: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    NavigationLink {
                        CertificatesView(certs: certs, incoming: incoming)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Certificados").font(.headline)
                            Text(udid.isEmpty ? "UDID sin detectar" : "UDID: \(udid)")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                    Button { Task { message = await LocalInstall.detectUDID { _ in } } } label: {
                        Label("Detectar UDID de este iPhone", systemImage: "iphone.gen3")
                    }
                    if !udid.isEmpty {
                        Button { UIPasteboard.general.string = udid; message = "UDID copiado." } label: {
                            Label("Copiar UDID", systemImage: "doc.on.doc")
                        }
                    }
                }

                Section("General") {
                    NavigationLink { AppearanceView() } label: { Label("Apariencia e icono", systemImage: "circle.lefthalf.filled") }
                }

                Section("Servicio de instalación") {
                    HStack(spacing: 12) {
                        Image(systemName: "largecircle.fill.circle").foregroundColor(.gold)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Instalación local").font(.headline)
                            Text("Totalmente sin conexión, no necesita internet.").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "circle").foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Servidor").font(.headline).foregroundStyle(.secondary)
                            Text("Próximamente.").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    HStack(spacing: 10) {
                        Image(systemName: trustOK == true ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                            .foregroundColor(trustOK == true ? .green : .orange)
                        Text(trustOK == nil ? "Comprobando…" : (trustOK == true ? "Certificado local listo" : "iOS aún no confía en el certificado local"))
                            .font(.subheadline)
                    }
                    if trustOK == false, !trustReason.isEmpty {
                        Text(trustReason).font(.caption).foregroundStyle(.secondary)
                    }
                    Button("Instalar certificado local") { Task { message = await LocalInstall.setupCertificate() } }
                    Button("Comprobar de nuevo") { Task { await check() } }
                    Text("1. Toca «Instalar certificado local» y permite la descarga.\n2. Ajustes › Perfil descargado › Instalar.\n3. Ajustes › General › Información › Ajustes de confianza de certificados: activa «AZASing Local CA».\n4. Vuelve aquí y toca «Comprobar de nuevo».")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("Firmado") {
                    Picker("Compresión", selection: $compression) {
                        Text("Rápida").tag(0)
                        Text("Estándar").tag(1)
                    }
                    .pickerStyle(.segmented)
                    Picker("Formato de exportación", selection: $exportFormat) {
                        Text("IPA").tag("ipa")
                        Text("TIPA").tag("tipa")
                    }
                    .pickerStyle(.segmented)
                    Toggle("Instalar después de firmar", isOn: $installAfter)
                    Toggle("Borrar el IPA tras instalar", isOn: $autoDelete)
                    Toggle("Quitar esquemas URL", isOn: $removeURLs)
                    Toggle("Quitar Apple Watch", isOn: $removeWatch)
                    Toggle("Añadir sufijo -AZASing al archivo", isOn: $appendSuffix)
                }

                Section("Comunidad") {
                    if let url = URL(string: "https://t.me/Zfull27") {
                        Link(destination: url) {
                            Label("Telegram · @Zfull27", systemImage: "paperplane.fill")
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Ajustes")
            .task { await check() }
            .sheet(isPresented: $incoming.showAddCert) { AddCertificateView(certs: certs, incoming: incoming) }
            .alert("AZASing", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func check() async {
        trustOK = nil
        do {
            try await LocalServer.shared.startIfNeeded()
            let r = LocalServer.shared.trustReport()
            trustOK = r.ok
            trustReason = r.reason
        } catch {
            trustOK = false
            trustReason = error.localizedDescription
        }
    }
}

struct AppearanceView: View {
    @AppStorage("accentHex") private var accentHex = "FFC733"
    @State private var currentIcon = UIApplication.shared.alternateIconName
    @State private var message: String?

    private let icons: [(title: String, name: String?, preview: String)] = [
        ("Dorado", nil, "PrevDorado"), ("Plata", "IconPlata", "PrevPlata"), ("Rosa", "IconRosa", "PrevRosa")
    ]

    var body: some View {
        Form {
            Section("Color de acento") {
                ColorPicker("Color", selection: Binding(get: { Color(hex: accentHex) },
                                                        set: { accentHex = $0.hexString }), supportsOpacity: false)
                Button("Restablecer") { accentHex = "FFC733" }
            }
            Section("Icono de la app") {
                HStack(spacing: 18) {
                    ForEach(icons, id: \.title) { icon in
                        Button { setIcon(icon.name) } label: {
                            VStack(spacing: 6) {
                                Image(icon.preview).resizable().scaledToFit().frame(width: 74, height: 74)
                                    .clipShape(RoundedRectangle(cornerRadius: 17))
                                    .overlay(RoundedRectangle(cornerRadius: 17)
                                        .stroke(currentIcon == icon.name ? Color.gold : .clear, lineWidth: 3))
                                Text(icon.title).font(.caption)
                                    .foregroundColor(currentIcon == icon.name ? .gold : .secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("Apariencia e icono")
        .alert("AZASing", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(message ?? "") }
    }

    private func setIcon(_ name: String?) {
        UIApplication.shared.setAlternateIconName(name) { error in
            DispatchQueue.main.async {
                if let error { message = "No se pudo cambiar el icono: \(error.localizedDescription)" }
                else { currentIcon = name }
            }
        }
    }
}
