import Foundation
import Zsign

// ⚠️ ESTE ES EL ÚNICO ARCHIVO QUE DEPENDE DE LA LIBRERÍA DE FIRMADO.
// Si el primer build falla aquí, solo hay que ajustar la llamada a Zsign
// (nombre del módulo o de los parámetros) según el README del paquete.

enum SignError: LocalizedError {
    case invalidIPA, engine(String)
    var errorDescription: String? {
        switch self {
        case .invalidIPA: return "El IPA no es válido (no se encontró Payload/*.app)."
        case .engine(let m): return "Error al firmar: \(m)"
        }
    }
}

enum ZsignEngine {
    static func sign(appPath: String, p12Path: String, password: String, provisionPath: String) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            Zsign.sign(appPath: appPath,
                       provisionPath: provisionPath,
                       p12Path: p12Path,
                       p12Password: password,
                       entitlementsPath: "",
                       removeProvision: false) { success, error in
                if success {
                    cont.resume()
                } else {
                    cont.resume(throwing: SignError.engine(error?.localizedDescription ?? "zsign devolvió un error"))
                }
            }
        }
    }
}
