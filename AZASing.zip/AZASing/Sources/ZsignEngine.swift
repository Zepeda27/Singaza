import Foundation
import ZSign

// Motor de firmado: paquete zwsn/zsign-ios (zsign + OpenSSL incluido).
// Este es el único archivo que depende de esa librería.

enum SignError: LocalizedError {
    case invalidIPA, engine(String)
    var errorDescription: String? {
        switch self {
        case .invalidIPA: return "El IPA no es válido (no se encontró Payload/*.app)."
        case .engine(let m): return "Error al firmar: \(m)"
        }
    }
}

enum ZsignEngine {
    /// Firma la carpeta .app en el lugar. Devuelve sin error si zsign responde 0.
    static func sign(appPath: String, p12Path: String, password: String, provisionPath: String) async throws {
        let code = zsign(appPath, p12Path, p12Path, provisionPath, password)
        guard code == 0 else {
            throw SignError.engine("zsign devolvió el código \(code). Revisa la contraseña del .p12 y que el perfil coincida con el certificado.")
        }
    }
}
