import Foundation

struct FileItem: Identifiable, Hashable {
    let url: URL
    let size: Int64
    let date: Date
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

@MainActor
final class FileStore: ObservableObject {
    let folder: Folder
    @Published private(set) var items: [FileItem] = []
    @Published private(set) var metas: [URL: AppMeta] = [:]
    @Published var notice: String?

    init(_ folder: Folder) {
        self.folder = folder
        refresh()
    }

    func refresh() {
        let keys: [URLResourceKey] = [.fileSizeKey, .contentModificationDateKey]
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: folder.url, includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles])) ?? []
        items = urls.map { u in
            let v = try? u.resourceValues(forKeys: Set(keys))
            return FileItem(url: u, size: Int64(v?.fileSize ?? 0),
                            date: v?.contentModificationDate ?? .distantPast)
        }.sorted { $0.date > $1.date }
        loadMetas()
    }

    private func loadMetas() {
        guard folder == .ipas || folder == .signed else { return }
        let urls = items.map(\.url).filter { metas[$0] == nil }
        guard !urls.isEmpty else { return }
        Task.detached {
            var out: [URL: AppMeta] = [:]
            for u in urls { if let m = IPAReader.read(u) { out[u] = m } }
            await MainActor.run { self.metas.merge(out) { $1 } }
        }
    }

    /// Copia archivos elegidos desde el selector de Archivos.
    func importFiles(_ urls: [URL]) {
        let fm = FileManager.default
        var ok = 0
        var failure: String?
        for src in urls {
            let scoped = src.startAccessingSecurityScopedResource()
            defer { if scoped { src.stopAccessingSecurityScopedResource() } }
            let dest = uniqueURL(for: src.lastPathComponent)
            do {
                if src.path.contains("/tmp/") { try fm.moveItem(at: src, to: dest) }
                else { try fm.copyItem(at: src, to: dest) }
                ok += 1
            } catch {
                failure = "\(src.lastPathComponent): \(error.localizedDescription)"
            }
        }
        notice = failure.map { "No se pudo importar. \($0)" } ?? "Importado: \(ok) archivo(s)."
        refresh()
    }

    func delete(_ item: FileItem) {
        try? FileManager.default.removeItem(at: item.url)
        refresh()
    }

    func rename(_ item: FileItem, to newName: String) {
        let clean = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, clean != item.name else { return }
        let dest = folder.url.appendingPathComponent(clean)
        guard !FileManager.default.fileExists(atPath: dest.path) else { return }
        try? FileManager.default.moveItem(at: item.url, to: dest)
        refresh()
    }

    private func uniqueURL(for name: String) -> URL {
        let fm = FileManager.default
        var url = folder.url.appendingPathComponent(name)
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 1
        while fm.fileExists(atPath: url.path) {
            let newName = ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)"
            url = folder.url.appendingPathComponent(newName)
            n += 1
        }
        return url
    }
}
