import SwiftUI
import UIKit

/// Envío de IPA a Telegram con portada (miniatura = icono de la app), usando un bot propio.
enum TelegramSender {
    struct Failure: LocalizedError { let message: String; var errorDescription: String? { message } }

    static var token: String { Keychain.get("tgToken") ?? "" }
    static var chat: String { UserDefaults.standard.string(forKey: "tgChat") ?? "" }
    static var configured: Bool { !token.isEmpty && !chat.trimmingCharacters(in: .whitespaces).isEmpty }

    static func send(file: URL, caption: String, icon: UIImage?) async throws {
        let size = (try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        if size > 50 * 1024 * 1024 {
            throw Failure(message: "El archivo pesa más de 50 MB, el límite de los bots de Telegram.")
        }
        let boundary = "azasing-" + UUID().uuidString
        let body = FileManager.default.temporaryDirectory.appendingPathComponent("tg-\(UUID().uuidString).body")
        FileManager.default.createFile(atPath: body.path, contents: nil)
        let out = try FileHandle(forWritingTo: body)
        defer { try? out.close(); try? FileManager.default.removeItem(at: body) }

        func text(_ name: String, _ value: String) {
            out.write(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n".utf8))
        }
        text("chat_id", chat.trimmingCharacters(in: .whitespaces))
        text("caption", caption)
        text("disable_content_type_detection", "true")

        if let icon, let jpg = thumbnail(icon) {
            text("thumbnail", "attach://cover")
            out.write(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"cover\"; filename=\"cover.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".utf8))
            out.write(jpg)
            out.write(Data("\r\n".utf8))
        }

        out.write(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"document\"; filename=\"\(file.lastPathComponent)\"\r\nContent-Type: application/octet-stream\r\n\r\n".utf8))
        let src = try FileHandle(forReadingFrom: file)
        defer { try? src.close() }
        while let chunk = try src.read(upToCount: 1_048_576), !chunk.isEmpty { out.write(chunk) }
        out.write(Data("\r\n--\(boundary)--\r\n".utf8))
        try out.synchronize()

        var req = URLRequest(url: URL(string: "https://api.telegram.org/bot\(token)/sendDocument")!)
        req.httpMethod = "POST"
        req.timeoutInterval = 900
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        let (data, _) = try await URLSession.shared.upload(for: req, fromFile: body)
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        if json?["ok"] as? Bool != true {
            throw Failure(message: (json?["description"] as? String) ?? "Telegram no aceptó el archivo.")
        }
    }

    /// Portada: JPEG de hasta 320 px y menos de 200 KB (requisito de Telegram).
    private static func thumbnail(_ image: UIImage) -> Data? {
        let side: CGFloat = 320
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: fmt).image { _ in
            UIColor.black.setFill(); UIRectFill(CGRect(x: 0, y: 0, width: side, height: side))
            image.draw(in: CGRect(x: 0, y: 0, width: side, height: side))
        }
        var q: CGFloat = 0.85
        while q > 0.3 {
            if let d = img.jpegData(compressionQuality: q), d.count < 200_000 { return d }
            q -= 0.15
        }
        return img.jpegData(compressionQuality: 0.3)
    }
}

enum TelegramUI {
    @MainActor
    static func send(_ url: URL) async {
        guard let top = UIKitBridge.topViewController() else { return }
        guard TelegramSender.configured else {
            info("Telegram", "Configura tu bot en Ajustes › Telegram (token y chat ID).")
            return
        }
        let meta = IPAReader.read(url)
        let caption = [meta?.name, meta.map { $0.version.isEmpty ? "" : "v\($0.version)" }, meta?.bundleID]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: "\n")
        let wait = UIAlertController(title: "Enviando a Telegram…", message: "\(url.lastPathComponent)\nNo cierres la app.", preferredStyle: .alert)
        top.present(wait, animated: true)
        do {
            try await TelegramSender.send(file: url, caption: caption.isEmpty ? url.lastPathComponent : caption, icon: meta?.icon)
            wait.dismiss(animated: true) { info("Telegram", "Enviado con portada.") }
        } catch {
            wait.dismiss(animated: true) { info("Telegram", "No se pudo enviar: \(error.localizedDescription)") }
        }
    }

    @MainActor
    private static func info(_ title: String, _ text: String) {
        guard let top = UIKitBridge.topViewController() else { return }
        let a = UIAlertController(title: title, message: text, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default))
        top.present(a, animated: true)
    }
}

/// Aparece en la hoja de compartir cuando se comparte un IPA.
final class TelegramActivity: UIActivity {
    private var urls: [URL] = []
    override class var activityCategory: UIActivity.Category { .action }
    override var activityType: UIActivity.ActivityType? { UIActivity.ActivityType("com.azasing.telegram") }
    override var activityTitle: String? { "Telegram con portada" }
    override var activityImage: UIImage? { UIImage(systemName: "paperplane.fill") }

    private func isIPA(_ u: URL) -> Bool { ["ipa", "tipa"].contains(u.pathExtension.lowercased()) }
    override func canPerform(withActivityItems items: [Any]) -> Bool { items.contains { ($0 as? URL).map(isIPA) ?? false } }
    override func prepare(withActivityItems items: [Any]) { urls = items.compactMap { $0 as? URL }.filter(isIPA) }
    override func perform() {
        let list = urls
        activityDidFinish(true)
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 700_000_000)
            for u in list { await TelegramUI.send(u) }
        }
    }
}
