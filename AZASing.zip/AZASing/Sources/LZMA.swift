import Foundation

/// Descompresor LZMA / XZ (LZMA2) en Swift puro, para leer .deb con data.tar.lzma o data.tar.xz.
enum LZMA {
    struct Failure: LocalizedError {
        let message: String
        init(_ m: String) { message = m }
        var errorDescription: String? { message }
    }

    /// Formato antiguo «.lzma» (LZMA-alone).
    static func decodeAlone(_ data: Data) throws -> Data {
        let d = [UInt8](data)
        guard d.count > 13 else { throw Failure("Datos lzma no válidos.") }
        let dec = Decoder()
        try dec.setProps(d[0])
        dec.resetState()
        var size: UInt64 = 0
        for i in 0..<8 { size |= UInt64(d[5 + i]) << UInt64(8 * i) }
        let known = size != UInt64.max
        try dec.chunk(d, start: 13, end: d.count, unpacked: known ? Int(size) : nil)
        return Data(dec.out)
    }

    /// Formato «.xz» con filtro LZMA2.
    static func decodeXZ(_ data: Data) throws -> Data {
        let d = [UInt8](data)
        guard d.count > 32, d[0] == 0xFD, d[1] == 0x37, d[2] == 0x7A, d[3] == 0x58, d[4] == 0x5A, d[5] == 0 else {
            throw Failure("Datos xz no válidos.")
        }
        let checkSizes: [UInt8: Int] = [0: 0, 1: 4, 4: 8, 10: 32]
        guard let checkLen = checkSizes[d[7] & 0x0F] else { throw Failure("xz: tipo de comprobación no soportado.") }
        let dec = Decoder()
        var p = 12

        func varint(_ q: inout Int) throws -> Int {
            var v = 0, shift = 0
            while true {
                guard q < d.count, shift < 63 else { throw Failure("xz dañado.") }
                let b = d[q]; q += 1
                v |= Int(b & 0x7F) << shift; shift += 7
                if b < 0x80 { return v }
            }
        }

        while p < d.count, d[p] != 0 {
            let blockStart = p
            let headerSize = (Int(d[p]) + 1) * 4
            guard p + headerSize <= d.count else { throw Failure("xz dañado.") }
            let flags = d[p + 1]
            var q = p + 2
            if flags & 0x40 != 0 { _ = try varint(&q) }
            if flags & 0x80 != 0 { _ = try varint(&q) }
            for _ in 0..<(Int(flags & 3) + 1) {
                let id = try varint(&q)
                let psz = try varint(&q)
                q += psz
                if id != 0x21 { throw Failure("Este .xz usa un filtro (\(String(id, radix: 16))) que no se soporta.") }
            }
            p += headerSize
            while true {
                guard p < d.count else { throw Failure("xz truncado.") }
                let c = d[p]
                if c == 0 { p += 1; break }
                if c == 1 || c == 2 {
                    guard p + 3 <= d.count else { throw Failure("xz truncado.") }
                    let sz = ((Int(d[p + 1]) << 8) | Int(d[p + 2])) + 1
                    p += 3
                    guard p + sz <= d.count else { throw Failure("xz truncado.") }
                    dec.out.append(contentsOf: d[p..<(p + sz)])
                    p += sz
                    continue
                }
                guard c >= 0x80, p + 5 <= d.count else { throw Failure("xz dañado.") }
                let unpacked = (((Int(c) & 0x1F) << 16) | (Int(d[p + 1]) << 8) | Int(d[p + 2])) + 1
                let packed = ((Int(d[p + 3]) << 8) | Int(d[p + 4])) + 1
                p += 5
                let mode = (c >> 5) & 3
                if mode >= 2 {
                    guard p < d.count else { throw Failure("xz truncado.") }
                    try dec.setProps(d[p]); p += 1
                }
                if mode >= 1 { dec.resetState() }
                guard p + packed <= d.count else { throw Failure("xz truncado.") }
                try dec.chunk(d, start: p, end: p + packed, unpacked: unpacked)
                p += packed
            }
            p += (4 - (p - blockStart) % 4) % 4
            p += checkLen
        }
        return Data(dec.out)
    }

    // MARK: - Decodificador

    private final class Decoder {
        var out: [UInt8] = []
        var lc = 0, lp = 0, pb = 0
        var probs: [UInt16] = []
        var state = 0
        var r0 = 0, r1 = 0, r2 = 0, r3 = 0

        // Posiciones dentro de `probs`
        let isMatch = 0, isRep = 192, g0 = 204, g1 = 216, g2 = 228, rep0Long = 240
        let posSlot = 432, posDec = 688, align = 803
        let lenBase = 819, repLenBase = 1333, literal = 1847

        // Codificador de rango
        var code: UInt32 = 0, range: UInt32 = 0
        var data: [UInt8] = [], pos = 0, end = 0

        func setProps(_ b: UInt8) throws {
            var d = Int(b)
            guard d < 225 else { throw Failure("lzma: propiedades no válidas.") }
            lc = d % 9; d /= 9
            lp = d % 5; pb = d / 5
        }

        func resetState() {
            probs = [UInt16](repeating: 1024, count: literal + (0x300 << (lc + lp)))
            state = 0; r0 = 0; r1 = 0; r2 = 0; r3 = 0
        }

        @inline(__always) private func normalize() {
            if range < (1 << 24) {
                range <<= 8
                let b: UInt32 = pos < end ? UInt32(data[pos]) : 0
                code = (code << 8) | b
                pos += 1
            }
        }

        @inline(__always) private func bit(_ i: Int) -> Int {
            let p = UInt32(probs[i])
            let bound = (range >> 11) &* p
            var r: Int
            if code < bound {
                range = bound
                probs[i] = UInt16(p + ((2048 - p) >> 5))
                r = 0
            } else {
                range -= bound
                code -= bound
                probs[i] = UInt16(p - (p >> 5))
                r = 1
            }
            normalize()
            return r
        }

        private func direct(_ n: Int) -> UInt32 {
            var res: UInt32 = 0
            for _ in 0..<n {
                range >>= 1
                code = code &- range
                let t: UInt32 = 0 &- (code >> 31)
                code = code &+ (range & t)
                normalize()
                res = (res << 1) &+ (t &+ 1)
            }
            return res
        }

        private func tree(_ base: Int, _ nb: Int) -> Int {
            var m = 1
            for _ in 0..<nb { m = (m << 1) + bit(base + m) }
            return m - (1 << nb)
        }

        private func rtree(_ base: Int, _ nb: Int) -> Int {
            var m = 1, sym = 0
            for i in 0..<nb {
                let b = bit(base + m)
                m = (m << 1) + b
                sym |= b << i
            }
            return sym
        }

        private func length(_ base: Int, _ ps: Int) -> Int {
            if bit(base) == 0 { return tree(base + 2 + (ps << 3), 3) }
            if bit(base + 1) == 0 { return 8 + tree(base + 2 + 128 + (ps << 3), 3) }
            return 16 + tree(base + 2 + 256, 8)
        }

        /// Decodifica `unpacked` bytes (o hasta la marca de fin si es nil) desde data[start..<end].
        func chunk(_ input: [UInt8], start: Int, end e: Int, unpacked: Int?) throws {
            data = input; pos = start; end = e
            guard pos + 5 <= end, data[pos] == 0 else { throw Failure("lzma dañado.") }
            code = (UInt32(data[pos + 1]) << 24) | (UInt32(data[pos + 2]) << 16) | (UInt32(data[pos + 3]) << 8) | UInt32(data[pos + 4])
            pos += 5
            range = 0xFFFFFFFF
            let target = unpacked.map { out.count + $0 }
            let pbMask = (1 << pb) - 1, lpMask = (1 << lp) - 1
            if let t = target { out.reserveCapacity(t) }

            while target == nil || out.count < target! {
                let n = out.count
                let ps = n & pbMask
                if bit(isMatch + (state << 4) + ps) == 0 {
                    let prev = n > 0 ? Int(out[n - 1]) : 0
                    let base = literal + 0x300 * (((n & lpMask) << lc) + (prev >> (8 - lc)))
                    var sym = 1
                    if state >= 7 {
                        guard n > r0 else { throw Failure("lzma dañado.") }
                        var mb = Int(out[n - r0 - 1])
                        while sym < 0x100 {
                            let mbit = (mb >> 7) & 1
                            mb = (mb << 1) & 0xFF
                            let b = bit(base + ((1 + mbit) << 8) + sym)
                            sym = (sym << 1) | b
                            if mbit != b { break }
                        }
                    }
                    while sym < 0x100 { sym = (sym << 1) | bit(base + sym) }
                    out.append(UInt8(truncatingIfNeeded: sym))
                    state = state < 4 ? 0 : (state < 10 ? state - 3 : state - 6)
                    continue
                }
                var len: Int
                if bit(isRep + state) != 0 {
                    guard n > 0 else { throw Failure("lzma dañado.") }
                    if bit(g0 + state) == 0 {
                        if bit(rep0Long + (state << 4) + ps) == 0 {
                            guard n > r0 else { throw Failure("lzma dañado.") }
                            state = state < 7 ? 9 : 11
                            out.append(out[n - r0 - 1])
                            continue
                        }
                    } else {
                        var dist: Int
                        if bit(g1 + state) == 0 { dist = r1 }
                        else {
                            if bit(g2 + state) == 0 { dist = r2 }
                            else { dist = r3; r3 = r2 }
                            r2 = r1
                        }
                        r1 = r0; r0 = dist
                    }
                    len = length(repLenBase, ps)
                    state = state < 7 ? 8 : 11
                } else {
                    r3 = r2; r2 = r1; r1 = r0
                    len = length(lenBase, ps)
                    state = state < 7 ? 7 : 10
                    let ls = min(len, 3)
                    let slot = tree(posSlot + (ls << 6), 6)
                    var dist: Int
                    if slot < 4 { dist = slot }
                    else {
                        let nd = (slot >> 1) - 1
                        dist = (2 | (slot & 1)) << nd
                        if slot < 14 { dist += rtree(posDec + dist - slot, nd) }
                        else {
                            dist += Int(direct(nd - 4)) << 4
                            dist += rtree(align, 4)
                        }
                    }
                    r0 = dist
                    if r0 == 0xFFFFFFFF { return }   // marca de fin
                }
                len += 2
                guard r0 < n else { throw Failure("lzma dañado (distancia no válida).") }
                if let t = target, len > t - n { len = t - n }
                var src = n - r0 - 1
                for _ in 0..<len { out.append(out[src]); src += 1 }
            }
        }
    }
}
