import SwiftUI

@MainActor
final class SignModel: ObservableObject {
    @Published var log = ""
    @Published var busy = false
    @Published var result: URL?

    func run(_ options: SignOptions, signed: FileStore) {
        busy = true
        log = ""
        result = nil
        Task {
            do {
                let url = try await Signer.run(options, outputFolder: Folder.signed.url) { [weak self] msg in
                    self?.log += msg + "\n"
                }
                result = url
                log += "Listo: \(url.lastPathComponent)\n"
                signed.refresh()
            } catch {
                log += "Error: \(error.localizedDescription)\n"
            }
            busy = false
        }
    }
}

struct SignView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore

    @StateObject private var model = SignModel()
    @State private var ipa: FileItem?
    @State private var certID: UUID?
    @State private var chosenTweaks = Set<URL>()
    @State private var bundleID = ""
    @State private var displayName = ""
    @State private var version = ""

    private var selectedCert: Certificate? { certs.items.first { $0.id == certID } }
    private var canSign: Bool { ipa != nil && selectedCert != nil && !model.busy }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Image("Logo").resizable().scaledToFit()
                        .frame(maxWidth: .infinity).listRowBackground(Color.black)
                }

                Section("App") {
                    Picker("IPA", selection: $ipa) {
                        Text("Elegir…").tag(FileItem?.none)
                        ForEach(ipas.items) { Text($0.name).tag(Optional($0)) }
                    }
                    if ipas.items.isEmpty {
                        Text("Importa un IPA en la pestaña Archivos.").font(.footnote).foregroundStyle(.secondary)
                    }
                }

                Section("Certificado") {
                    Picker("Certificado", selection: $certID) {
                        Text("Elegir…").tag(UUID?.none)
                        ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                    }
                    if certs.items.isEmpty {
                        Text("Agrega un certificado en la pestaña Certificados.").font(.footnote).foregroundStyle(.secondary)
                    }
                    if selectedCert?.isExpired == true {
                        Label("Este certificado está caducado.", systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                Section("Tweaks a inyectar") {
                    if tweaks.items.isEmpty {
                        Text("Importa .dylib o .framework en Archivos › Tweaks.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(tweaks.items) { t in
                        Toggle(t.name, isOn: Binding(
                            get: { chosenTweaks.contains(t.url) },
                            set: { on in if on { chosenTweaks.insert(t.url) } else { chosenTweaks.remove(t.url) } }))
                    }
                }

                Section("Opciones (opcional)") {
                    TextField("Bundle ID nuevo", text: $bundleID)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Nombre de la app", text: $displayName)
                    TextField("Versión", text: $version)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }

                Section {
                    Button(model.busy ? "Firmando…" : "Firmar") { sign() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(!canSign)
                        .listRowBackground(Color.clear)
                    if model.busy { ProgressView().frame(maxWidth: .infinity) }
                }

                if !model.log.isEmpty {
                    Section("Registro") {
                        Text(model.log).font(.system(.footnote, design: .monospaced))
                        if let url = model.result {
                            ShareLink(item: url) { Label("Compartir IPA firmado", systemImage: "square.and.arrow.up") }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("AZASing")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                if certID == nil { certID = certs.defaultID ?? certs.items.first?.id }
            }
        }
    }

    private func sign() {
        guard let ipa, let cert = selectedCert else { return }
        let selected = tweaks.items.map(\.url).filter { chosenTweaks.contains($0) }
        model.run(SignOptions(ipa: ipa.url, cert: cert, tweaks: selected,
                              bundleID: bundleID.trimmingCharacters(in: .whitespaces),
                              displayName: displayName.trimmingCharacters(in: .whitespaces),
                              version: version.trimmingCharacters(in: .whitespaces)),
                  signed: signed)
    }
}
