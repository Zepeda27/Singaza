import SwiftUI
import UniformTypeIdentifiers

// MARK: - Modelo de firmado

@MainActor
final class SignModel: ObservableObject {
    @Published var log = ""
    @Published var busy = false
    @Published var result: URL?

    func run(_ options: SignOptions, signed: FileStore, onDone: @escaping (URL) -> Void = { _ in }) {
        busy = true
        log = ""
        result = nil
        Task {
            do {
                let url = try await Signer.run(options, outputFolder: Folder.signed.url) { [weak self] msg in
                    self?.log += msg + "\n"
                }
                result = url
                log += "Listo: \(url.lastPathComponent)\n"
                signed.refresh()
                onDone(url)
            } catch {
                log += "Error: \(error.localizedDescription)\n"
            }
            busy = false
        }
    }
}

// MARK: - Tarjeta de app

struct Pill: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(Color.gold.opacity(0.15))
            .foregroundColor(.gold)
            .clipShape(Capsule())
    }
}

struct ProjectCard<Accessory: View>: View {
    let item: FileItem
    let meta: AppMeta?
    @ViewBuilder var accessory: () -> Accessory

    var body: some View {
        HStack(spacing: 14) {
            Group {
                if let icon = meta?.icon {
                    Image(uiImage: icon).resizable().scaledToFill()
                } else {
                    Image(systemName: "app.dashed").font(.title).foregroundColor(.gold)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.black)
                }
            }
            .frame(width: 62, height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(meta?.name ?? item.name).font(.headline).lineLimit(1)
                Text(meta?.bundleID ?? item.name)
                    .font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 6) {
                    if let v = meta?.version, !v.isEmpty { Pill(text: "v\(v)") }
                    Pill(text: ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                }
            }
            Spacer(minLength: 0)
            accessory()
        }
        .padding(14)
        .glassCard(cornerRadius: 22)
    }
}

// MARK: - Pestaña Proyectos (IPAs importados)

struct ProjectsView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore

    @State private var selected: FileItem?

    var body: some View {
        NavigationStack {
            ScrollView {
                if ipas.items.isEmpty {
                    VStack(spacing: 14) {
                        Image("Logo").resizable().scaledToFit().frame(maxWidth: 280)
                        Text("Importa un IPA con el botón +, o compártelo a AZASing desde Archivos, Safari o cualquier app.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .padding(.top, 60).padding(.horizontal, 30)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(ipas.items) { item in
                            Button { selected = item } label: {
                                ProjectCard(item: item, meta: ipas.metas[item.url]) {
                                    Image(systemName: "signature").foregroundColor(.gold).font(.title3)
                                }
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button(role: .destructive) { ipas.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(AppBackground())
            .navigationTitle("Proyectos")
            .toolbar {
                Button { DocPicker.present { ipas.importFiles($0) } } label: { Image(systemName: "plus") }
            }
            .sheet(item: $selected) { item in
                SignSheet(item: item, meta: ipas.metas[item.url], tweaks: tweaks, signed: signed, certs: certs)
            }
            .onAppear { ipas.refresh() }
            .alert("Importación", isPresented: Binding(get: { ipas.notice != nil },
                                                        set: { if !$0 { ipas.notice = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(ipas.notice ?? "") }
        }
    }
}

// MARK: - Plugins disponibles (Tweaks, incluidas subcarpetas)

enum TweakScanner {
    static func scan() -> [URL] {
        guard let en = FileManager.default.enumerator(at: Folder.tweaks.url, includingPropertiesForKeys: [.isDirectoryKey],
                                                      options: [.skipsHiddenFiles]) else { return [] }
        var out: [URL] = []
        for case let u as URL in en {
            let ext = u.pathExtension.lowercased()
            let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if isDir {
                if ["framework", "bundle"].contains(ext) { out.append(u); en.skipDescendants() }
            } else if ["dylib", "deb"].contains(ext) { out.append(u) }
        }
        return out.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }
}

struct KV: Identifiable, Hashable {
    let id = UUID()
    var key = ""
    var value = ""
}

struct KeyValueView: View {
    @Binding var items: [KV]
    var body: some View {
        List {
            ForEach($items) { $kv in
                VStack(alignment: .leading, spacing: 6) {
                    TextField("Clave (ej. UIFileSharingEnabled)", text: $kv.key)
                        .font(.caption.weight(.semibold)).foregroundColor(.gold)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Valor (texto, número, true o false)", text: $kv.value)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }
            }
            .onDelete { items.remove(atOffsets: $0) }
            Button { items.append(KV()) } label: { Label("Añadir clave", systemImage: "plus.circle") }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("Info.plist")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct RemoveLibrariesView: View {
    let ipa: URL
    @Binding var selection: Set<String>
    @State private var libs: [String]?

    var body: some View {
        List {
            if libs == nil { ProgressView().frame(maxWidth: .infinity) }
            if let libs, libs.isEmpty { Text("No se encontraron librerías propias en este IPA.").foregroundStyle(.secondary) }
            ForEach(libs ?? [], id: \.self) { lib in
                Toggle(isOn: Binding(get: { selection.contains(lib) },
                                     set: { on in if on { selection.insert(lib) } else { selection.remove(lib) } })) {
                    Text(lib).font(.system(.footnote, design: .monospaced))
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("Quitar librerías")
        .navigationBarTitleDisplayMode(.inline)
        .task { libs = await Task.detached { IPAReader.libraries(ipa) }.value }
    }
}

// MARK: - Hoja de firmado

struct SignSheet: View {
    let item: FileItem
    let meta: AppMeta?
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore
    @Environment(\.dismiss) private var dismiss

    @AppStorage("installAfterSign") private var installAfter = false
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("appendSuffix") private var appendSuffix = true
    @AppStorage("exportFormat") private var exportFormat = "ipa"
    @AppStorage("injectPath") private var injectPath = "executable"
    @AppStorage("injectFolder") private var injectFolder = "frameworks"

    @StateObject private var model = SignModel()
    @State private var certID: UUID?
    @State private var tweakList: [URL] = []
    @State private var chosen = Set<URL>()
    @State private var debItems: [URL: [DebKit.DebItem]] = [:]
    @State private var debOn: [URL: Set<String>] = [:]
    @State private var bundleID = ""
    @State private var displayName = ""
    @State private var version = ""
    @State private var outputName = ""
    @State private var note = ""
    @State private var newIcon: UIImage?
    @State private var newIconData: Data?
    @State private var removeLibs = Set<String>()
    @State private var extras: [KV] = []

    private var cert: Certificate? { certs.items.first { $0.id == certID } }
    private var noteKey: String { "note." + item.name }
    private var injectPreview: String {
        let prefix = injectPath == "rpath" ? "@rpath/" : (injectFolder == "frameworks" ? "@executable_path/Frameworks/" : "@executable_path/")
        return prefix + "xxx.dylib"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    ProjectCard(item: item, meta: meta) { EmptyView() }
                        .listRowBackground(Color.clear).listRowInsets(EdgeInsets())
                }

                Section("Certificado") {
                    Picker("Certificado", selection: $certID) {
                        Text("Elegir…").tag(UUID?.none)
                        ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                    }
                    if certs.items.isEmpty {
                        Text("Agrega un certificado en Ajustes › Certificados.").font(.footnote).foregroundStyle(.secondary)
                    }
                    if cert?.isExpired == true {
                        Label("Este certificado está caducado.", systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                Section("Editar (solo afecta al IPA firmado)") {
                    LabeledContent("Nombre") { TextField("Nombre de la app", text: $displayName).multilineTextAlignment(.trailing) }
                    LabeledContent("Bundle ID") {
                        TextField("Bundle ID", text: $bundleID).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    LabeledContent("Versión") {
                        TextField("Versión", text: $version).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                }

                Section("Logo") {
                    HStack(spacing: 14) {
                        Group {
                            if let img = newIcon ?? meta?.icon { Image(uiImage: img).resizable().scaledToFill() }
                            else { Image(systemName: "app.dashed").font(.title).foregroundColor(.gold) }
                        }
                        .frame(width: 58, height: 58).clipShape(RoundedRectangle(cornerRadius: 13))
                        Button("Cambiar logo") { pickIcon() }
                        Spacer()
                        if newIcon != nil { Button("Restaurar", role: .destructive) { newIcon = nil; newIconData = nil } }
                    }
                }

                Section("Librerías a inyectar (\(chosen.count))") {
                    Button { addLibrary() } label: { Label("Añadir librería (dylib, framework, deb)", systemImage: "plus.circle") }
                    if tweakList.isEmpty {
                        Text("Aún no hay librerías. Añade una o importa archivos en Archivos › Tweaks.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(tweakList, id: \.self) { t in
                        Toggle(isOn: Binding(get: { chosen.contains(t) }, set: { setTweak(t, $0) })) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(t.lastPathComponent)
                                if t.pathExtension.lowercased() == "deb", chosen.contains(t), debItems[t]?.isEmpty != false {
                                    Text("Leyendo contenido…").font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                        if t.pathExtension.lowercased() == "deb", chosen.contains(t), let inner = debItems[t], !inner.isEmpty {
                            ForEach(inner, id: \.self) { piece in
                                Toggle(isOn: Binding(get: { debOn[t]?.contains(piece.name) ?? true },
                                                     set: { setPiece(t, piece.name, $0) })) {
                                    Label(piece.name, systemImage: piece.kind == "dylib" ? "puzzlepiece.extension" : (piece.kind == "bundle" ? "shippingbox.fill" : "shippingbox"))
                                        .font(.subheadline)
                                }
                                .padding(.leading, 18)
                            }
                        }
                    }
                    NavigationLink { RemoveLibrariesView(ipa: item.url, selection: $removeLibs) } label: {
                        Label("Quitar librerías existentes (\(removeLibs.count))", systemImage: "minus.circle")
                    }
                }

                Section("Ajustes de inyección") {
                    Picker("Ruta", selection: $injectPath) {
                        Text("@executable_path").tag("executable")
                        Text("@rpath").tag("rpath")
                    }
                    .pickerStyle(.segmented)
                    Picker("Carpeta", selection: $injectFolder) {
                        Text("/").tag("root")
                        Text("Frameworks/").tag("frameworks")
                    }
                    .pickerStyle(.segmented)
                    Text(injectPreview).font(.system(.footnote, design: .monospaced)).foregroundStyle(.secondary)
                }

                Section("Info.plist") {
                    NavigationLink { KeyValueView(items: $extras) } label: {
                        Label("Añadir o reemplazar clave y valor (\(extras.filter { !$0.key.isEmpty }.count))", systemImage: "list.bullet.rectangle")
                    }
                }

                Section("Salida") {
                    LabeledContent("Archivo") {
                        TextField("Nombre del archivo", text: $outputName).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Picker("Formato", selection: $exportFormat) {
                        Text("IPA").tag("ipa")
                        Text("TIPA").tag("tipa")
                    }
                    .pickerStyle(.segmented)
                    Toggle("Instalar después de firmar", isOn: $installAfter)
                }

                Section("Nota del proyecto") {
                    TextField("Escribe una nota…", text: $note, axis: .vertical).lineLimit(1...4)
                }

                Section {
                    Button(model.busy ? "Firmando…" : (installAfter ? "Firmar e instalar" : "Firmar")) { sign() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(cert == nil || model.busy)
                        .listRowBackground(Color.clear)
                    if model.busy { ProgressView().frame(maxWidth: .infinity) }
                }

                if !model.log.isEmpty {
                    Section("Registro") {
                        Text(model.log).font(.system(.footnote, design: .monospaced))
                        if let url = model.result {
                            Button { install(url) } label: { Label("Instalar en este iPhone", systemImage: "arrow.down.app") }
                            ShareLink(item: url) { Label("Compartir IPA firmado", systemImage: "square.and.arrow.up") }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle(meta?.name ?? item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
            .onAppear {
                if certID == nil { certID = certs.defaultID ?? certs.items.first?.id }
                if displayName.isEmpty { displayName = meta?.name ?? "" }
                if bundleID.isEmpty { bundleID = meta?.bundleID ?? "" }
                if version.isEmpty { version = meta?.version ?? "" }
                if outputName.isEmpty {
                    let base = (meta?.name ?? item.url.deletingPathExtension().lastPathComponent)
                    outputName = version.isEmpty ? base : "\(base)_\(version)"
                }
                note = UserDefaults.standard.string(forKey: noteKey) ?? ""
                tweakList = TweakScanner.scan()
            }
            .onChange(of: note) { UserDefaults.standard.set($0, forKey: noteKey) }
        }
    }

    // MARK: Librerías

    private func addLibrary() {
        DocPicker.present { urls in
            let before = Set(TweakScanner.scan())
            tweaks.importFiles(urls)
            let after = TweakScanner.scan()
            tweakList = after
            for u in after where !before.contains(u) { setTweak(u, true) }
        }
    }

    private func setTweak(_ url: URL, _ on: Bool) {
        if on {
            chosen.insert(url)
            if url.pathExtension.lowercased() == "deb", debItems[url] == nil {
                Task {
                    let items = await Task.detached { DebKit.listItems(url) }.value
                    debItems[url] = items
                    if debOn[url] == nil { debOn[url] = Set(items.map(\.name)) }
                }
            }
        } else {
            chosen.remove(url)
        }
    }

    private func setPiece(_ deb: URL, _ name: String, _ on: Bool) {
        var s = debOn[deb] ?? Set((debItems[deb] ?? []).map(\.name))
        if on { s.insert(name) } else { s.remove(name) }
        debOn[deb] = s
    }

    private func pickIcon() {
        DocPicker.present(multiple: false) { urls in
            guard let u = urls.first, let d = try? Data(contentsOf: u), let img = UIImage(data: d) else { return }
            newIcon = img
            newIconData = d
        }
    }

    // MARK: Firmar

    private func sign() {
        guard let cert else { return }
        let trim: (String) -> String = { $0.trimmingCharacters(in: .whitespaces) }
        var debSel: [String: Set<String>] = [:]
        for t in chosen where t.pathExtension.lowercased() == "deb" {
            if let on = debOn[t], debItems[t]?.isEmpty == false { debSel[t.path] = on }
        }
        var extra: [String: String] = [:]
        for kv in extras where !trim(kv.key).isEmpty { extra[trim(kv.key)] = kv.value }
        let opts = SignOptions(ipa: item.url, cert: cert, tweaks: tweakList.filter { chosen.contains($0) },
                               bundleID: trim(bundleID), displayName: trim(displayName), version: trim(version),
                               removeURLSchemes: removeURLs, removeWatch: removeWatch,
                               compress: compression != 0, outputName: trim(outputName), appendSuffix: appendSuffix,
                               ext: exportFormat, iconData: newIconData, removeLibraries: removeLibs,
                               injectRPath: injectPath == "rpath", injectInFrameworks: injectFolder == "frameworks",
                               plistExtras: extra, debSelection: debSel)
        model.run(opts, signed: signed) { url in
            if installAfter { install(url) }
        }
    }

    private func install(_ url: URL) {
        Task {
            let err = await LocalInstall.run(ipa: url) {
                if autoDelete { try? FileManager.default.removeItem(at: url); signed.refresh() }
            }
            if let err { model.log += err + "\n" }
        }
    }
}

// MARK: - Pestaña Firmadas

struct SignedView: View {
    @ObservedObject var signed: FileStore
    @AppStorage("autoDelete") private var autoDelete = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                if signed.items.isEmpty {
                    Text("Aquí aparecerán tus apps firmadas.")
                        .foregroundStyle(.secondary).padding(.top, 80)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(signed.items) { item in
                            ProjectCard(item: item, meta: signed.metas[item.url]) {
                                HStack(spacing: 14) {
                                    Button { install(item) } label: {
                                        Image(systemName: "arrow.down.app").foregroundColor(.gold).font(.title3)
                                    }
                                    ShareLink(item: item.url) {
                                        Image(systemName: "square.and.arrow.up").foregroundColor(.gold).font(.title3)
                                    }
                                }
                            }
                            .contextMenu {
                                Button { install(item) } label: { Label("Instalar", systemImage: "arrow.down.app") }
                                Button(role: .destructive) { signed.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(AppBackground())
            .navigationTitle("Firmadas")
            .onAppear { signed.refresh() }
            .alert("Instalación", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func install(_ item: FileItem) {
        Task {
            message = await LocalInstall.run(ipa: item.url) {
                if autoDelete { try? FileManager.default.removeItem(at: item.url); signed.refresh() }
            }
        }
    }
}
