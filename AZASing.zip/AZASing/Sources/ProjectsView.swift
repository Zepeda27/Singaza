import SwiftUI
import UniformTypeIdentifiers

// MARK: - Modelo de firmado

@MainActor
final class SignModel: ObservableObject {
    @Published var log = ""
    @Published var busy = false
    @Published var result: URL?

    func run(_ options: SignOptions, signed: FileStore) {
        busy = true
        log = ""
        result = nil
        Task {
            do {
                let url = try await Signer.run(options, outputFolder: Folder.signed.url) { [weak self] msg in
                    self?.log += msg + "\n"
                }
                result = url
                log += "Listo: \(url.lastPathComponent)\n"
                signed.refresh()
            } catch {
                log += "Error: \(error.localizedDescription)\n"
            }
            busy = false
        }
    }
}

// MARK: - Tarjeta de app

struct Pill: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(Color.gold.opacity(0.15))
            .foregroundColor(.gold)
            .clipShape(Capsule())
    }
}

struct ProjectCard<Accessory: View>: View {
    let item: FileItem
    let meta: AppMeta?
    @ViewBuilder var accessory: () -> Accessory

    var body: some View {
        HStack(spacing: 14) {
            Group {
                if let icon = meta?.icon {
                    Image(uiImage: icon).resizable().scaledToFill()
                } else {
                    Image(systemName: "app.dashed").font(.title).foregroundColor(.gold)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.black)
                }
            }
            .frame(width: 62, height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(meta?.name ?? item.name).font(.headline).lineLimit(1)
                Text(meta?.bundleID ?? item.name)
                    .font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 6) {
                    if let v = meta?.version, !v.isEmpty { Pill(text: "v\(v)") }
                    Pill(text: ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                }
            }
            Spacer(minLength: 0)
            accessory()
        }
        .padding(14)
        .background(Color.card)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.gold.opacity(0.15)))
    }
}

// MARK: - Pestaña Proyectos (IPAs importados)

struct ProjectsView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore

    @State private var selected: FileItem?
    @State private var showImporter = false

    var body: some View {
        NavigationStack {
            ScrollView {
                if ipas.items.isEmpty {
                    VStack(spacing: 14) {
                        Image("Logo").resizable().scaledToFit().frame(maxWidth: 280)
                        Text("Importa un IPA con el botón +, o compártelo a AZASing desde Archivos, Safari o cualquier app.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .padding(.top, 60).padding(.horizontal, 30)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(ipas.items) { item in
                            Button { selected = item } label: {
                                ProjectCard(item: item, meta: ipas.metas[item.url]) {
                                    Image(systemName: "signature").foregroundColor(.gold).font(.title3)
                                }
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button(role: .destructive) { ipas.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(Color.black)
            .navigationTitle("Proyectos")
            .toolbar {
                Button { showImporter = true } label: { Image(systemName: "plus") }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [UTType(filenameExtension: "ipa") ?? .data, .zip],
                          allowsMultipleSelection: true) { result in
                if case .success(let urls) = result { ipas.importFiles(urls) }
            }
            .sheet(item: $selected) { item in
                SignSheet(item: item, meta: ipas.metas[item.url], tweaks: tweaks, signed: signed, certs: certs)
            }
            .onAppear { ipas.refresh() }
        }
    }
}

// MARK: - Hoja de firmado

struct SignSheet: View {
    let item: FileItem
    let meta: AppMeta?
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore
    @Environment(\.dismiss) private var dismiss

    @StateObject private var model = SignModel()
    @State private var certID: UUID?
    @State private var chosen = Set<URL>()
    @State private var bundleID = ""
    @State private var displayName = ""
    @State private var version = ""

    private var cert: Certificate? { certs.items.first { $0.id == certID } }

    var body: some View {
        NavigationStack {
            Form {
                Section("Certificado") {
                    Picker("Certificado", selection: $certID) {
                        Text("Elegir…").tag(UUID?.none)
                        ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                    }
                    if certs.items.isEmpty {
                        Text("Agrega un certificado en la pestaña Certificados.").font(.footnote).foregroundStyle(.secondary)
                    }
                    if cert?.isExpired == true {
                        Label("Este certificado está caducado.", systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                Section("Tweaks a inyectar") {
                    if tweaks.items.isEmpty {
                        Text("Importa .dylib o .framework en Archivos › Tweaks.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(tweaks.items) { t in
                        Toggle(t.name, isOn: Binding(
                            get: { chosen.contains(t.url) },
                            set: { on in if on { chosen.insert(t.url) } else { chosen.remove(t.url) } }))
                    }
                }

                Section("Opciones (opcional)") {
                    TextField("Bundle ID nuevo", text: $bundleID)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Nombre de la app", text: $displayName)
                    TextField("Versión", text: $version)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }

                Section {
                    Button(model.busy ? "Firmando…" : "Firmar") { sign() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(cert == nil || model.busy)
                        .listRowBackground(Color.clear)
                    if model.busy { ProgressView().frame(maxWidth: .infinity) }
                }

                if !model.log.isEmpty {
                    Section("Registro") {
                        Text(model.log).font(.system(.footnote, design: .monospaced))
                        if let url = model.result {
                            ShareLink(item: url) { Label("Compartir IPA firmado", systemImage: "square.and.arrow.up") }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle(meta?.name ?? item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
            .onAppear { if certID == nil { certID = certs.defaultID ?? certs.items.first?.id } }
        }
        .preferredColorScheme(.dark)
    }

    private func sign() {
        guard let cert else { return }
        let selected = tweaks.items.map(\.url).filter { chosen.contains($0) }
        model.run(SignOptions(ipa: item.url, cert: cert, tweaks: selected,
                              bundleID: bundleID.trimmingCharacters(in: .whitespaces),
                              displayName: displayName.trimmingCharacters(in: .whitespaces),
                              version: version.trimmingCharacters(in: .whitespaces)),
                  signed: signed)
    }
}

// MARK: - Pestaña Firmadas

struct SignedView: View {
    @ObservedObject var signed: FileStore

    var body: some View {
        NavigationStack {
            ScrollView {
                if signed.items.isEmpty {
                    Text("Aquí aparecerán tus apps firmadas.")
                        .foregroundStyle(.secondary).padding(.top, 80)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(signed.items) { item in
                            ProjectCard(item: item, meta: signed.metas[item.url]) {
                                ShareLink(item: item.url) {
                                    Image(systemName: "square.and.arrow.up").foregroundColor(.gold).font(.title3)
                                }
                            }
                            .contextMenu {
                                Button(role: .destructive) { signed.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(Color.black)
            .navigationTitle("Firmadas")
            .onAppear { signed.refresh() }
        }
    }
}
