import SwiftUI
import UniformTypeIdentifiers

// MARK: - Modelo de firmado

@MainActor
final class SignModel: ObservableObject {
    @Published var log = ""
    @Published var busy = false
    @Published var result: URL?

    func run(_ options: SignOptions, signed: FileStore, onDone: @escaping (URL) -> Void = { _ in }) {
        busy = true
        log = ""
        result = nil
        let copies = max(1, min(UserDefaults.standard.integer(forKey: "copies"), 10))
        Task {
            do {
                var url = URL(fileURLWithPath: "/")
                for i in 1...copies {
                    var o = options
                    o.copyIndex = i
                    if copies > 1 { log += "— Copia \(i) de \(copies) —\n" }
                    url = try await Signer.run(o, outputFolder: Folder.signed.url) { [weak self] msg in
                        self?.log += msg + "\n"
                    }
                    log += "Listo: \(url.lastPathComponent)\n"
                    signed.refresh()
                }
                result = url
                onDone(url)
            } catch {
                log += "Error: \(error.localizedDescription)\n"
            }
            busy = false
        }
    }
}

// MARK: - Tarjeta de app

struct Pill: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(Color.gold.opacity(0.15))
            .foregroundColor(.gold)
            .clipShape(Capsule())
    }
}

struct ProjectCard<Accessory: View>: View {
    let item: FileItem
    let meta: AppMeta?
    @ViewBuilder var accessory: () -> Accessory

    var body: some View {
        HStack(spacing: 14) {
            Group {
                if let icon = meta?.icon {
                    Image(uiImage: icon).resizable().scaledToFill()
                } else {
                    Image(systemName: "app.dashed").font(.title).foregroundColor(.gold)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.black)
                }
            }
            .frame(width: 62, height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(meta?.name ?? item.name).font(.headline).lineLimit(1)
                Text(meta?.bundleID ?? item.name)
                    .font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 6) {
                    if let v = meta?.version, !v.isEmpty { Pill(text: "v\(v)") }
                    Pill(text: ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                }
            }
            Spacer(minLength: 0)
            accessory()
        }
        .padding(14)
        .glassCard(cornerRadius: 22)
    }
}

// MARK: - Pestaña Proyectos (IPAs importados)

struct ProjectsView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming
    @State private var opening = false
    @State private var selecting = false
    @State private var selection = Set<URL>()
    @State private var confirmDelete = false
    @State private var openError: String?

    @State private var selected: FileItem?

    var body: some View {
        NavigationStack {
            ScrollView {
                if ipas.items.isEmpty {
                    VStack(spacing: 14) {
                        Image("Logo").resizable().scaledToFit().frame(maxWidth: 280)
                        Text("Importa un IPA con el botón +, o compártelo a AZASing desde Archivos, Safari o cualquier app.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .padding(.top, 60).padding(.horizontal, 30)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(ipas.items) { item in
                            Button {
                                if selecting {
                                    if selection.contains(item.url) { selection.remove(item.url) } else { selection.insert(item.url) }
                                } else { selected = item }
                            } label: {
                                ProjectCard(item: item, meta: ipas.metas[item.url]) {
                                    if selecting {
                                        Image(systemName: selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
                                            .foregroundColor(selection.contains(item.url) ? .gold : .secondary).font(.title3)
                                    } else {
                                        Image(systemName: "signature").foregroundColor(.gold).font(.title3)
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button { openPayload(item) } label: { Label("Abrir Payload", systemImage: "folder") }
                                Button { Share.present(item.url) } label: { Label("Compartir", systemImage: "square.and.arrow.up") }
                                Button(role: .destructive) { ipas.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                    if opening { ProgressView("Abriendo Payload…").padding() }
                }
            }
            .background(AppBackground())
            .navigationTitle("Proyectos")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 14) {
                        Button(selecting ? "Listo" : "Seleccionar") { selecting.toggle(); if !selecting { selection = [] } }
                        Button { DocPicker.present { ipas.importFiles($0) } } label: { Image(systemName: "plus") }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if selecting {
                    HStack(spacing: 6) {
                        Button { selection = selection.count == ipas.items.count ? [] : Set(ipas.items.map(\.url)) } label: {
                            VStack(spacing: 3) { Image(systemName: "checklist").font(.title3); Text("Todo").font(.caption2) }.frame(maxWidth: .infinity)
                        }
                        Button { if !selection.isEmpty { Share.present(Array(selection)) } } label: {
                            VStack(spacing: 3) { Image(systemName: "square.and.arrow.up").font(.title3); Text("Compartir").font(.caption2) }.frame(maxWidth: .infinity)
                        }
                        Button(role: .destructive) { if !selection.isEmpty { confirmDelete = true } } label: {
                            VStack(spacing: 3) { Image(systemName: "trash").font(.title3); Text("Eliminar").font(.caption2) }.frame(maxWidth: .infinity)
                        }
                    }
                    .foregroundColor(.gold)
                    .padding(.horizontal, 10).padding(.vertical, 8)
                    .glassCard(cornerRadius: 26)
                    .padding(.horizontal).padding(.bottom, 4)
                }
            }
            .confirmationDialog("¿Eliminar \(selection.count) app(s)?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Eliminar", role: .destructive) {
                    for u in selection { try? FileManager.default.removeItem(at: u) }
                    selection = []
                    ipas.refresh()
                }
            }
            .sheet(item: $selected) { item in
                SignSheet(item: item, meta: ipas.metas[item.url], tweaks: tweaks, signed: signed, certs: certs, incoming: incoming)
            }
            .onAppear { ipas.refresh() }
            .alert("Payload", isPresented: Binding(get: { openError != nil }, set: { if !$0 { openError = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(openError ?? "") }
            .alert("Importación", isPresented: Binding(get: { ipas.notice != nil },
                                                        set: { if !$0 { ipas.notice = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(ipas.notice ?? "") }
        }
    }
}

extension ProjectsView {
    fileprivate func openPayload(_ item: FileItem) {
        opening = true
        Task {
            let folder = await WorkspaceOpener.prepare(ipa: item.url)
            opening = false
            if let folder { incoming.returnTab = 0; incoming.openFolder = folder; incoming.selectedTab = 2 }
            else { openError = "No se pudo abrir el IPA. Puede estar dañado." }
        }
    }
}

// MARK: - Plugins disponibles (Tweaks, incluidas subcarpetas)

enum TweakScanner {
    /// Busca dylib, deb, framework y bundle en cualquier carpeta propia (Tweaks, raíz, carpetas nuevas).
    static func scan() -> [URL] {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let skip: Set<String> = [Folder.ipas.rawValue, Folder.signed.rawValue, Folder.certs.rawValue, Folder.workspaces.rawValue, "Inbox"]
        guard let en = FileManager.default.enumerator(at: docs, includingPropertiesForKeys: [.isDirectoryKey],
                                                      options: [.skipsHiddenFiles]) else { return [] }
        var out: [URL] = []
        for case let u as URL in en {
            if u.pathComponents.count == docs.pathComponents.count + 1, skip.contains(u.lastPathComponent) {
                en.skipDescendants(); continue
            }
            let ext = u.pathExtension.lowercased()
            let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if isDir {
                if ["framework", "bundle"].contains(ext) { out.append(u); en.skipDescendants() }
            } else if ["dylib", "deb"].contains(ext) { out.append(u) }
        }
        return out.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }
}

extension TweakScanner {
    /// Elementos (dylib, deb, framework, bundle) dentro de una carpeta, incluidas subcarpetas.
    static func items(in dir: URL, recursive: Bool = true) -> [URL] {
        let fm = FileManager.default
        var out: [URL] = []
        if recursive, let en = fm.enumerator(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) {
            for case let u as URL in en {
                let ext = u.pathExtension.lowercased()
                let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                if isDir { if ["framework", "bundle"].contains(ext) { out.append(u); en.skipDescendants() } }
                else if ["dylib", "deb"].contains(ext) { out.append(u) }
            }
        } else if let list = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) {
            for u in list {
                let ext = u.pathExtension.lowercased()
                let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                if isDir ? ["framework", "bundle"].contains(ext) : ["dylib", "deb"].contains(ext) { out.append(u) }
            }
        }
        return out.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }

    /// Carpetas creadas dentro de Tweaks (las que se muestran al firmar).
    static func folders() -> [URL] {
        let root = Folder.tweaks.url
        let list = (try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
        return list.filter {
            let ext = $0.pathExtension.lowercased()
            let isDir = (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            return isDir && !["framework", "bundle"].contains(ext)
        }.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }
}

struct KV: Identifiable, Hashable {
    let id = UUID()
    var key = ""
    var value = ""
}

struct KeyValueView: View {
    @Binding var items: [KV]
    var body: some View {
        List {
            ForEach($items) { $kv in
                VStack(alignment: .leading, spacing: 6) {
                    TextField("Clave (ej. UIFileSharingEnabled)", text: $kv.key)
                        .font(.caption.weight(.semibold)).foregroundColor(.gold)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Valor (texto, número, true o false)", text: $kv.value)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }
            }
            .onDelete { items.remove(atOffsets: $0) }
            Button { items.append(KV()) } label: { Label("Añadir clave", systemImage: "plus.circle") }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("Info.plist")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct RemoveLibrariesView: View {
    let ipa: URL
    @Binding var selection: Set<String>
    @State private var libs: [String]?

    var body: some View {
        List {
            if libs == nil { ProgressView().frame(maxWidth: .infinity) }
            if let libs, libs.isEmpty { Text("No se encontraron librerías propias en este IPA.").foregroundStyle(.secondary) }
            ForEach(libs ?? [], id: \.self) { lib in
                Toggle(isOn: Binding(get: { selection.contains(lib) },
                                     set: { on in if on { selection.insert(lib) } else { selection.remove(lib) } })) {
                    Text(lib).font(.system(.footnote, design: .monospaced))
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("Quitar librerías")
        .navigationBarTitleDisplayMode(.inline)
        .task { libs = await Task.detached { IPAReader.libraries(ipa) }.value }
    }
}

// MARK: - Opciones de firma (compartidas entre Ajustes y la hoja de firmado)

struct SignToggles: View {
    @AppStorage("signMode") private var signMode = "sign"
    @AppStorage("fileAccess") private var fileAccess = false
    @AppStorage("installAfterSign") private var installAfter = false
    @AppStorage("fixJBDeps") private var fixJBDeps = false
    @AppStorage("fixWhiteIcon") private var fixWhiteIcon = false
    @AppStorage("removeProfile") private var removeProfile = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("copies") private var copies = 1
    @AppStorage("gameMode") private var gameMode = false
    @AppStorage("unlockFPS") private var unlockFPS = false

    var body: some View {
        Picker("Modo", selection: $signMode) {
            Text("Firmar").tag("sign")
            Text("Solo inyectar (sin certificado)").tag("inject")
        }
        Toggle("Acceso a archivos", isOn: $fileAccess)
        Toggle("Instalar tras firmar", isOn: $installAfter)
        Toggle("Corregir dependencias de jailbreak", isOn: $fixJBDeps)
        Toggle("Reparar iconos en blanco", isOn: $fixWhiteIcon)
        Toggle("Quitar perfil incrustado", isOn: $removeProfile)
        Toggle("Quitar URL schemes", isOn: $removeURLs)
        Toggle("Quitar extensiones y Watch", isOn: $removeWatch)
        Stepper(value: $copies, in: 1...10) {
            HStack { Text("Varias copias"); Spacer(); Text(copies == 1 ? "No" : "\(copies)").foregroundStyle(.secondary) }
        }
        Toggle("Omitir firma", isOn: Binding(get: { signMode == "inject" }, set: { signMode = $0 ? "inject" : "sign" }))
        Toggle("Modo de juego", isOn: $gameMode)
        Toggle("Desbloquear FPS", isOn: $unlockFPS)
    }
}

// MARK: - Hoja de firmado

struct SignSheet: View {
    let item: FileItem
    let meta: AppMeta?
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming
    @Environment(\.dismiss) private var dismiss

    @AppStorage("installAfterSign") private var installAfter = false
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("signMode") private var signMode = "sign"
    @AppStorage("fileAccess") private var fileAccess = false
    @AppStorage("fixJBDeps") private var fixJBDeps = false
    @AppStorage("fixWhiteIcon") private var fixWhiteIcon = false
    @AppStorage("removeProfile") private var removeProfile = false
    @AppStorage("gameMode") private var gameMode = false
    @AppStorage("unlockFPS") private var unlockFPS = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("suffix") private var suffix = "-TGC"
    @AppStorage("exportFormat") private var exportFormat = "ipa"
    @AppStorage("injectPath") private var injectPath = "executable"
    @AppStorage("injectFolder") private var injectFolder = "frameworks"

    @StateObject private var model = SignModel()
    @State private var certID: UUID?
    @State private var tweakList: [URL] = []
    @State private var chosen = Set<URL>()
    @State private var debItems: [URL: [DebKit.DebItem]] = [:]
    @State private var debOn: [URL: Set<String>] = [:]
    @State private var bundleID = ""
    @State private var displayName = ""
    @State private var version = ""
    @State private var outputName = ""
    @State private var note = ""
    @State private var newIcon: UIImage?
    @State private var newIconData: Data?
    @State private var removeLibs = Set<String>()
    @State private var extras: [KV] = []

    private var cert: Certificate? { certs.items.first { $0.id == certID } }
    private var noteKey: String { "note." + item.name }
    private var injectPreview: String {
        let prefix = injectPath == "rpath" ? "@rpath/" : (injectFolder == "frameworks" ? "@executable_path/Frameworks/" : "@executable_path/")
        return prefix + "xxx.dylib"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    ProjectCard(item: item, meta: meta) { EmptyView() }
                        .listRowBackground(Color.clear).listRowInsets(EdgeInsets())
                }

                Section("Certificado") {
                    Picker("Certificado", selection: $certID) {
                        Text("Elegir…").tag(UUID?.none)
                        ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                    }
                    if certs.items.isEmpty {
                        Text("Agrega un certificado en Ajustes › Certificados.").font(.footnote).foregroundStyle(.secondary)
                    }
                    if cert?.isExpired == true {
                        Label("Este certificado está caducado.", systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                Section("Opciones de firma") { SignToggles() }

                Section("Editar (solo afecta al IPA firmado)") {
                    LabeledContent("Nombre") { TextField("Nombre de la app", text: $displayName).multilineTextAlignment(.trailing) }
                    LabeledContent("Bundle ID") {
                        TextField("Bundle ID", text: $bundleID).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    LabeledContent("Versión") {
                        TextField("Versión", text: $version).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                }

                Section("Payload") {
                    Button {
                        Task {
                            if let folder = await WorkspaceOpener.prepare(ipa: item.url) {
                                dismiss()
                                incoming.returnTab = 0
                                incoming.openFolder = folder
                                incoming.selectedTab = 2
                            } else { model.log += "No se pudo abrir el Payload.\n" }
                        }
                    } label: { Label("Abrir Payload (ver y editar archivos)", systemImage: "folder") }
                }

                Section("Logo") {
                    HStack(spacing: 14) {
                        Group {
                            if let img = newIcon ?? meta?.icon { Image(uiImage: img).resizable().scaledToFill() }
                            else { Image(systemName: "app.dashed").font(.title).foregroundColor(.gold) }
                        }
                        .frame(width: 58, height: 58).clipShape(RoundedRectangle(cornerRadius: 13))
                        Button("Cambiar logo") { pickIcon() }
                        Spacer()
                        if newIcon != nil { Button("Restaurar", role: .destructive) { newIcon = nil; newIconData = nil } }
                    }
                }

                Section("Librerías a inyectar (\(chosen.count))") {
                    Button { addLibrary() } label: { Label("Añadir librería (dylib, framework, deb)", systemImage: "plus.circle") }
                    if libFolders.isEmpty && looseItems.isEmpty {
                        Text("Crea una carpeta en Archivos › Tweaks y pon dentro tus dylib y deb. Aquí podrás elegir cuáles inyectar.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(libFolders, id: \.self) { f in
                        NavigationLink { folderPicker(f, recursive: true) } label: { folderRow(f.lastPathComponent, f, recursive: true) }
                    }
                    if !looseItems.isEmpty {
                        NavigationLink { folderPicker(Folder.tweaks.url, recursive: false) } label: { folderRow("Tweaks (sueltos)", Folder.tweaks.url, recursive: false) }
                    }
                    NavigationLink { RemoveLibrariesView(ipa: item.url, selection: $removeLibs) } label: {
                        Label("Quitar librerías existentes (\(removeLibs.count))", systemImage: "minus.circle")
                    }
                }

                Section("Avanzado") {
                  DisclosureGroup("Ajustes de inyección") {
                    Picker("Ruta", selection: $injectPath) {
                        Text("@executable_path").tag("executable")
                        Text("@rpath").tag("rpath")
                    }
                    .pickerStyle(.segmented)
                    Picker("Carpeta", selection: $injectFolder) {
                        Text("/").tag("root")
                        Text("Frameworks/").tag("frameworks")
                    }
                    .pickerStyle(.segmented)
                    Text(injectPreview).font(.system(.footnote, design: .monospaced)).foregroundStyle(.secondary)
                  }
                }

                Section("Info.plist") {
                    NavigationLink { KeyValueView(items: $extras) } label: {
                        Label("Añadir o reemplazar clave y valor (\(extras.filter { !$0.key.isEmpty }.count))", systemImage: "list.bullet.rectangle")
                    }
                }

                Section("Salida") {
                    LabeledContent("Archivo") {
                        TextField("Nombre del archivo", text: $outputName).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    LabeledContent("Sufijo") {
                        TextField("-TGC", text: $suffix).multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    HStack(spacing: 8) {
                        ForEach(["-TGC", "-AZASing"], id: \.self) { opt in
                            Button { suffix = opt } label: {
                                Text(opt).font(.footnote.weight(.semibold))
                                    .padding(.horizontal, 12).padding(.vertical, 6)
                                    .background(Capsule().fill(suffix == opt ? Color.gold.opacity(0.3) : Color.gray.opacity(0.15)))
                                    .foregroundColor(suffix == opt ? .gold : .secondary)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    Text("Se guardará como \(outputName)\(suffix).\(exportFormat)")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("Formato", selection: $exportFormat) {
                        Text("IPA").tag("ipa")
                        Text("TIPA").tag("tipa")
                    }
                    .pickerStyle(.segmented)
                }

                if !model.log.isEmpty {
                    Section("Registro") {
                        Text(model.log).font(.system(.footnote, design: .monospaced))
                        if let url = model.result {
                            ShareLink(item: url) { Label("Compartir IPA firmado", systemImage: "square.and.arrow.up") }
                        }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) { floatingBar }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle(meta?.name ?? item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
            .onAppear {
                if certID == nil { certID = certs.defaultID ?? certs.items.first?.id }
                if displayName.isEmpty { displayName = meta?.name ?? "" }
                if bundleID.isEmpty { bundleID = meta?.bundleID ?? "" }
                if version.isEmpty { version = meta?.version ?? "" }
                if outputName.isEmpty {
                    let base = (meta?.name ?? item.url.deletingPathExtension().lastPathComponent)
                    outputName = version.isEmpty ? base : "\(base)_\(version)"
                }
                tweakList = TweakScanner.scan()
            }
        }
    }

    private var floatingBar: some View {
        HStack(spacing: 10) {
            Button { sign(install: false) } label: {
                Text(signMode == "inject" ? "Inyectar sin firmar" : "Firmar").font(.headline).foregroundColor(.gold)
                    .frame(maxWidth: .infinity).padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            .glassCard(cornerRadius: 18)
            if signMode != "inject" {
                Button { sign(install: true) } label: { Text(model.busy ? "Firmando…" : "Firmar e instalar") }
                    .buttonStyle(GoldButtonStyle())
            }
        }
        .disabled((cert == nil && signMode != "inject") || model.busy)
        .padding(.horizontal).padding(.vertical, 8)
    }

    // MARK: Carpetas de librerías

    private var libFolders: [URL] { TweakScanner.folders() }
    private var looseItems: [URL] { TweakScanner.items(in: Folder.tweaks.url, recursive: false) }

    private func folderRow(_ title: String, _ dir: URL, recursive: Bool) -> some View {
        let all = TweakScanner.items(in: dir, recursive: recursive)
        let n = all.filter { chosen.contains($0) }.count
        return HStack {
            Image(systemName: "folder.fill").foregroundColor(.gold)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                Text("\(all.count) elementos").font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            if n > 0 { Text("\(n)").font(.caption.bold()).padding(.horizontal, 8).padding(.vertical, 2)
                .background(Capsule().fill(Color.gold.opacity(0.25))) }
        }
    }

    private func folderPicker(_ dir: URL, recursive: Bool) -> some View {
        let list = TweakScanner.items(in: dir, recursive: recursive)
        return List {
            if list.isEmpty { Text("Esta carpeta no tiene dylib, deb, framework ni bundle.").foregroundStyle(.secondary) }
            ForEach(list, id: \.self) { t in
                Toggle(isOn: Binding(get: { chosen.contains(t) }, set: { setTweak(t, $0) })) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(t.lastPathComponent)
                        if t.pathExtension.lowercased() == "deb", chosen.contains(t), debItems[t]?.isEmpty != false {
                            Text("Leyendo contenido…").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if t.pathExtension.lowercased() == "deb", chosen.contains(t), let inner = debItems[t], !inner.isEmpty {
                    ForEach(inner, id: \.self) { piece in
                        Toggle(isOn: Binding(get: { debOn[t]?.contains(piece.name) ?? true },
                                             set: { setPiece(t, piece.name, $0) })) {
                            Label(piece.name, systemImage: piece.kind == "dylib" ? "puzzlepiece.extension" : (piece.kind == "bundle" ? "shippingbox.fill" : "shippingbox"))
                                .font(.subheadline)
                        }
                        .padding(.leading, 18)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(recursive ? dir.lastPathComponent : "Tweaks")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: Librerías

    private func addLibrary() {
        DocPicker.present { urls in
            let before = Set(TweakScanner.scan())
            tweaks.importFiles(urls)
            let after = TweakScanner.scan()
            tweakList = after
            for u in after where !before.contains(u) { setTweak(u, true) }
        }
    }

    private func setTweak(_ url: URL, _ on: Bool) {
        if on {
            chosen.insert(url)
            if url.pathExtension.lowercased() == "deb", debItems[url] == nil {
                Task {
                    let items = await Task.detached { DebKit.listItems(url) }.value
                    debItems[url] = items
                    if debOn[url] == nil { debOn[url] = Set(items.map(\.name)) }
                }
            }
        } else {
            chosen.remove(url)
        }
    }

    private func setPiece(_ deb: URL, _ name: String, _ on: Bool) {
        var s = debOn[deb] ?? Set((debItems[deb] ?? []).map(\.name))
        if on { s.insert(name) } else { s.remove(name) }
        debOn[deb] = s
    }

    private func pickIcon() {
        DocPicker.present(multiple: false) { urls in
            guard let u = urls.first, let d = try? Data(contentsOf: u), let img = UIImage(data: d) else { return }
            newIcon = img
            newIconData = d
        }
    }

    // MARK: Firmar

    private func sign(install wantInstall: Bool) {
        let skip = signMode == "inject"
        guard cert != nil || skip else { return }
        let trim: (String) -> String = { $0.trimmingCharacters(in: .whitespaces) }
        var debSel: [String: Set<String>] = [:]
        for t in chosen where t.pathExtension.lowercased() == "deb" {
            if let on = debOn[t], debItems[t]?.isEmpty == false { debSel[t.path] = on }
        }
        var extra: [String: String] = [:]
        for kv in extras where !trim(kv.key).isEmpty { extra[trim(kv.key)] = kv.value }
        let opts = SignOptions(ipa: item.url, cert: skip ? nil : cert, tweaks: tweakList.filter { chosen.contains($0) },
                               bundleID: trim(bundleID), displayName: trim(displayName), version: trim(version),
                               removeURLSchemes: removeURLs, removeWatch: removeWatch,
                               compress: compression != 0, outputName: trim(outputName), suffix: suffix,
                               ext: exportFormat, iconData: newIconData, removeLibraries: removeLibs,
                               injectRPath: injectPath == "rpath", injectInFrameworks: injectFolder == "frameworks",
                               plistExtras: extra, debSelection: debSel,
                               skipSign: skip, fileAccess: fileAccess, fixJailbreakDeps: fixJBDeps,
                               fixWhiteIcon: fixWhiteIcon, removeProfile: removeProfile,
                               removeExtensions: removeWatch, gameMode: gameMode, unlockFPS: unlockFPS)
        model.run(opts, signed: signed) { url in
            if !skip && (wantInstall || installAfter) { startInstall(url) }
        }
    }

    private func startInstall(_ url: URL) {
        model.log += "Instalando… confirma en el aviso del sistema.\n"
        Task {
            let err = await LocalInstall.run(ipa: url) {
                if autoDelete { try? FileManager.default.removeItem(at: url); signed.refresh() }
            }
            if let err { model.log += err + "\n" }
        }
    }
}

// MARK: - Pestaña Firmadas

struct SignedView: View {
    @ObservedObject var signed: FileStore
    @AppStorage("autoDelete") private var autoDelete = false
    @State private var message: String?
    @State private var selecting = false
    @State private var selection = Set<URL>()
    @State private var confirmDelete = false

    var body: some View {
        NavigationStack {
            ScrollView {
                if signed.items.isEmpty {
                    Text("Aquí aparecerán tus apps firmadas.")
                        .foregroundStyle(.secondary).padding(.top, 80)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(signed.items) { item in
                            Button {
                                if selecting { toggle(item.url) }
                            } label: {
                                ProjectCard(item: item, meta: signed.metas[item.url]) {
                                    if selecting {
                                        Image(systemName: selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
                                            .foregroundColor(selection.contains(item.url) ? .gold : .secondary).font(.title3)
                                    } else {
                                        HStack(spacing: 14) {
                                            Button { install(item) } label: {
                                                Image(systemName: "arrow.down.app").foregroundColor(.gold).font(.title3)
                                            }
                                            Button { shareWithMetadata([item]) } label: {
                                                Image(systemName: "square.and.arrow.up").foregroundColor(.gold).font(.title3)
                                            }
                                        }
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button { install(item) } label: { Label("Instalar", systemImage: "arrow.down.app") }
                                Button { shareWithThumbnail([item]) } label: { Label("Compartir con miniatura", systemImage: "photo.on.rectangle") }
                                Button { shareWithMetadata([item]) } label: { Label("Compartir (con nombre e icono)", systemImage: "square.and.arrow.up") }
                                Button(role: .destructive) { signed.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(AppBackground())
            .navigationTitle("Firmadas")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if !signed.items.isEmpty {
                        Button(selecting ? "Listo" : "Seleccionar") { selecting.toggle(); if !selecting { selection = [] } }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if selecting {
                    HStack(spacing: 6) {
                        Button { selection = selection.count == signed.items.count ? [] : Set(signed.items.map(\.url)) } label: {
                            barLabel("checklist", "Todo")
                        }
                        Button {
                            if selection.count == 1, let it = signed.items.first(where: { selection.contains($0.url) }) { install(it) }
                            else { message = "Selecciona una sola app para instalarla." }
                        } label: { barLabel("arrow.down.app", "Instalar") }
                        Button { shareWithMetadata(signed.items.filter { selection.contains($0.url) }) } label: {
                            barLabel("square.and.arrow.up", "Compartir")
                        }
                        Button { shareWithThumbnail(signed.items.filter { selection.contains($0.url) }) } label: {
                            barLabel("photo.on.rectangle", "Con icono")
                        }
                        Button(role: .destructive) { if !selection.isEmpty { confirmDelete = true } } label: {
                            barLabel("trash", "Eliminar")
                        }
                    }
                    .foregroundColor(.gold)
                    .padding(.horizontal, 10).padding(.vertical, 8)
                    .glassCard(cornerRadius: 26)
                    .padding(.horizontal).padding(.bottom, 4)
                }
            }
            .confirmationDialog("¿Eliminar \(selection.count) app(s)?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Eliminar", role: .destructive) {
                    for u in selection { try? FileManager.default.removeItem(at: u) }
                    selection = []; selecting = false
                    signed.refresh()
                }
            }
            .onAppear { signed.refresh() }
            .alert("Instalación", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func barLabel(_ icon: String, _ text: String) -> some View {
        VStack(spacing: 3) { Image(systemName: icon).font(.title3); Text(text).font(.caption2) }.frame(maxWidth: .infinity)
    }

    /// Comparte el IPA con sus metadatos (nombre e icono) para que la hoja de compartir los muestre.
    private func shareWithMetadata(_ items: [FileItem]) {
        guard !items.isEmpty else { return }
        Share.presentItems(items.map { IPAShareItem(url: $0.url, title: signed.metas[$0.url]?.name ?? $0.name, icon: signed.metas[$0.url]?.icon) })
    }

    private func toggle(_ u: URL) {
        if selection.contains(u) { selection.remove(u) } else { selection.insert(u) }
    }

    /// Comparte el IPA junto con su icono (PNG) para que Telegram y otras apps muestren la miniatura.
    private func shareWithThumbnail(_ items: [FileItem]) {
        guard !items.isEmpty else { return }
        var urls: [URL] = []
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("share-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        for it in items {
            urls.append(it.url)
            if let icon = signed.metas[it.url]?.icon, let png = icon.pngData() {
                let f = dir.appendingPathComponent(it.url.deletingPathExtension().lastPathComponent + ".png")
                if (try? png.write(to: f)) != nil { urls.append(f) }
            }
        }
        Share.present(urls)
    }

    private func install(_ item: FileItem) {
        Task {
            message = await LocalInstall.run(ipa: item.url) {
                if autoDelete { try? FileManager.default.removeItem(at: item.url); signed.refresh() }
            }
        }
    }
}
