import SwiftUI
import UniformTypeIdentifiers

// MARK: - Modelo de firmado

@MainActor
final class SignModel: ObservableObject {
    @Published var log = ""
    @Published var busy = false
    @Published var result: URL?

    func run(_ options: SignOptions, signed: FileStore, onDone: @escaping (URL) -> Void = { _ in }) {
        busy = true
        log = ""
        result = nil
        Task {
            do {
                let url = try await Signer.run(options, outputFolder: Folder.signed.url) { [weak self] msg in
                    self?.log += msg + "\n"
                }
                result = url
                log += "Listo: \(url.lastPathComponent)\n"
                signed.refresh()
                onDone(url)
            } catch {
                log += "Error: \(error.localizedDescription)\n"
            }
            busy = false
        }
    }
}

// MARK: - Tarjeta de app

struct Pill: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(Color.gold.opacity(0.15))
            .foregroundColor(.gold)
            .clipShape(Capsule())
    }
}

struct ProjectCard<Accessory: View>: View {
    let item: FileItem
    let meta: AppMeta?
    @ViewBuilder var accessory: () -> Accessory

    var body: some View {
        HStack(spacing: 14) {
            Group {
                if let icon = meta?.icon {
                    Image(uiImage: icon).resizable().scaledToFill()
                } else {
                    Image(systemName: "app.dashed").font(.title).foregroundColor(.gold)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.black)
                }
            }
            .frame(width: 62, height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(meta?.name ?? item.name).font(.headline).lineLimit(1)
                Text(meta?.bundleID ?? item.name)
                    .font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 6) {
                    if let v = meta?.version, !v.isEmpty { Pill(text: "v\(v)") }
                    Pill(text: ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                }
            }
            Spacer(minLength: 0)
            accessory()
        }
        .padding(14)
        .glassCard(cornerRadius: 22)
    }
}

// MARK: - Pestaña Proyectos (IPAs importados)

struct ProjectsView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore

    @State private var selected: FileItem?

    var body: some View {
        NavigationStack {
            ScrollView {
                if ipas.items.isEmpty {
                    VStack(spacing: 14) {
                        Image("Logo").resizable().scaledToFit().frame(maxWidth: 280)
                        Text("Importa un IPA con el botón +, o compártelo a AZASing desde Archivos, Safari o cualquier app.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .padding(.top, 60).padding(.horizontal, 30)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(ipas.items) { item in
                            Button { selected = item } label: {
                                ProjectCard(item: item, meta: ipas.metas[item.url]) {
                                    Image(systemName: "signature").foregroundColor(.gold).font(.title3)
                                }
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button(role: .destructive) { ipas.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(AppBackground())
            .navigationTitle("Proyectos")
            .toolbar {
                Button { DocPicker.present { ipas.importFiles($0) } } label: { Image(systemName: "plus") }
            }
            .sheet(item: $selected) { item in
                SignSheet(item: item, meta: ipas.metas[item.url], tweaks: tweaks, signed: signed, certs: certs)
            }
            .onAppear { ipas.refresh() }
            .alert("Importación", isPresented: Binding(get: { ipas.notice != nil },
                                                        set: { if !$0 { ipas.notice = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(ipas.notice ?? "") }
        }
    }
}

// MARK: - Hoja de firmado

struct SignSheet: View {
    let item: FileItem
    let meta: AppMeta?
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore
    @ObservedObject var certs: CertStore
    @Environment(\.dismiss) private var dismiss

    @AppStorage("installAfterSign") private var installAfter = true
    @AppStorage("autoDelete") private var autoDelete = false
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("appendSuffix") private var appendSuffix = true
    @AppStorage("exportFormat") private var exportFormat = "ipa"

    @StateObject private var model = SignModel()
    @State private var certID: UUID?
    @State private var chosen = Set<URL>()
    @State private var bundleID = ""
    @State private var displayName = ""
    @State private var version = ""
    @State private var outputName = ""
    @State private var note = ""

    private var cert: Certificate? { certs.items.first { $0.id == certID } }
    private var noteKey: String { "note." + item.name }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    ProjectCard(item: item, meta: meta) { EmptyView() }
                        .listRowBackground(Color.clear).listRowInsets(EdgeInsets())
                }

                Section("Certificado") {
                    Picker("Certificado", selection: $certID) {
                        Text("Elegir…").tag(UUID?.none)
                        ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                    }
                    if certs.items.isEmpty {
                        Text("Agrega un certificado en la pestaña Certificados.").font(.footnote).foregroundStyle(.secondary)
                    }
                    if cert?.isExpired == true {
                        Label("Este certificado está caducado.", systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                Section("Plugins a inyectar (\(chosen.count))") {
                    if tweaks.items.isEmpty {
                        Text("Importa .dylib o .framework en Archivos › Tweaks.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(tweaks.items) { t in
                        Toggle(t.name, isOn: Binding(
                            get: { chosen.contains(t.url) },
                            set: { on in if on { chosen.insert(t.url) } else { chosen.remove(t.url) } }))
                    }
                }

                Section("Editar (solo afecta al IPA firmado)") {
                    TextField(meta?.name ?? "Nombre de la app", text: $displayName)
                    TextField(meta?.bundleID ?? "Bundle ID", text: $bundleID)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField(meta?.version ?? "Versión", text: $version)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Nombre del archivo de salida", text: $outputName)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }

                Section("Nota del proyecto") {
                    TextField("Escribe una nota…", text: $note, axis: .vertical).lineLimit(1...4)
                }

                Section {
                    Button(model.busy ? "Firmando…" : (installAfter ? "Firmar e instalar" : "Firmar")) { sign() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(cert == nil || model.busy)
                        .listRowBackground(Color.clear)
                    if model.busy { ProgressView().frame(maxWidth: .infinity) }
                }

                if !model.log.isEmpty {
                    Section("Registro") {
                        Text(model.log).font(.system(.footnote, design: .monospaced))
                        if let url = model.result {
                            Button { install(url) } label: { Label("Instalar en este iPhone", systemImage: "arrow.down.app") }
                            ShareLink(item: url) { Label("Compartir IPA firmado", systemImage: "square.and.arrow.up") }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle(meta?.name ?? item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
            .onAppear {
                if certID == nil { certID = certs.defaultID ?? certs.items.first?.id }
                note = UserDefaults.standard.string(forKey: noteKey) ?? ""
            }
            .onChange(of: note) { UserDefaults.standard.set($0, forKey: noteKey) }
        }
        .preferredColorScheme(.dark)
    }

    private func sign() {
        guard let cert else { return }
        let selected = tweaks.items.map(\.url).filter { chosen.contains($0) }
        let trim: (String) -> String = { $0.trimmingCharacters(in: .whitespaces) }
        model.run(SignOptions(ipa: item.url, cert: cert, tweaks: selected,
                              bundleID: trim(bundleID), displayName: trim(displayName), version: trim(version),
                              removeURLSchemes: removeURLs, removeWatch: removeWatch,
                              compress: compression != 0, outputName: trim(outputName), appendSuffix: appendSuffix, ext: exportFormat),
                  signed: signed) { url in
            if installAfter { install(url) }
        }
    }

    private func install(_ url: URL) {
        Task {
            let err = await LocalInstall.run(ipa: url) {
                if autoDelete { try? FileManager.default.removeItem(at: url); signed.refresh() }
            }
            if let err { model.log += err + "\n" }
        }
    }
}

// MARK: - Pestaña Firmadas

struct SignedView: View {
    @ObservedObject var signed: FileStore
    @AppStorage("autoDelete") private var autoDelete = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                if signed.items.isEmpty {
                    Text("Aquí aparecerán tus apps firmadas.")
                        .foregroundStyle(.secondary).padding(.top, 80)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(signed.items) { item in
                            ProjectCard(item: item, meta: signed.metas[item.url]) {
                                HStack(spacing: 14) {
                                    Button { install(item) } label: {
                                        Image(systemName: "arrow.down.app").foregroundColor(.gold).font(.title3)
                                    }
                                    ShareLink(item: item.url) {
                                        Image(systemName: "square.and.arrow.up").foregroundColor(.gold).font(.title3)
                                    }
                                }
                            }
                            .contextMenu {
                                Button { install(item) } label: { Label("Instalar", systemImage: "arrow.down.app") }
                                Button(role: .destructive) { signed.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .background(AppBackground())
            .navigationTitle("Firmadas")
            .onAppear { signed.refresh() }
            .alert("Instalación", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func install(_ item: FileItem) {
        Task {
            message = await LocalInstall.run(ipa: item.url) {
                if autoDelete { try? FileManager.default.removeItem(at: item.url); signed.refresh() }
            }
        }
    }
}
