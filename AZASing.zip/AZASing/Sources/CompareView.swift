import SwiftUI
import ZIPFoundation

// MARK: - Comparar un IPA modificado con el original

struct IPADiff {
    var added: [(name: String, count: Int)] = []
    var removed: [(name: String, count: Int)] = []
    var changed: [String] = []
    var signatureChanges = 0   // binarios que cambian solo por volver a firmar
}

enum IPAComparer {
    /// ruta dentro de la app → CRC32. Ignora _CodeSignature.
    private static func entries(_ url: URL) -> [String: UInt32]? {
        guard let archive = try? Archive(url: url, accessMode: .read) else { return nil }
        var d: [String: UInt32] = [:]
        for e in archive where e.type == .file {
            let parts = e.path.split(separator: "/").map(String.init)
            guard parts.count > 2, parts[0] == "Payload", parts[1].hasSuffix(".app") else { continue }
            let rel = parts.dropFirst(2).joined(separator: "/")
            if rel.hasPrefix("_CodeSignature/") || rel.contains("/_CodeSignature/") { continue }
            d[rel] = e.checksum
        }
        return d
    }

    /// Agrupa por framework / bundle / extensión; el resto, archivo a archivo.
    private static func group(_ rel: String) -> String {
        var out: [String] = []
        for p in rel.split(separator: "/").map(String.init) {
            out.append(p)
            if ["framework", "bundle", "appex", "app", "xpc"].contains((p as NSString).pathExtension.lowercased()) { break }
        }
        return out.joined(separator: "/")
    }

    /// Binarios que cambian al volver a firmar (no son inyecciones).
    private static func looksBinary(_ rel: String) -> Bool {
        let name = (rel as NSString).lastPathComponent
        let ext = (name as NSString).pathExtension.lowercased()
        if ext == "dylib" { return true }
        if !rel.contains("/") && ext.isEmpty { return true }   // ejecutable principal
        let parts = rel.split(separator: "/").map(String.init)
        if parts.count >= 2, ext.isEmpty {
            let parent = parts[parts.count - 2]
            if (parent as NSString).deletingPathExtension == name { return true }   // Foo.framework/Foo
        }
        return false
    }

    static func compare(original: URL, modified: URL) -> IPADiff? {
        guard let a = entries(original), let b = entries(modified) else { return nil }
        var diff = IPADiff()
        var added: [String: Int] = [:], removed: [String: Int] = [:]
        var changedGroups = Set<String>()
        for (rel, crc) in b {
            if let old = a[rel] {
                if old != crc {
                    if looksBinary(rel) { diff.signatureChanges += 1 } else { changedGroups.insert(rel) }
                }
            } else {
                added[group(rel), default: 0] += 1
            }
        }
        for rel in a.keys where b[rel] == nil { removed[group(rel), default: 0] += 1 }
        diff.added = added.map { ($0.key, $0.value) }.sorted { $0.name.lowercased() < $1.name.lowercased() }
        diff.removed = removed.map { ($0.key, $0.value) }.sorted { $0.name.lowercased() < $1.name.lowercased() }
        diff.changed = changedGroups.sorted { $0.lowercased() < $1.lowercased() }
        return diff
    }
}

struct CompareView: View {
    let diff: IPADiff
    let title: String
    @Environment(\.dismiss) private var dismiss

    private func label(_ item: (name: String, count: Int)) -> String {
        item.count > 1 ? "\(item.name) (\(item.count) archivos)" : item.name
    }

    private var summary: String {
        var t = "Comparación: \(title)\n"
        t += "\nAñadidos (\(diff.added.count))\n" + diff.added.map { "+ \(label($0))" }.joined(separator: "\n")
        t += "\n\nModificados (\(diff.changed.count))\n" + diff.changed.map { "~ \($0)" }.joined(separator: "\n")
        t += "\n\nEliminados (\(diff.removed.count))\n" + diff.removed.map { "- \(label($0))" }.joined(separator: "\n")
        return t
    }

    var body: some View {
        NavigationStack {
            List {
                if diff.added.isEmpty && diff.changed.isEmpty && diff.removed.isEmpty {
                    Section { Text("No hay diferencias (aparte de la firma).").foregroundStyle(.secondary) }
                }
                if !diff.added.isEmpty {
                    Section("Añadidos (\(diff.added.count))") {
                        ForEach(diff.added, id: \.name) { item in
                            Label(label(item), systemImage: "plus.circle.fill").foregroundColor(.green).font(.callout)
                        }
                    }
                }
                if !diff.changed.isEmpty {
                    Section("Modificados (\(diff.changed.count))") {
                        ForEach(diff.changed, id: \.self) { rel in
                            Label(rel, systemImage: "pencil.circle.fill").foregroundColor(.orange).font(.callout)
                        }
                    }
                }
                if !diff.removed.isEmpty {
                    Section("Eliminados (\(diff.removed.count))") {
                        ForEach(diff.removed, id: \.name) { item in
                            Label(label(item), systemImage: "minus.circle.fill").foregroundColor(.red).font(.callout)
                        }
                    }
                }
                if diff.signatureChanges > 0 {
                    Section {
                        Text("\(diff.signatureChanges) binario(s) cambian solo por volver a firmar; no se cuentan como modificados.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Comparación con el original")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { UIPasteboard.general.string = summary } label: { Image(systemName: "doc.on.doc") }
                }
            }
        }
    }
}
