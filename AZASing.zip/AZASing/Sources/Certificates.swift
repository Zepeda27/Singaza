import Foundation
import Security

struct Certificate: Identifiable, Codable, Hashable {
    var id: UUID
    var name: String
    var profileName: String
    var teamName: String
    var expiry: Date?
    var devices: [String]?

    var isExpired: Bool { (expiry ?? .distantFuture) < Date() }
    var dir: URL { Folder.certs.url.appendingPathComponent(id.uuidString, isDirectory: true) }
    var p12URL: URL { dir.appendingPathComponent("cert.p12") }
    var provisionURL: URL { dir.appendingPathComponent("profile.mobileprovision") }
    var password: String { Keychain.get(id.uuidString) ?? "" }
}

struct ProvisionInfo {
    var name: String
    var team: String
    var expiry: Date?
    var devices: [String] = []

    /// El .mobileprovision es un CMS que contiene un plist en texto claro.
    static func parse(_ data: Data) -> ProvisionInfo? {
        guard let start = data.range(of: Data("<?xml".utf8)),
              let end = data.range(of: Data("</plist>".utf8)) else { return nil }
        let plist = data.subdata(in: start.lowerBound..<end.upperBound)
        guard let dict = try? PropertyListSerialization.propertyList(from: plist, format: nil) as? [String: Any]
        else { return nil }
        return ProvisionInfo(name: dict["Name"] as? String ?? "",
                             team: dict["TeamName"] as? String ?? "",
                             expiry: dict["ExpirationDate"] as? Date,
                             devices: dict["ProvisionedDevices"] as? [String] ?? [])
    }
}

enum CertError: LocalizedError {
    case wrongPassword, badProfile, copyFailed
    var errorDescription: String? {
        switch self {
        case .wrongPassword: return "La contraseña del .p12 es incorrecta."
        case .badProfile: return "No se pudo leer el archivo .mobileprovision."
        case .copyFailed: return "No se pudieron guardar los archivos del certificado."
        }
    }
}

@MainActor
final class CertStore: ObservableObject {
    @Published private(set) var items: [Certificate] = []
    @Published var defaultID: UUID? {
        didSet { UserDefaults.standard.set(defaultID?.uuidString, forKey: "defaultCert") }
    }

    init() {
        if let s = UserDefaults.standard.string(forKey: "defaultCert") { defaultID = UUID(uuidString: s) }
        load()
    }

    func load() {
        let fm = FileManager.default
        let dirs = (try? fm.contentsOfDirectory(at: Folder.certs.url, includingPropertiesForKeys: nil)) ?? []
        items = dirs.compactMap { dir in
            guard let data = try? Data(contentsOf: dir.appendingPathComponent("meta.json")) else { return nil }
            return try? JSONDecoder().decode(Certificate.self, from: data)
        }.sorted { $0.name < $1.name }
    }

    func add(name: String, p12: URL, profile: URL, password: String) throws {
        let p12Data = try Data(contentsOf: p12)
        let profileData = try Data(contentsOf: profile)

        // Valida la contraseña (solo bloquea si es claramente incorrecta).
        var out: CFArray?
        let status = SecPKCS12Import(p12Data as CFData,
                                     [kSecImportExportPassphrase as String: password] as CFDictionary, &out)
        if status == errSecAuthFailed { throw CertError.wrongPassword }

        guard let info = ProvisionInfo.parse(profileData) else { throw CertError.badProfile }

        let cert = Certificate(id: UUID(),
                               name: name.isEmpty ? info.name : name,
                               profileName: info.name, teamName: info.team, expiry: info.expiry,
                               devices: info.devices.isEmpty ? nil : info.devices)
        do {
            try FileManager.default.createDirectory(at: cert.dir, withIntermediateDirectories: true)
            try p12Data.write(to: cert.p12URL)
            try profileData.write(to: cert.provisionURL)
            try JSONEncoder().encode(cert).write(to: cert.dir.appendingPathComponent("meta.json"))
        } catch { throw CertError.copyFailed }

        Keychain.set(password, for: cert.id.uuidString)
        if defaultID == nil { defaultID = cert.id }
        load()
    }

    func delete(_ cert: Certificate) {
        try? FileManager.default.removeItem(at: cert.dir)
        Keychain.delete(cert.id.uuidString)
        if defaultID == cert.id { defaultID = nil }
        load()
    }
}
