import SwiftUI
import UIKit
import UniformTypeIdentifiers

// Puente con UIKit: selector de documentos y hoja de compartir.
// El selector usa asCopy: el sistema entrega una COPIA dentro de la app,
// así no dependemos de permisos de acceso (el fallo de fileImporter).

enum UIKitBridge {
    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            ?? scene?.windows.first?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}

final class PickerDelegate: NSObject, UIDocumentPickerDelegate {
    static var current: PickerDelegate?   // se retiene mientras el selector está abierto
    let onPick: ([URL]) -> Void
    init(_ onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        PickerDelegate.current = nil
        DispatchQueue.main.async { self.onPick(urls) }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        PickerDelegate.current = nil
    }
}

enum DocPicker {
    /// Elegir carpetas completas. Se abren en el sitio (sin copia) y se copian con acceso temporal.
    static func presentFolders(onPick: @escaping ([URL]) -> Void) {
        guard let top = UIKitBridge.topViewController() else { return }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = true
        let delegate = PickerDelegate { urls in
            var copies: [URL] = []
            let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("pick-\(UUID().uuidString)")
            try? FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)
            for u in urls {
                let ok = u.startAccessingSecurityScopedResource()
                let dest = tmp.appendingPathComponent(u.lastPathComponent)
                if (try? FileManager.default.copyItem(at: u, to: dest)) != nil { copies.append(dest) }
                if ok { u.stopAccessingSecurityScopedResource() }
            }
            onPick(copies)
        }
        PickerDelegate.current = delegate
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    static func present(multiple: Bool = true, onPick: @escaping ([URL]) -> Void) {
        guard let top = UIKitBridge.topViewController() else { return }
        // .item + .folder: cualquier tipo de archivo, paquetes (.framework, .bundle, .app) y carpetas.
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item, .data, .content, .package], asCopy: true)
        picker.allowsMultipleSelection = multiple
        let delegate = PickerDelegate(onPick)
        PickerDelegate.current = delegate
        picker.delegate = delegate
        top.present(picker, animated: true)
    }
}

import LinkPresentation

/// Archivo IPA con metadatos de enlace: la hoja de compartir muestra su nombre e icono.
final class IPAShareItem: NSObject, UIActivityItemSource {
    let url: URL; let title: String; let icon: UIImage?
    init(url: URL, title: String, icon: UIImage?) { self.url = url; self.title = title; self.icon = icon }
    func activityViewControllerPlaceholderItem(_ c: UIActivityViewController) -> Any { url }
    func activityViewController(_ c: UIActivityViewController, itemForActivityType t: UIActivity.ActivityType?) -> Any? { url }
    func activityViewControllerLinkMetadata(_ c: UIActivityViewController) -> LPLinkMetadata? {
        let m = LPLinkMetadata()
        m.title = title
        m.originalURL = url
        if let icon { let p = NSItemProvider(object: icon); m.iconProvider = p; m.imageProvider = p }
        return m
    }
}

enum Share {
    static func presentItems(_ items: [Any]) {
        guard let top = UIKitBridge.topViewController() else { return }
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = top.view
        vc.popoverPresentationController?.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 0, height: 0)
        top.present(vc, animated: true)
    }

    static func present(_ url: URL) { present([url]) }

    /// Los IPA se comparten con nombre e icono (leídos de su Info.plist); el resto, como archivo normal.
    static func present(_ urls: [URL]) {
        let items: [Any] = urls.map { u in
            let ext = u.pathExtension.lowercased()
            guard ext == "ipa" || ext == "tipa", let meta = IPAReader.read(u) else { return u }
            return IPAShareItem(url: u, title: meta.name, icon: meta.icon)
        }
        presentItems(items)
    }
}

/// Cierra la app como si el usuario hiciera el gesto de ir a inicio y la descartara:
/// primero la lleva a la pantalla de inicio (animación del sistema) y luego termina el proceso.
enum AppCloser {
    @MainActor static func goHomeThenQuit(after delay: Double = 0.7) {
        UIControl().sendAction(#selector(URLSessionTask.suspend), to: UIApplication.shared, for: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { exit(0) }
    }
}
