import SwiftUI
import UIKit
import UniformTypeIdentifiers

// Puente con UIKit: selector de documentos y hoja de compartir.
// El selector usa asCopy: el sistema entrega una COPIA dentro de la app,
// así no dependemos de permisos de acceso (el fallo de fileImporter).

enum UIKitBridge {
    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            ?? scene?.windows.first?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}

final class PickerDelegate: NSObject, UIDocumentPickerDelegate {
    static var current: PickerDelegate?   // se retiene mientras el selector está abierto
    let onPick: ([URL]) -> Void
    init(_ onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        PickerDelegate.current = nil
        DispatchQueue.main.async { self.onPick(urls) }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        PickerDelegate.current = nil
    }
}

enum DocPicker {
    /// Copia a una carpeta temporal lo elegido en el sitio (archivos y carpetas), con acceso temporal
    /// y lectura coordinada. Devuelve las copias y el primer error, si lo hubo.
    private static func copyOpened(_ urls: [URL]) -> (copies: [URL], error: String?) {
        var copies: [URL] = []
        var firstError: String?
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("pick-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)
        for u in urls {
            let ok = u.startAccessingSecurityScopedResource()
            let dest = tmp.appendingPathComponent(u.lastPathComponent)
            var coordError: NSError?
            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: u, options: [], error: &coordError) { readURL in
                do { try FileManager.default.copyItem(at: readURL, to: dest); copies.append(dest) }
                catch { if firstError == nil { firstError = error.localizedDescription } }
            }
            if let e = coordError, firstError == nil { firstError = e.localizedDescription }
            if ok { u.stopAccessingSecurityScopedResource() }
        }
        return (copies, firstError)
    }

    /// Elegir una carpeta completa: se entra en ella y se toca «Abrir». iOS exige abrirla en el sitio
    /// (asCopy: false); con asCopy: true la app se cierra.
    static func presentFolders(onError: ((String) -> Void)? = nil, onPick: @escaping ([URL]) -> Void) {
        guard let top = UIKitBridge.topViewController() else { return }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false
        let delegate = PickerDelegate { urls in
            // La copia se hace fuera del hilo principal para no bloquear la app.
            DispatchQueue.global(qos: .userInitiated).async {
                let r = copyOpened(urls)
                DispatchQueue.main.async {
                    if r.copies.isEmpty { onError?(r.error ?? "iOS no entregó ninguna carpeta.") }
                    else { onPick(r.copies) }
                }
            }
        }
        PickerDelegate.current = delegate
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    /// Pega lo que se copió en la app Archivos de iOS (archivos o carpetas completas).
    static func pasteFromPasteboard(onError: @escaping (String) -> Void, onPick: @escaping ([URL]) -> Void) {
        let providers = UIPasteboard.general.itemProviders
        guard !providers.isEmpty else {
            onError("No hay nada copiado. En Archivos, mantén presionada la carpeta y toca Copiar.")
            return
        }
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("paste-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)
        let group = DispatchGroup()
        let lock = NSLock()
        var copies: [URL] = []
        var firstError: String?
        for p in providers {
            let ids = p.registeredTypeIdentifiers
            let id = ids.first(where: { UTType($0)?.conforms(to: .folder) == true })
                ?? ids.first(where: { UTType($0)?.conforms(to: .item) == true })
            guard let id else { continue }
            group.enter()
            p.loadFileRepresentation(forTypeIdentifier: id) { url, error in
                defer { group.leave() }
                guard let url else {
                    lock.lock(); if firstError == nil { firstError = error?.localizedDescription ?? "No se pudo leer lo copiado." }; lock.unlock()
                    return
                }
                // El archivo temporal se borra al salir de este bloque: se copia aquí mismo.
                let name = url.lastPathComponent
                let dest = tmp.appendingPathComponent(name)
                do {
                    try FileManager.default.copyItem(at: url, to: dest)
                    lock.lock(); copies.append(dest); lock.unlock()
                } catch {
                    lock.lock(); if firstError == nil { firstError = error.localizedDescription }; lock.unlock()
                }
            }
        }
        group.notify(queue: .main) {
            if copies.isEmpty { onError(firstError ?? "Lo copiado no es un archivo ni una carpeta.") }
            else { onPick(copies) }
        }
    }

    /// allowFolders: se pueden elegir archivos Y carpetas a la vez (las carpetas se seleccionan con «Seleccionar»).
    static func present(multiple: Bool = true, allowFolders: Bool = false, onPick: @escaping ([URL]) -> Void) {
        guard let top = UIKitBridge.topViewController() else { return }
        let picker: UIDocumentPickerViewController
        let delegate: PickerDelegate
        if allowFolders {
            picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item, .folder], asCopy: false)
            delegate = PickerDelegate { onPick(copyOpened($0).copies) }
        } else {
            // .item cubre cualquier archivo y paquete (.framework, .bundle, .app).
            picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item, .data, .content, .package], asCopy: true)
            delegate = PickerDelegate(onPick)
        }
        picker.allowsMultipleSelection = multiple
        PickerDelegate.current = delegate
        picker.delegate = delegate
        top.present(picker, animated: true)
    }
}

import LinkPresentation

/// Archivo IPA con metadatos de enlace: la hoja de compartir muestra su nombre e icono.
final class IPAShareItem: NSObject, UIActivityItemSource {
    let url: URL; let title: String; let icon: UIImage?
    init(url: URL, title: String, icon: UIImage?) { self.url = url; self.title = title; self.icon = icon }
    func activityViewControllerPlaceholderItem(_ c: UIActivityViewController) -> Any { url }
    func activityViewController(_ c: UIActivityViewController, itemForActivityType t: UIActivity.ActivityType?) -> Any? { url }
    func activityViewControllerLinkMetadata(_ c: UIActivityViewController) -> LPLinkMetadata? {
        let m = LPLinkMetadata()
        m.title = title
        m.originalURL = url
        if let icon { let p = NSItemProvider(object: icon); m.iconProvider = p; m.imageProvider = p }
        return m
    }
}

enum Share {
    static func presentItems(_ items: [Any]) {
        guard let top = UIKitBridge.topViewController() else { return }
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = top.view
        vc.popoverPresentationController?.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 0, height: 0)
        top.present(vc, animated: true)
    }

    static func present(_ url: URL) { present([url]) }

    /// Los IPA se comparten con nombre e icono (leídos de su Info.plist); el resto, como archivo normal.
    static func present(_ urls: [URL]) {
        let items: [Any] = urls.map { u in
            let ext = u.pathExtension.lowercased()
            guard ext == "ipa" || ext == "tipa", let meta = IPAReader.read(u) else { return u }
            return IPAShareItem(url: u, title: meta.name, icon: meta.icon)
        }
        presentItems(items)
    }
}

/// Cierra la app como si el usuario hiciera el gesto de ir a inicio y la descartara:
/// primero la lleva a la pantalla de inicio (animación del sistema) y luego termina el proceso.
enum AppCloser {
    @MainActor static func goHomeThenQuit(after delay: Double = 0.7) {
        UIControl().sendAction(#selector(URLSessionTask.suspend), to: UIApplication.shared, for: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { exit(0) }
    }
}
