import SwiftUI
import UIKit
import UniformTypeIdentifiers

// Puente con UIKit: selector de documentos y hoja de compartir.
// El selector usa asCopy: el sistema entrega una COPIA dentro de la app,
// así no dependemos de permisos de acceso (el fallo de fileImporter).

enum UIKitBridge {
    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            ?? scene?.windows.first?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}

final class PickerDelegate: NSObject, UIDocumentPickerDelegate {
    static var current: PickerDelegate?   // se retiene mientras el selector está abierto
    let onPick: ([URL]) -> Void
    init(_ onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        PickerDelegate.current = nil
        DispatchQueue.main.async { self.onPick(urls) }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        PickerDelegate.current = nil
    }
}

enum DocPicker {
    static func present(multiple: Bool = true, onPick: @escaping ([URL]) -> Void) {
        guard let top = UIKitBridge.topViewController() else { return }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        picker.allowsMultipleSelection = multiple
        let delegate = PickerDelegate(onPick)
        PickerDelegate.current = delegate
        picker.delegate = delegate
        top.present(picker, animated: true)
    }
}

enum Share {
    static func present(_ url: URL) {
        guard let top = UIKitBridge.topViewController() else { return }
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = top.view
        vc.popoverPresentationController?.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 0, height: 0)
        top.present(vc, animated: true)
    }
}
