import SwiftUI

@main
struct AZASingApp: App {
    @StateObject private var ipas = FileStore(.ipas)
    @StateObject private var tweaks = FileStore(.tweaks)
    @StateObject private var signed = FileStore(.signed)
    @StateObject private var certs = CertStore()

    init() {
        let bar = UITabBarAppearance()
        bar.configureWithOpaqueBackground()
        bar.backgroundColor = .black
        UITabBar.appearance().standardAppearance = bar
        UITabBar.appearance().scrollEdgeAppearance = bar
    }

    var body: some Scene {
        WindowGroup {
            TabView {
                SignView(ipas: ipas, tweaks: tweaks, signed: signed, certs: certs)
                    .tabItem { Label("Firmar", systemImage: "signature") }
                FilesView(ipas: ipas, tweaks: tweaks, signed: signed)
                    .tabItem { Label("Archivos", systemImage: "folder") }
                CertificatesView(certs: certs)
                    .tabItem { Label("Certificados", systemImage: "checkmark.seal") }
            }
            .tint(.gold)
            .preferredColorScheme(.dark)
        }
    }
}
