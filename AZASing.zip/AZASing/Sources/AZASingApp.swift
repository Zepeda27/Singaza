import SwiftUI

@main
struct AZASingApp: App {
    @StateObject private var ipas = FileStore(.ipas)
    @StateObject private var tweaks = FileStore(.tweaks)
    @StateObject private var signed = FileStore(.signed)
    @StateObject private var certs = CertStore()
    @StateObject private var incoming = Incoming()
    @AppStorage("accentHex") private var accentHex = "FFC733"
    @AppStorage("appearance") private var appearance = 0   // 0 sistema, 1 claro, 2 oscuro

    init() {
        UserDefaults.standard.register(defaults: ["installAfterSign": false, "appendSuffix": true,
                                                  "compression": 1, "accentHex": "FFC733"])
    }

    var body: some Scene {
        WindowGroup {
            TabView(selection: $incoming.selectedTab) {
                ProjectsView(ipas: ipas, tweaks: tweaks, signed: signed, certs: certs)
                    .tabItem { Label("Proyectos", systemImage: "shippingbox") }.tag(0)
                SignedView(signed: signed)
                    .tabItem { Label("Firmadas", systemImage: "checkmark.circle") }.tag(1)
                FilesView()
                    .tabItem { Label("Archivos", systemImage: "folder") }.tag(2)
                SettingsView(certs: certs, incoming: incoming)
                    .tabItem { Label("Ajustes", systemImage: "gearshape") }.tag(3)
            }
            .tint(Color(hex: accentHex))
            .preferredColorScheme(appearance == 1 ? .light : (appearance == 2 ? .dark : nil))
            .onOpenURL { handle($0) }
        }
    }

    /// Archivos que llegan desde el menú Compartir / "Abrir con".
    private func handle(_ url: URL) {
        switch url.pathExtension.lowercased() {
        case "ipa", "tipa":
            ipas.importFiles([url]); incoming.selectedTab = 0
        case "dylib", "deb", "framework":
            tweaks.importFiles([url]); incoming.selectedTab = 2
        case "p12", "pfx":
            if let c = Staging.copy(url) { incoming.p12 = c; incoming.showAddCert = true; incoming.selectedTab = 3 }
        case "mobileprovision":
            if let c = Staging.copy(url) { incoming.profile = c; incoming.showAddCert = true; incoming.selectedTab = 3 }
        default: break
        }
        if url.path.contains("/Inbox/") { try? FileManager.default.removeItem(at: url) }
    }
}
