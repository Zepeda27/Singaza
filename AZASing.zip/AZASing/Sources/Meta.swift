import UIKit
import ZIPFoundation

struct AppMeta {
    var name: String
    var bundleID: String
    var version: String
    var icon: UIImage?
    var signed = false      // el IPA lleva _CodeSignature (firmado) o no (solo modificado)
}

enum IPAReader {
    static func read(_ url: URL) -> AppMeta? {
        guard let archive = try? Archive(url: url, accessMode: .read) else { return nil }
        guard let infoEntry = archive.first(where: { e -> Bool in
            let c = e.path.split(separator: "/")
            return c.count == 3 && c[0] == "Payload" && c[1].hasSuffix(".app") && c[2] == "Info.plist"
        }) else { return nil }

        var data = Data()
        _ = try? archive.extract(infoEntry) { data.append($0) }
        guard let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any]
        else { return nil }

        let name = (plist["CFBundleDisplayName"] as? String)
            ?? (plist["CFBundleName"] as? String)
            ?? url.deletingPathExtension().lastPathComponent
        let bundleID = plist["CFBundleIdentifier"] as? String ?? ""
        let version = plist["CFBundleShortVersionString"] as? String ?? ""

        // Icono: busca el PNG más grande que coincida con los nombres declarados.
        var names: [String] = []
        if let icons = plist["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
           let files = primary["CFBundleIconFiles"] as? [String] { names = files }
        if names.isEmpty, let files = plist["CFBundleIconFiles"] as? [String] { names = files }

        let appDir = infoEntry.path.replacingOccurrences(of: "Info.plist", with: "")
        let candidates = archive.filter { e -> Bool in
            guard e.path.hasPrefix(appDir), e.path.hasSuffix(".png") else { return false }
            let rest = e.path.dropFirst(appDir.count)
            if rest.contains("/") { return false }
            return names.contains(where: { rest.hasPrefix($0) }) || rest.hasPrefix("AppIcon")
        }
        var icon: UIImage?
        if let best = candidates.max(by: { $0.uncompressedSize < $1.uncompressedSize }) {
            var png = Data()
            _ = try? archive.extract(best) { png.append($0) }
            icon = UIImage(data: png)
        }
        let signed = archive[appDir + "_CodeSignature/CodeResources"] != nil
        return AppMeta(name: name, bundleID: bundleID, version: version, icon: icon, signed: signed)
    }

    private struct StopReading: Error {}

    /// Librerías propias (no del sistema) que carga el ejecutable principal de un IPA.
    static func libraries(_ url: URL) -> [String] {
        guard let archive = try? Archive(url: url, accessMode: .read),
              let infoEntry = archive.first(where: { e -> Bool in
                  let c = e.path.split(separator: "/")
                  return c.count == 3 && c[0] == "Payload" && c[1].hasSuffix(".app") && c[2] == "Info.plist"
              }) else { return [] }
        var info = Data()
        _ = try? archive.extract(infoEntry) { info.append($0) }
        guard let plist = try? PropertyListSerialization.propertyList(from: info, options: [], format: nil) as? [String: Any],
              let exec = plist["CFBundleExecutable"] as? String,
              let entry = archive[infoEntry.path.replacingOccurrences(of: "Info.plist", with: exec)] else { return [] }
        var head = Data()
        do {
            _ = try archive.extract(entry, bufferSize: 65536) { chunk in
                head.append(chunk)
                if head.count > 2_500_000 { throw StopReading() }
            }
        } catch {}
        return MachOInjector.dylibs(in: head)
    }

    /// Plugins (dylib) que ya lleva el IPA, con el ejecutable que los carga: principal o extensiones (.appex).
    static func injectedLibs(_ url: URL) -> [InjectedLib] {
        guard let archive = try? Archive(url: url, accessMode: .read),
              let infoEntry = archive.first(where: { e -> Bool in
                  let c = e.path.split(separator: "/")
                  return c.count == 3 && c[0] == "Payload" && c[1].hasSuffix(".app") && c[2] == "Info.plist"
              }) else { return [] }
        let appDir = infoEntry.path.replacingOccurrences(of: "Info.plist", with: "")

        func plist(_ e: Entry) -> [String: Any]? {
            var d = Data(); _ = try? archive.extract(e) { d.append($0) }
            return (try? PropertyListSerialization.propertyList(from: d, options: [], format: nil)) as? [String: Any]
        }
        func head(_ e: Entry) -> Data {
            var h = Data()
            do { _ = try archive.extract(e, bufferSize: 65536) { c in h.append(c); if h.count > 2_500_000 { throw StopReading() } } } catch {}
            return h
        }

        var hosts: [(rel: String, label: String, isMain: Bool, entry: Entry)] = []
        if let p = plist(infoEntry), let exec = p["CFBundleExecutable"] as? String, let e = archive[appDir + exec] {
            hosts.append((exec, "Ejecutable principal", true, e))
        }
        for e in archive where e.path.hasPrefix(appDir + "PlugIns/") && e.path.hasSuffix(".appex/Info.plist") {
            guard let p = plist(e), let exec = p["CFBundleExecutable"] as? String else { continue }
            let folder = e.path.replacingOccurrences(of: "/Info.plist", with: "")
            guard let bin = archive[folder + "/" + exec] else { continue }
            let label = ((folder as NSString).lastPathComponent as NSString).deletingPathExtension
            hosts.append((String(folder.dropFirst(appDir.count)) + "/" + exec, label, false, bin))
        }

        var out: [InjectedLib] = []
        for h in hosts {
            for path in MachOInjector.dylibs(in: head(h.entry)) {
                let name = (path as NSString).lastPathComponent
                guard name.lowercased().hasSuffix(".dylib") || path.hasPrefix("@executable_path/") || InjectionScanner.hinted(name) else { continue }
                out.append(InjectedLib(key: h.rel + "\t" + path, name: name, path: path, host: h.label, isMain: h.isMain))
            }
        }
        return out
    }
}

extension IPAReader {
    /// Saca de dentro del IPA el archivo (dylib o framework) de un plugin y lo deja en una carpeta temporal.
    static func extractLib(ipa: URL, lib: InjectedLib) -> URL? {
        guard let archive = try? Archive(url: ipa, accessMode: .read),
              let infoEntry = archive.first(where: { e -> Bool in
                  let c = e.path.split(separator: "/")
                  return c.count == 3 && c[0] == "Payload" && c[1].hasSuffix(".app") && c[2] == "Info.plist"
              }) else { return nil }
        let appDir = infoEntry.path.replacingOccurrences(of: "Info.plist", with: "")
        let hostRel = lib.key.components(separatedBy: "\t").first ?? ""
        let hostParent = ((appDir + hostRel) as NSString).deletingLastPathComponent + "/"

        var rel = lib.path
        for pre in ["@executable_path/", "@loader_path/", "@rpath/"] where rel.hasPrefix(pre) { rel = String(rel.dropFirst(pre.count)) }
        var targets = [rel]
        if let r = rel.range(of: ".framework/") { targets = [String(rel[..<r.upperBound].dropLast())] }
        let bases = [hostParent, appDir, appDir + "Frameworks/", hostParent + "Frameworks/"]

        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("plugin-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)

        for t in targets {
            for b in bases {
                let full = b + t
                let name = (t as NSString).lastPathComponent
                if let e = archive[full], e.type == .file {
                    let dest = tmp.appendingPathComponent(name)
                    if (try? archive.extract(e, to: dest)) != nil { return dest }
                }
                let inside = archive.filter { $0.path.hasPrefix(full + "/") }
                if !inside.isEmpty {
                    let root = tmp.appendingPathComponent(name)
                    for e in inside {
                        let dest = root.appendingPathComponent(String(e.path.dropFirst(full.count + 1)))
                        try? FileManager.default.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
                        if e.type == .directory { try? FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true) }
                        else { _ = try? archive.extract(e, to: dest) }
                    }
                    return root
                }
            }
        }
        return nil
    }
}

struct InjectedLib: Identifiable, Hashable {
    var id: String { key }
    let key: String      // "<ejecutable relativo>\t<ruta del load command>"
    let name: String
    let path: String
    let host: String
    let isMain: Bool
}
