import UIKit
import ZIPFoundation

struct AppMeta {
    var name: String
    var bundleID: String
    var version: String
    var icon: UIImage?
}

enum IPAReader {
    static func read(_ url: URL) -> AppMeta? {
        guard let archive = try? Archive(url: url, accessMode: .read) else { return nil }
        guard let infoEntry = archive.first(where: { e -> Bool in
            let c = e.path.split(separator: "/")
            return c.count == 3 && c[0] == "Payload" && c[1].hasSuffix(".app") && c[2] == "Info.plist"
        }) else { return nil }

        var data = Data()
        _ = try? archive.extract(infoEntry) { data.append($0) }
        guard let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any]
        else { return nil }

        let name = (plist["CFBundleDisplayName"] as? String)
            ?? (plist["CFBundleName"] as? String)
            ?? url.deletingPathExtension().lastPathComponent
        let bundleID = plist["CFBundleIdentifier"] as? String ?? ""
        let version = plist["CFBundleShortVersionString"] as? String ?? ""

        // Icono: busca el PNG más grande que coincida con los nombres declarados.
        var names: [String] = []
        if let icons = plist["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
           let files = primary["CFBundleIconFiles"] as? [String] { names = files }
        if names.isEmpty, let files = plist["CFBundleIconFiles"] as? [String] { names = files }

        let appDir = infoEntry.path.replacingOccurrences(of: "Info.plist", with: "")
        let candidates = archive.filter { e -> Bool in
            guard e.path.hasPrefix(appDir), e.path.hasSuffix(".png") else { return false }
            let rest = e.path.dropFirst(appDir.count)
            if rest.contains("/") { return false }
            return names.contains(where: { rest.hasPrefix($0) }) || rest.hasPrefix("AppIcon")
        }
        var icon: UIImage?
        if let best = candidates.max(by: { $0.uncompressedSize < $1.uncompressedSize }) {
            var png = Data()
            _ = try? archive.extract(best) { png.append($0) }
            icon = UIImage(data: png)
        }
        return AppMeta(name: name, bundleID: bundleID, version: version, icon: icon)
    }
}
