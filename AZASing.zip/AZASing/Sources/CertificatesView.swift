import SwiftUI

struct CertificatesView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming
    @AppStorage("udid") private var udid = ""

    var body: some View {
            List {
                if certs.items.isEmpty {
                    Text("Aún no tienes certificados. Toca + para agregar uno.")
                        .foregroundStyle(.secondary).listRowBackground(Color.clear)
                }
                ForEach(certs.items) { c in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(c.name).font(.headline)
                            if !c.teamName.isEmpty { Text(c.teamName).font(.caption).foregroundStyle(.secondary) }
                            if let devices = c.devices, !udid.isEmpty {
                                let ok = devices.contains { $0.caseInsensitiveCompare(udid) == .orderedSame }
                                Label(ok ? "Incluye este iPhone" : "No incluye este iPhone", systemImage: ok ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .font(.caption).foregroundStyle(ok ? .green : .red)
                            }
                            if let e = c.expiry {
                                Text((c.isExpired ? "Caducó " : "Caduca ") + e.formatted(date: .abbreviated, time: .omitted))
                                    .font(.caption).foregroundStyle(c.isExpired ? .red : .secondary)
                            }
                        }
                        Spacer()
                        if certs.defaultID == c.id {
                            Image(systemName: "star.fill").foregroundStyle(Color.gold)
                        }
                    }
                    .listRowBackground(Color.clear)
                    .swipeActions {
                        Button(role: .destructive) { certs.delete(c) } label: { Label("Eliminar", systemImage: "trash") }
                        Button { certs.defaultID = c.id } label: { Label("Predeterminado", systemImage: "star") }
                            .tint(.gold)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .keyboardDone()
            .background(AppBackground())
            .navigationTitle("Certificados")
            .toolbar {
                Button { incoming.p12 = nil; incoming.profile = nil; incoming.showAddCert = true } label: {
                    Image(systemName: "plus")
                }
            }
    }
}

struct AddCertificateView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming

    private enum Pick { case p12, profile }

    @State private var name = ""
    @State private var password = ""
    @State private var error: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Nombre (opcional)", text: $name)
                    Button { pick(.p12) } label: {
                        Label(incoming.p12.map { Self.shortName($0) } ?? "Elegir archivo .p12", systemImage: "key")
                    }
                    Button { pick(.profile) } label: {
                        Label(incoming.profile.map { Self.shortName($0) } ?? "Elegir .mobileprovision", systemImage: "doc.badge.gearshape")
                    }
                    SecureField("Contraseña del .p12", text: $password)
                }
                if let error {
                    Text(error).foregroundStyle(.red).font(.footnote)
                }
                Section {
                    Button("Guardar certificado") { save() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(incoming.p12 == nil || incoming.profile == nil)
                        .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .keyboardDone()
            .background(AppBackground())
            .navigationTitle("Nuevo certificado")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { incoming.showAddCert = false } }
        }
    }

    /// El nombre real, sin el prefijo UUID de la copia temporal.
    private static func shortName(_ url: URL) -> String {
        let n = url.lastPathComponent
        if let r = n.range(of: "-"), n.distance(from: n.startIndex, to: r.lowerBound) >= 32 {
            return String(n[r.upperBound...])
        }
        return n
    }

    private func pick(_ kind: Pick) {
        DocPicker.present(multiple: false) { urls in
            guard let url = urls.first else { return }
            let valid = kind == .p12 ? ["p12", "pfx"] : ["mobileprovision"]
            guard valid.contains(url.pathExtension.lowercased()) else {
                error = "Elige un archivo .\(valid[0])."
                return
            }
            error = nil
            if kind == .p12 { incoming.p12 = url } else { incoming.profile = url }
        }
    }

    private func save() {
        guard let p12 = incoming.p12, let profile = incoming.profile else { return }
        do {
            try certs.add(name: name.trimmingCharacters(in: .whitespaces), p12: p12, profile: profile, password: password)
            incoming.showAddCert = false
        } catch {
            self.error = error.localizedDescription
        }
    }
}
