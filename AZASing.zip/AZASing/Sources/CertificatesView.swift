import SwiftUI
import UniformTypeIdentifiers

struct CertificatesView: View {
    @ObservedObject var certs: CertStore
    @State private var showAdd = false

    var body: some View {
        NavigationStack {
            List {
                if certs.items.isEmpty {
                    Text("Aún no tienes certificados. Toca + para agregar uno.").foregroundStyle(.secondary)
                }
                ForEach(certs.items) { c in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(c.name).font(.headline)
                            if !c.teamName.isEmpty { Text(c.teamName).font(.caption).foregroundStyle(.secondary) }
                            if let e = c.expiry {
                                Text((c.isExpired ? "Caducó " : "Caduca ") + e.formatted(date: .abbreviated, time: .omitted))
                                    .font(.caption).foregroundStyle(c.isExpired ? .red : .secondary)
                            }
                        }
                        Spacer()
                        if certs.defaultID == c.id {
                            Image(systemName: "star.fill").foregroundStyle(Color.gold)
                        }
                    }
                    .swipeActions {
                        Button(role: .destructive) { certs.delete(c) } label: { Label("Eliminar", systemImage: "trash") }
                        Button { certs.defaultID = c.id } label: { Label("Predeterminado", systemImage: "star") }
                            .tint(.gold)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Certificados")
            .toolbar { Button { showAdd = true } label: { Image(systemName: "plus") } }
            .sheet(isPresented: $showAdd) { AddCertificateView(certs: certs) }
        }
    }
}

struct AddCertificateView: View {
    @ObservedObject var certs: CertStore
    @Environment(\.dismiss) private var dismiss

    private enum Pick { case p12, profile }

    @State private var name = ""
    @State private var password = ""
    @State private var p12: URL?
    @State private var profile: URL?
    @State private var pending: Pick = .p12
    @State private var showPicker = false
    @State private var error: String?

    private var types: [UTType] {
        switch pending {
        case .p12: return [UTType(filenameExtension: "p12") ?? .data, UTType(filenameExtension: "pfx") ?? .data]
        case .profile: return [UTType(filenameExtension: "mobileprovision") ?? .data]
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Nombre (opcional)", text: $name)
                    Button { pending = .p12; showPicker = true } label: {
                        Label(p12?.lastPathComponent ?? "Elegir archivo .p12", systemImage: "key")
                    }
                    Button { pending = .profile; showPicker = true } label: {
                        Label(profile?.lastPathComponent ?? "Elegir .mobileprovision", systemImage: "doc.badge.gearshape")
                    }
                    SecureField("Contraseña del .p12", text: $password)
                }
                if let error {
                    Text(error).foregroundStyle(.red).font(.footnote)
                }
                Section {
                    Button("Guardar certificado") { save() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(p12 == nil || profile == nil)
                        .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Nuevo certificado")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
            .fileImporter(isPresented: $showPicker, allowedContentTypes: types) { result in
                guard case .success(let url) = result else { return }
                let copy = stage(url)
                if pending == .p12 { p12 = copy } else { profile = copy }
            }
        }
    }

    /// Copia el archivo elegido a una carpeta temporal para no depender del acceso del selector.
    private func stage(_ url: URL) -> URL? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
        do { try FileManager.default.copyItem(at: url, to: dest); return dest } catch { return nil }
    }

    private func save() {
        guard let p12, let profile else { return }
        do {
            try certs.add(name: name.trimmingCharacters(in: .whitespaces), p12: p12, profile: profile, password: password)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }
}
