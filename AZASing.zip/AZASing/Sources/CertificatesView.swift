import SwiftUI
import UniformTypeIdentifiers

struct CertificatesView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming

    var body: some View {
        NavigationStack {
            List {
                if certs.items.isEmpty {
                    Text("Aún no tienes certificados. Toca + para agregar uno.").foregroundStyle(.secondary)
                }
                ForEach(certs.items) { c in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(c.name).font(.headline)
                            if !c.teamName.isEmpty { Text(c.teamName).font(.caption).foregroundStyle(.secondary) }
                            if let e = c.expiry {
                                Text((c.isExpired ? "Caducó " : "Caduca ") + e.formatted(date: .abbreviated, time: .omitted))
                                    .font(.caption).foregroundStyle(c.isExpired ? .red : .secondary)
                            }
                        }
                        Spacer()
                        if certs.defaultID == c.id {
                            Image(systemName: "star.fill").foregroundStyle(Color.gold)
                        }
                    }
                    .swipeActions {
                        Button(role: .destructive) { certs.delete(c) } label: { Label("Eliminar", systemImage: "trash") }
                        Button { certs.defaultID = c.id } label: { Label("Predeterminado", systemImage: "star") }
                            .tint(.gold)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Certificados")
            .toolbar { Button { incoming.p12 = nil; incoming.profile = nil; incoming.showAddCert = true } label: { Image(systemName: "plus") } }
            .sheet(isPresented: $incoming.showAddCert) { AddCertificateView(certs: certs, incoming: incoming) }
        }
    }
}

struct AddCertificateView: View {
    @ObservedObject var certs: CertStore
    @ObservedObject var incoming: Incoming

    private enum Pick { case p12, profile }

    @State private var name = ""
    @State private var password = ""
    @State private var pending: Pick = .p12
    @State private var showPicker = false
    @State private var error: String?

    private var types: [UTType] {
        switch pending {
        case .p12: return [UTType(filenameExtension: "p12") ?? .data, UTType(filenameExtension: "pfx") ?? .data]
        case .profile: return [UTType(filenameExtension: "mobileprovision") ?? .data]
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Nombre (opcional)", text: $name)
                    Button { pending = .p12; showPicker = true } label: {
                        Label(incoming.p12?.lastPathComponent ?? "Elegir archivo .p12", systemImage: "key")
                    }
                    Button { pending = .profile; showPicker = true } label: {
                        Label(incoming.profile?.lastPathComponent ?? "Elegir .mobileprovision", systemImage: "doc.badge.gearshape")
                    }
                    SecureField("Contraseña del .p12", text: $password)
                }
                if let error {
                    Text(error).foregroundStyle(.red).font(.footnote)
                }
                Section {
                    Button("Guardar certificado") { save() }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(incoming.p12 == nil || incoming.profile == nil)
                        .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Nuevo certificado")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { incoming.showAddCert = false } }
            .fileImporter(isPresented: $showPicker, allowedContentTypes: types) { result in
                guard case .success(let url) = result else { return }
                let copy = Staging.copy(url)
                if pending == .p12 { incoming.p12 = copy } else { incoming.profile = copy }
            }
        }
    }

    private func save() {
        guard let p12 = incoming.p12, let profile = incoming.profile else { return }
        do {
            try certs.add(name: name.trimmingCharacters(in: .whitespaces), p12: p12, profile: profile, password: password)
            incoming.showAddCert = false
        } catch {
            self.error = error.localizedDescription
        }
    }
}
