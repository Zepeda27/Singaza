import SwiftUI

// MARK: - Cola de firmado: varias apps seguidas con los ajustes actuales

struct QueueSignView: View {
    let items: [FileItem]
    let metas: [URL: AppMeta]
    @ObservedObject var certs: CertStore
    @ObservedObject var signed: FileStore
    @Environment(\.dismiss) private var dismiss

    @AppStorage("signMode") private var signMode = "sign"
    @AppStorage("removeURLSchemes") private var removeURLs = false
    @AppStorage("removeWatch") private var removeWatch = false
    @AppStorage("fileAccess") private var fileAccess = false
    @AppStorage("fixJBDeps") private var fixJBDeps = false
    @AppStorage("fixWhiteIcon") private var fixWhiteIcon = false
    @AppStorage("removeProfile") private var removeProfile = false
    @AppStorage("gameMode") private var gameMode = false
    @AppStorage("unlockFPS") private var unlockFPS = false
    @AppStorage("compression") private var compression = 1
    @AppStorage("suffix") private var suffix = "-TGC"
    @AppStorage("exportFormat") private var exportFormat = "ipa"

    enum JobState: Equatable { case pending, working, done, failed(String) }

    @State private var certID: UUID?
    @State private var states: [URL: JobState] = [:]
    @State private var running = false
    @State private var cancelled = false
    @State private var finished = false

    private var skip: Bool { signMode == "inject" }
    private var cert: Certificate? { certs.items.first { $0.id == certID } }
    private var doneCount: Int { states.values.filter { $0 == .done }.count }

    var body: some View {
        NavigationStack {
            List {
                if !skip {
                    Section("Certificado") {
                        if certs.items.isEmpty {
                            Text("Primero agrega un certificado en Ajustes.").foregroundStyle(.secondary)
                        } else {
                            Picker("Firmar con", selection: $certID) {
                                ForEach(certs.items) { Text($0.name).tag(Optional($0.id)) }
                            }
                        }
                    }
                }
                Section {
                    Picker("Modo", selection: $signMode) {
                        Text("Firmar").tag("sign")
                        Text("Solo empaquetar").tag("inject")
                    }
                    .pickerStyle(.segmented)
                    .disabled(running)
                } footer: {
                    Text("Se usan tus ajustes de firma actuales y el sufijo \(suffix). Cada app queda en Firmadas.")
                }
                Section("Apps (\(items.count))") {
                    ForEach(items) { item in
                        HStack(spacing: 12) {
                            if let icon = metas[item.url]?.icon {
                                Image(uiImage: icon).resizable().scaledToFill().frame(width: 40, height: 40)
                                    .clipShape(RoundedRectangle(cornerRadius: 9))
                            } else {
                                Image(systemName: "app.dashed").foregroundColor(.gold).frame(width: 40, height: 40)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text(metas[item.url]?.name ?? item.name).lineLimit(1)
                                if case .failed(let m) = states[item.url] ?? .pending {
                                    Text(m).font(.caption).foregroundColor(.red).lineLimit(3)
                                }
                            }
                            Spacer()
                            statusIcon(states[item.url] ?? .pending)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Cola de firmado")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(running ? "Detener" : "Cerrar") {
                        if running { cancelled = true } else { dismiss() }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button { start() } label: {
                    Text(running ? "Firmando…" : (finished ? "Listo: \(doneCount) de \(items.count)" : (skip ? "Empaquetar \(items.count)" : "Firmar \(items.count)")))
                }
                .buttonStyle(GoldButtonStyle())
                .disabled(running || finished || (!skip && cert == nil))
                .padding(.horizontal).padding(.vertical, 8)
            }
            .onAppear { if certID == nil { certID = certs.defaultID ?? certs.items.first?.id } }
        }
        .interactiveDismissDisabled(running)
    }

    @ViewBuilder
    private func statusIcon(_ s: JobState) -> some View {
        switch s {
        case .pending: Image(systemName: "clock").foregroundStyle(.secondary)
        case .working: ProgressView()
        case .done: Image(systemName: "checkmark.circle.fill").foregroundColor(.green)
        case .failed: Image(systemName: "xmark.octagon.fill").foregroundColor(.red)
        }
    }

    private func start() {
        running = true; cancelled = false; finished = false
        for it in items { states[it.url] = .pending }
        let useCert = skip ? nil : cert
        Task {
            for it in items {
                if cancelled { break }
                states[it.url] = .working
                let opts = SignOptions(ipa: it.url, cert: useCert, tweaks: [],
                                       bundleID: "", displayName: "", version: "",
                                       removeURLSchemes: removeURLs, removeWatch: removeWatch,
                                       compress: compression != 0, outputName: "", suffix: suffix,
                                       ext: exportFormat, iconData: nil, removeLibraries: [],
                                       injectRPath: UserDefaults.standard.string(forKey: "injectPath") == "rpath",
                                       injectInFrameworks: (UserDefaults.standard.string(forKey: "injectFolder") ?? "frameworks") == "frameworks",
                                       plistExtras: [:], debSelection: [:],
                                       skipSign: skip, fileAccess: fileAccess, fixJailbreakDeps: fixJBDeps,
                                       fixWhiteIcon: fixWhiteIcon, removeProfile: removeProfile,
                                       removeExtensions: removeWatch, gameMode: gameMode, unlockFPS: unlockFPS)
                do {
                    _ = try await Signer.run(opts, outputFolder: Folder.signed.url) { _ in }
                    states[it.url] = .done
                } catch {
                    states[it.url] = .failed(error.localizedDescription)
                }
                signed.refresh()
            }
            running = false
            finished = true
        }
    }
}
