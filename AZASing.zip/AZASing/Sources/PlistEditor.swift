import SwiftUI
import UIKit

// MARK: - Árbol editable de un plist

final class PNode: ObservableObject, Identifiable {
    enum Kind: String, CaseIterable {
        case dict = "Diccionario", array = "Arreglo", string = "Texto", int = "Entero"
        case real = "Decimal", bool = "Booleano", date = "Fecha", data = "Datos"
        var isContainer: Bool { self == .dict || self == .array }
    }

    let id = UUID()
    @Published var kind: Kind
    @Published var key: String
    @Published var children: [PNode] = []
    @Published var text = ""
    @Published var flag = false
    @Published var date = Date()
    var raw = Data()

    init(key: String, kind: Kind) {
        self.key = key
        self.kind = kind
    }

    convenience init(key: String, value: Any) {
        if let d = value as? [String: Any] {
            self.init(key: key, kind: .dict)
            children = d.keys.sorted().map { PNode(key: $0, value: d[$0]!) }
        } else if let a = value as? [Any] {
            self.init(key: key, kind: .array)
            children = a.enumerated().map { PNode(key: "Elemento \($0.offset)", value: $0.element) }
        } else if let s = value as? String {
            self.init(key: key, kind: .string); text = s
        } else if let n = value as? NSNumber {
            if CFGetTypeID(n) == CFBooleanGetTypeID() { self.init(key: key, kind: .bool); flag = n.boolValue }
            else if CFNumberIsFloatType(n) { self.init(key: key, kind: .real); text = "\(n.doubleValue)" }
            else { self.init(key: key, kind: .int); text = "\(n.int64Value)" }
        } else if let dt = value as? Date {
            self.init(key: key, kind: .date); date = dt
        } else if let data = value as? Data {
            self.init(key: key, kind: .data); raw = data
        } else {
            self.init(key: key, kind: .string); text = "\(value)"
        }
    }

    func toAny() -> Any {
        switch kind {
        case .dict:
            var d: [String: Any] = [:]
            for c in children { d[c.key] = c.toAny() }
            return d
        case .array: return children.map { $0.toAny() }
        case .string: return text
        case .int: return Int(text.trimmingCharacters(in: .whitespaces)) ?? 0
        case .real: return Double(text.trimmingCharacters(in: .whitespaces)) ?? 0
        case .bool: return flag
        case .date: return date
        case .data: return raw
        }
    }
}

// MARK: - Editor de plist

struct PlistEditorView: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var root: PNode?
    @State private var format = PropertyListSerialization.PropertyListFormat.xml
    @State private var message: String?

    var body: some View {
        NavigationStack {
            Group {
                if let root {
                    PlistContainerView(node: root, title: url.lastPathComponent)
                } else {
                    Text(message ?? "Cargando…").foregroundStyle(.secondary)
                }
            }
            .background(AppBackground())
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) { Button("Guardar") { save() }.disabled(root == nil) }
            }
            .alert("Plist", isPresented: Binding(get: { message != nil && root != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
        .preferredColorScheme(.dark)
        .onAppear { load() }
    }

    private func load() {
        do {
            let data = try Data(contentsOf: url)
            var fmt = PropertyListSerialization.PropertyListFormat.xml
            let obj = try PropertyListSerialization.propertyList(from: data, options: [], format: &fmt)
            format = fmt
            root = PNode(key: "Raíz", value: obj)
        } catch {
            message = "No se pudo leer el plist: \(error.localizedDescription)"
        }
    }

    private func save() {
        guard let root else { return }
        do {
            let data = try PropertyListSerialization.data(fromPropertyList: root.toAny(), format: format, options: 0)
            try data.write(to: url)
            dismiss()
        } catch {
            message = "No se pudo guardar: \(error.localizedDescription)"
        }
    }
}

struct PlistContainerView: View {
    @ObservedObject var node: PNode
    let title: String

    var body: some View {
        List {
            ForEach(node.children) { child in
                if child.kind.isContainer {
                    NavigationLink {
                        PlistContainerView(node: child, title: child.key)
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(child.key).font(.headline)
                            Text("\(child.kind.rawValue) · \(child.children.count) elementos").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                } else {
                    PlistScalarRow(node: child, keyEditable: node.kind == .dict)
                }
            }
            .onDelete { node.children.remove(atOffsets: $0) }
        }
        .scrollContentBackground(.hidden)
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Menu {
                ForEach(PNode.Kind.allCases, id: \.self) { kind in
                    Button(kind.rawValue) { add(kind) }
                }
            } label: { Image(systemName: "plus") }
        }
    }

    private func add(_ kind: PNode.Kind) {
        let key = node.kind == .dict ? "NuevaClave\(node.children.count + 1)" : "Elemento \(node.children.count)"
        let n = PNode(key: key, kind: kind)
        if kind == .int || kind == .real { n.text = "0" }
        node.children.append(n)
    }
}

struct PlistScalarRow: View {
    @ObservedObject var node: PNode
    let keyEditable: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            if keyEditable {
                TextField("Clave", text: $node.key).font(.caption.weight(.semibold)).foregroundColor(.gold)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
            } else {
                Text(node.key).font(.caption.weight(.semibold)).foregroundColor(.gold)
            }
            switch node.kind {
            case .string:
                TextField("Valor", text: $node.text, axis: .vertical)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
            case .int, .real:
                TextField("Número", text: $node.text).keyboardType(.numbersAndPunctuation)
            case .bool:
                Toggle(node.flag ? "Sí" : "No", isOn: $node.flag)
            case .date:
                DatePicker("", selection: $node.date).labelsHidden()
            case .data:
                Text("Datos · \(node.raw.count) bytes").foregroundStyle(.secondary)
            default:
                EmptyView()
            }
            Text(node.kind.rawValue).font(.caption2).foregroundStyle(.secondary)
        }
    }
}

// MARK: - Editor de texto y vista previa de imagen

struct TextFileEditor: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var message: String?

    var body: some View {
        NavigationStack {
            TextEditor(text: $text)
                .font(.system(.footnote, design: .monospaced))
                .scrollContentBackground(.hidden)
                .padding(.horizontal)
                .background(AppBackground())
                .navigationTitle(url.lastPathComponent)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { Button("Cerrar") { dismiss() } }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Guardar") {
                            do { try text.write(to: url, atomically: false, encoding: .utf8); dismiss() }
                            catch { message = error.localizedDescription }
                        }
                    }
                }
                .alert("Error", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                    Button("OK", role: .cancel) {}
                } message: { Text(message ?? "") }
        }
        .preferredColorScheme(.dark)
        .onAppear { text = (try? String(contentsOf: url, encoding: .utf8)) ?? "" }
    }
}

struct ImagePreview: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Group {
                if let img = UIImage(contentsOfFile: url.path) {
                    Image(uiImage: img).resizable().scaledToFit().padding()
                } else {
                    Text("No se pudo abrir la imagen.").foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(AppBackground())
            .navigationTitle(url.lastPathComponent)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Cerrar") { dismiss() } }
        }
        .preferredColorScheme(.dark)
    }
}
