import Foundation
import UIKit
import ZIPFoundation

struct SignOptions {
    var ipa: URL
    var cert: Certificate
    var tweaks: [URL]
    var bundleID: String
    var displayName: String
    var version: String
    var removeURLSchemes = false
    var removeWatch = false
    var compress = true
    var outputName = ""
    var appendSuffix = true
    var ext = "ipa"
    var iconData: Data? = nil                 // logo nuevo (PNG/JPG)
    var removeLibraries: Set<String> = []     // rutas de load commands a quitar
    var injectRPath = false                   // @rpath en vez de @executable_path
    var injectInFrameworks = true             // Frameworks/ o raíz de la app
    var plistExtras: [String: String] = [:]   // claves a añadir/reemplazar en Info.plist
    var debSelection: [String: Set<String>] = [:]   // ruta del .deb → nombres a inyectar
}

enum Signer {
    /// Descomprime el IPA, edita Info.plist, inyecta tweaks, firma y vuelve a empaquetar.
    static func run(_ o: SignOptions, outputFolder: URL,
                    log: @escaping @MainActor (String) -> Void) async throws -> URL {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("azasing-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        await log("Descomprimiendo IPA…")
        try fm.unzipItem(at: o.ipa, to: work)

        let payload = work.appendingPathComponent("Payload")
        guard let appDir = try? fm.contentsOfDirectory(atPath: payload.path).first(where: { $0.hasSuffix(".app") })
        else { throw SignError.invalidIPA }
        let app = payload.appendingPathComponent(appDir)

        if o.removeWatch {
            await log("Quitando Apple Watch…")
            try? fm.removeItem(at: app.appendingPathComponent("Watch"))
            try? fm.removeItem(at: app.appendingPathComponent("com.apple.WatchPlaceholder"))
        }

        // Info.plist
        let infoURL = app.appendingPathComponent("Info.plist")
        guard let info = NSMutableDictionary(contentsOf: infoURL) else { throw SignError.invalidIPA }
        let oldID = info["CFBundleIdentifier"] as? String ?? ""

        if !o.bundleID.isEmpty {
            await log("Bundle ID → \(o.bundleID)")
            info["CFBundleIdentifier"] = o.bundleID
            try renameExtensions(in: app, oldID: oldID, newID: o.bundleID)
        }
        if !o.displayName.isEmpty {
            info["CFBundleDisplayName"] = o.displayName
            info["CFBundleName"] = o.displayName
        }
        if !o.version.isEmpty { info["CFBundleShortVersionString"] = o.version }
        if o.removeURLSchemes { info.removeObject(forKey: "CFBundleURLTypes") }
        for (k, v) in o.plistExtras where !k.isEmpty { info[k] = parseValue(v) }
        if let data = o.iconData, let image = UIImage(data: data) {
            await log("Cambiando el logo…")
            applyIcon(image, to: app, info: info)
        }
        guard info.write(to: infoURL, atomically: true) else { throw SignError.invalidIPA }

        // Quitar librerías existentes
        if !o.removeLibraries.isEmpty, let execName = info["CFBundleExecutable"] as? String {
            await log("Quitando \(o.removeLibraries.count) librería(s)…")
            try MachOInjector.remove(names: o.removeLibraries, from: app.appendingPathComponent(execName))
            for path in o.removeLibraries { removeFile(for: path, in: app) }
        }

        // Tweaks
        if !o.tweaks.isEmpty {
            guard let execName = info["CFBundleExecutable"] as? String else { throw SignError.invalidIPA }
            let execURL = app.appendingPathComponent(execName)
            let frameworks = app.appendingPathComponent("Frameworks", isDirectory: true)
            try fm.createDirectory(at: frameworks, withIntermediateDirectories: true)
            let cfg = InjectConfig(dir: o.injectInFrameworks ? frameworks : app,
                                   prefix: o.injectRPath ? "@rpath/" : (o.injectInFrameworks ? "@executable_path/Frameworks/" : "@executable_path/"))

            for tweak in o.tweaks {
                let name = tweak.lastPathComponent
                await log("Inyectando \(name)…")
                switch tweak.pathExtension.lowercased() {
                case "deb":
                    let tmp = work.appendingPathComponent("deb-\(UUID().uuidString)")
                    try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                    try DebKit.extractDeb(tweak, to: tmp)
                    var found = DebKit.collect(in: tmp)
                    if let only = o.debSelection[tweak.path] {
                        found.dylibs = found.dylibs.filter { only.contains($0.lastPathComponent) }
                        found.frameworks = found.frameworks.filter { only.contains($0.lastPathComponent) }
                        found.bundles = found.bundles.filter { only.contains($0.lastPathComponent) }
                    }
                    if found.dylibs.isEmpty && found.frameworks.isEmpty && found.bundles.isEmpty {
                        throw SignError.engine("No hay nada que inyectar del .deb \(name). Revisa los elementos elegidos.")
                    }
                    for d in found.dylibs { try injectDylib(d, cfg: cfg, exec: execURL) }
                    for f in found.frameworks { try injectFramework(f, cfg: cfg, exec: execURL) }
                    for bnd in found.bundles { try copyBundle(bnd, app: app) }
                case "framework": try injectFramework(tweak, cfg: cfg, exec: execURL)
                case "bundle": try copyBundle(tweak, app: app)
                default: try injectDylib(tweak, cfg: cfg, exec: execURL)
                }
            }
        }

        // Firma
        await log("Firmando con \(o.cert.name)…")
        try await ZsignEngine.sign(appPath: app.path,
                                   p12Path: o.cert.p12URL.path,
                                   password: o.cert.password,
                                   provisionPath: o.cert.provisionURL.path)

        // Empaquetado
        await log("Creando IPA firmado…")
        let base = (appDir as NSString).deletingPathExtension
        let custom = o.outputName.trimmingCharacters(in: .whitespaces)
        let name = (custom.isEmpty ? base : custom) + (o.appendSuffix ? "-AZASing" : "")
        let out = outputFolder.appendingPathComponent("\(name).\(o.ext)")
        if fm.fileExists(atPath: out.path) { try fm.removeItem(at: out) }
        try fm.zipItem(at: payload, to: out, shouldKeepParent: true, compressionMethod: o.compress ? .deflate : .none)
        return out
    }

    struct InjectConfig { let dir: URL; let prefix: String }

    private static func injectDylib(_ src: URL, cfg: InjectConfig, exec: URL) throws {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = cfg.dir.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        try MachOInjector.inject(loadPath: cfg.prefix + name, into: exec)
    }

    private static func injectFramework(_ src: URL, cfg: InjectConfig, exec: URL) throws {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = cfg.dir.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        let stem = src.deletingPathExtension().lastPathComponent
        let info = NSDictionary(contentsOf: dest.appendingPathComponent("Info.plist"))
        let bin = info?["CFBundleExecutable"] as? String ?? stem
        try MachOInjector.inject(loadPath: cfg.prefix + "\(name)/\(bin)", into: exec)
    }

    /// Borra del paquete el archivo al que apunta una ruta de librería (.dylib o .framework).
    private static func removeFile(for loadPath: String, in app: URL) {
        let fm = FileManager.default
        var rel = loadPath
        for p in ["@executable_path/", "@loader_path/", "@rpath/"] where rel.hasPrefix(p) { rel = String(rel.dropFirst(p.count)) }
        var candidates = [rel, "Frameworks/" + rel]
        if let r = rel.range(of: ".framework/") { candidates = [String(rel[..<r.upperBound].dropLast()), "Frameworks/" + String(rel[..<r.upperBound].dropLast())] }
        for c in candidates {
            let url = app.appendingPathComponent(c)
            if fm.fileExists(atPath: url.path) { try? fm.removeItem(at: url); return }
        }
    }

    private static func parseValue(_ s: String) -> Any {
        let t = s.trimmingCharacters(in: .whitespaces)
        if t.lowercased() == "true" { return true }
        if t.lowercased() == "false" { return false }
        if let i = Int(t) { return i }
        if let d = Double(t) { return d }
        return s
    }

    /// Sustituye el icono de la app por una imagen propia.
    private static func applyIcon(_ image: UIImage, to app: URL, info: NSMutableDictionary) {
        func png(_ side: CGFloat) -> Data? {
            let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
            let r = UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: fmt)
            return r.image { _ in image.draw(in: CGRect(x: 0, y: 0, width: side, height: side)) }.pngData()
        }
        let files: [(String, CGFloat)] = [("AZAIcon60x60@2x.png", 120), ("AZAIcon60x60@3x.png", 180),
                                          ("AZAIcon76x76@2x~ipad.png", 152), ("AZAIcon83.5x83.5@2x~ipad.png", 167)]
        for (name, side) in files { try? png(side)?.write(to: app.appendingPathComponent(name)) }
        info.removeObject(forKey: "CFBundleIconName")
        info["CFBundleIcons"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": ["AZAIcon60x60"]]]
        info["CFBundleIcons~ipad"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": ["AZAIcon60x60", "AZAIcon76x76", "AZAIcon83.5x83.5"]]]
    }

    /// Los .bundle (recursos del tweak) van en la raíz de la app.
    private static func copyBundle(_ src: URL, app: URL) throws {
        let fm = FileManager.default
        let dest = app.appendingPathComponent(src.lastPathComponent)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
    }

    /// Las extensiones (.appex) y apps de Watch deben seguir el nuevo Bundle ID.
    private static func renameExtensions(in app: URL, oldID: String, newID: String) throws {
        let fm = FileManager.default
        for sub in ["PlugIns", "Watch"] {
            let dir = app.appendingPathComponent(sub)
            guard let names = try? fm.contentsOfDirectory(atPath: dir.path) else { continue }
            for n in names where n.hasSuffix(".appex") || n.hasSuffix(".app") {
                let plist = dir.appendingPathComponent(n).appendingPathComponent("Info.plist")
                guard let d = NSMutableDictionary(contentsOf: plist),
                      let id = d["CFBundleIdentifier"] as? String, id.hasPrefix(oldID) else { continue }
                d["CFBundleIdentifier"] = newID + id.dropFirst(oldID.count)
                if d["WKCompanionAppBundleIdentifier"] != nil { d["WKCompanionAppBundleIdentifier"] = newID }
                d.write(to: plist, atomically: true)
            }
        }
    }
}
