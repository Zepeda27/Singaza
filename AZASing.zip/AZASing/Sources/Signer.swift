import Foundation
import UIKit
import ZIPFoundation

struct SignOptions {
    var ipa: URL
    var cert: Certificate?
    var tweaks: [URL]
    var bundleID: String
    var displayName: String
    var version: String
    var removeURLSchemes = false
    var removeWatch = false
    var compress = true
    var outputName = ""
    var suffix = "-AZASing"
    var ext = "ipa"
    var iconData: Data? = nil                 // logo nuevo (PNG/JPG)
    var removeLibraries: Set<String> = []     // rutas de load commands a quitar
    var injectRPath = false                   // @rpath en vez de @executable_path
    var injectInFrameworks = true             // Frameworks/ o raíz de la app
    var plistExtras: [String: String] = [:]   // claves a añadir/reemplazar en Info.plist
    var debSelection: [String: Set<String>] = [:]   // ruta del .deb → nombres a inyectar
    var skipSign = false                      // solo inyectar, sin certificado
    var fileAccess = false                    // acceso a archivos (Archivos app)
    var fixJailbreakDeps = false              // CydiaSubstrate/substitute → librería incluida
    var fixWhiteIcon = false
    var removeProfile = false                 // quitar embedded.mobileprovision
    var removeExtensions = false              // PlugIns / Extensions
    var gameMode = false
    var unlockFPS = false
    var copyIndex = 1                         // >1: copia con otro Bundle ID
}

enum Signer {
    /// Descomprime el IPA, edita Info.plist, inyecta tweaks, firma y vuelve a empaquetar.
    static func run(_ o: SignOptions, outputFolder: URL,
                    log: @escaping @MainActor (String) -> Void) async throws -> URL {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("azasing-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        await log("Descomprimiendo IPA…")
        try fm.unzipItem(at: o.ipa, to: work)

        let payload = work.appendingPathComponent("Payload")
        guard let appDir = try? fm.contentsOfDirectory(atPath: payload.path).first(where: { $0.hasSuffix(".app") })
        else { throw SignError.invalidIPA }
        let app = payload.appendingPathComponent(appDir)

        if o.removeWatch {
            await log("Quitando extensiones y Apple Watch…")
            for n in ["Watch", "com.apple.WatchPlaceholder", "PlugIns", "Extensions"] {
                try? fm.removeItem(at: app.appendingPathComponent(n))
            }
        }
        if o.removeProfile {
            try? fm.removeItem(at: app.appendingPathComponent("embedded.mobileprovision"))
        }

        // Info.plist
        let infoURL = app.appendingPathComponent("Info.plist")
        guard let info = NSMutableDictionary(contentsOf: infoURL) else { throw SignError.invalidIPA }
        let oldID = info["CFBundleIdentifier"] as? String ?? ""

        var newID = o.bundleID
        var newName = o.displayName
        if o.copyIndex > 1 {
            newID = (newID.isEmpty ? oldID : newID) + ".\(o.copyIndex)"
            let base = newName.isEmpty ? (info["CFBundleDisplayName"] as? String ?? info["CFBundleName"] as? String ?? "") : newName
            newName = "\(base) \(o.copyIndex)"
        }
        if !newID.isEmpty {
            await log("Bundle ID → \(newID)")
            info["CFBundleIdentifier"] = newID
            try renameExtensions(in: app, oldID: oldID, newID: newID)
        }
        if !newName.isEmpty {
            info["CFBundleDisplayName"] = newName
            info["CFBundleName"] = newName
        }
        if o.fileAccess {
            info["UIFileSharingEnabled"] = true
            info["LSSupportsOpeningDocumentsInPlace"] = true
        }
        if o.gameMode {
            info["GCSupportsGameMode"] = true
            info["LSApplicationCategoryType"] = "public.app-category.games"
        }
        if o.unlockFPS { info["CADisableMinimumFrameDurationOnPhone"] = true }
        if o.fixWhiteIcon { fixIcons(app: app, info: info) }
        if !o.version.isEmpty { info["CFBundleShortVersionString"] = o.version }
        if o.removeURLSchemes { info.removeObject(forKey: "CFBundleURLTypes") }
        for (k, v) in o.plistExtras where !k.isEmpty { info[k] = parseValue(v) }
        if let data = o.iconData, let image = UIImage(data: data) {
            await log("Cambiando el logo…")
            applyIcon(image, to: app, info: info)
        }
        guard info.write(to: infoURL, atomically: true) else { throw SignError.invalidIPA }

        // Quitar librerías existentes
        if !o.removeLibraries.isEmpty, let execName = info["CFBundleExecutable"] as? String {
            await log("Quitando \(o.removeLibraries.count) librería(s)…")
            try MachOInjector.remove(names: o.removeLibraries, from: app.appendingPathComponent(execName))
            for path in o.removeLibraries { removeFile(for: path, in: app) }
        }

        var injected: [URL] = []

        // Tweaks
        if !o.tweaks.isEmpty {
            guard let execName = info["CFBundleExecutable"] as? String else { throw SignError.invalidIPA }
            let execURL = app.appendingPathComponent(execName)
            let frameworks = app.appendingPathComponent("Frameworks", isDirectory: true)
            try fm.createDirectory(at: frameworks, withIntermediateDirectories: true)
            let cfg = InjectConfig(dir: o.injectInFrameworks ? frameworks : app,
                                   prefix: o.injectRPath ? "@rpath/" : (o.injectInFrameworks ? "@executable_path/Frameworks/" : "@executable_path/"))

            for tweak in o.tweaks {
                let name = tweak.lastPathComponent
                await log("Inyectando \(name)…")
                switch tweak.pathExtension.lowercased() {
                case "deb":
                    let tmp = work.appendingPathComponent("deb-\(UUID().uuidString)")
                    try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                    try DebKit.extractDeb(tweak, to: tmp)
                    var found = DebKit.collect(in: tmp)
                    if let only = o.debSelection[tweak.path] {
                        found.dylibs = found.dylibs.filter { only.contains($0.lastPathComponent) }
                        found.frameworks = found.frameworks.filter { only.contains($0.lastPathComponent) }
                        found.bundles = found.bundles.filter { only.contains($0.lastPathComponent) }
                    }
                    if found.dylibs.isEmpty && found.frameworks.isEmpty && found.bundles.isEmpty {
                        throw SignError.engine("No hay nada que inyectar del .deb \(name). Revisa los elementos elegidos.")
                    }
                    for d in found.dylibs { injected.append(try injectDylib(d, cfg: cfg, exec: execURL)) }
                    for f in found.frameworks { injected.append(try injectFramework(f, cfg: cfg, exec: execURL)) }
                    for bnd in found.bundles { try copyBundle(bnd, app: app) }
                case "framework": injected.append(try injectFramework(tweak, cfg: cfg, exec: execURL))
                case "bundle": try copyBundle(tweak, app: app)
                default: injected.append(try injectDylib(tweak, cfg: cfg, exec: execURL))
                }
            }
            if o.fixJailbreakDeps {
                await log("Corrigiendo dependencias de jailbreak…")
                let msg = fixJailbreakDependencies(app: app, binaries: injected)
                if !msg.isEmpty { await log(msg) }
            }
        }

        // Firma
        if o.skipSign {
            await log("Firma omitida (solo inyección).")
        } else {
            guard let cert = o.cert else { throw SignError.engine("Falta elegir un certificado.") }
            await log("Firmando con \(cert.name)…")
            try await ZsignEngine.sign(appPath: app.path,
                                       p12Path: cert.p12URL.path,
                                       password: cert.password,
                                       provisionPath: cert.provisionURL.path)
        }

        // Empaquetado
        await log(o.skipSign ? "Creando IPA sin firmar…" : "Creando IPA firmado…")
        let base = (appDir as NSString).deletingPathExtension
        let custom = o.outputName.trimmingCharacters(in: .whitespaces)
        let name = (custom.isEmpty ? base : custom) + o.suffix + (o.copyIndex > 1 ? "-\(o.copyIndex)" : "")
        let out = outputFolder.appendingPathComponent("\(name).\(o.ext)")
        if fm.fileExists(atPath: out.path) { try fm.removeItem(at: out) }
        try fm.zipItem(at: payload, to: out, shouldKeepParent: true, compressionMethod: o.compress ? .deflate : .none)
        return out
    }

    struct InjectConfig { let dir: URL; let prefix: String }

    @discardableResult
    private static func injectDylib(_ src: URL, cfg: InjectConfig, exec: URL) throws -> URL {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = cfg.dir.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        try MachOInjector.inject(loadPath: cfg.prefix + name, into: exec)
        return dest
    }

    @discardableResult
    private static func injectFramework(_ src: URL, cfg: InjectConfig, exec: URL) throws -> URL {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = cfg.dir.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        let stem = src.deletingPathExtension().lastPathComponent
        let info = NSDictionary(contentsOf: dest.appendingPathComponent("Info.plist"))
        let bin = info?["CFBundleExecutable"] as? String ?? stem
        try MachOInjector.inject(loadPath: cfg.prefix + "\(name)/\(bin)", into: exec)
        return dest.appendingPathComponent(bin)
    }

    /// Borra del paquete el archivo al que apunta una ruta de librería (.dylib o .framework).
    private static func removeFile(for loadPath: String, in app: URL) {
        let fm = FileManager.default
        var rel = loadPath
        for p in ["@executable_path/", "@loader_path/", "@rpath/"] where rel.hasPrefix(p) { rel = String(rel.dropFirst(p.count)) }
        var candidates = [rel, "Frameworks/" + rel]
        if let r = rel.range(of: ".framework/") { candidates = [String(rel[..<r.upperBound].dropLast()), "Frameworks/" + String(rel[..<r.upperBound].dropLast())] }
        for c in candidates {
            let url = app.appendingPathComponent(c)
            if fm.fileExists(atPath: url.path) { try? fm.removeItem(at: url); return }
        }
    }

    private static func parseValue(_ s: String) -> Any {
        let t = s.trimmingCharacters(in: .whitespaces)
        if t.lowercased() == "true" { return true }
        if t.lowercased() == "false" { return false }
        if let i = Int(t) { return i }
        if let d = Double(t) { return d }
        return s
    }

    /// Sustituye el icono de la app por una imagen propia.
    private static func applyIcon(_ image: UIImage, to app: URL, info: NSMutableDictionary) {
        func png(_ side: CGFloat) -> Data? {
            let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
            let r = UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: fmt)
            return r.image { _ in image.draw(in: CGRect(x: 0, y: 0, width: side, height: side)) }.pngData()
        }
        let files: [(String, CGFloat)] = [("AZAIcon60x60@2x.png", 120), ("AZAIcon60x60@3x.png", 180),
                                          ("AZAIcon76x76@2x~ipad.png", 152), ("AZAIcon83.5x83.5@2x~ipad.png", 167)]
        for (name, side) in files { try? png(side)?.write(to: app.appendingPathComponent(name)) }
        info.removeObject(forKey: "CFBundleIconName")
        info["CFBundleIcons"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": ["AZAIcon60x60"]]]
        info["CFBundleIcons~ipad"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": ["AZAIcon60x60", "AZAIcon76x76", "AZAIcon83.5x83.5"]]]
    }

    /// Cambia las dependencias de Substrate/Substitute de los tweaks por una librería incluida en la app.
    private static func fixJailbreakDependencies(app: URL, binaries: [URL]) -> String {
        let fm = FileManager.default
        let frameworks = app.appendingPathComponent("Frameworks")
        try? fm.createDirectory(at: frameworks, withIntermediateDirectories: true)
        // ¿Qué proveedor hay en la app o en la biblioteca del usuario?
        let providers: [(file: String, path: String)] = [
            ("CydiaSubstrate.framework", "@rpath/CydiaSubstrate.framework/CydiaSubstrate"),
            ("libellekit.dylib", "@rpath/libellekit.dylib"),
            ("libsubstrate.dylib", "@rpath/libsubstrate.dylib")]
        var target: String?
        for pr in providers where fm.fileExists(atPath: frameworks.appendingPathComponent(pr.file).path) { target = pr.path; break }
        if target == nil {
            let lib = TweakScanner.scan()
            for pr in providers {
                if let src = lib.first(where: { $0.lastPathComponent == pr.file }) {
                    let dest = frameworks.appendingPathComponent(pr.file)
                    if (try? fm.copyItem(at: src, to: dest)) != nil { target = pr.path; break }
                }
            }
        }
        guard let target else {
            return "No encontré CydiaSubstrate.framework, libellekit.dylib ni libsubstrate.dylib en tu carpeta Tweaks; añade uno para corregir las dependencias."
        }
        var changed = 0, skipped = 0
        for b in binaries {
            let r = (try? MachOInjector.rewriteDependencies(in: b) { old in
                let l = old.lowercased()
                if l.contains("cydiasubstrate") || l.contains("libsubstrate") || l.contains("libsubstitute") || l.contains("libellekit") {
                    return old == target ? nil : target
                }
                return nil
            }) ?? (0, 0)
            changed += r.0; skipped += r.1
        }
        return "Dependencias corregidas: \(changed)" + (skipped > 0 ? " (\(skipped) no cabían)" : "")
    }

    /// Reparar iconos en blanco: usa los PNG del paquete en vez del catálogo.
    private static func fixIcons(app: URL, info: NSMutableDictionary) {
        let names = ((try? FileManager.default.contentsOfDirectory(atPath: app.path)) ?? [])
            .filter { $0.lowercased().hasSuffix(".png") && ($0.hasPrefix("AppIcon") || $0.contains("60x60") || $0.contains("76x76")) }
        var stems = Set<String>()
        for n in names {
            var t = (n as NSString).deletingPathExtension
            for suf in ["~ipad", "@2x", "@3x"] { t = t.replacingOccurrences(of: suf, with: "") }
            stems.insert(t)
        }
        guard !stems.isEmpty else { return }
        let list = stems.sorted()
        info.removeObject(forKey: "CFBundleIconName")
        info["CFBundleIcons"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": list]]
        info["CFBundleIcons~ipad"] = ["CFBundlePrimaryIcon": ["CFBundleIconFiles": list]]
    }

    /// Los .bundle (recursos del tweak) van en la raíz de la app.
    private static func copyBundle(_ src: URL, app: URL) throws {
        let fm = FileManager.default
        let dest = app.appendingPathComponent(src.lastPathComponent)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
    }

    /// Las extensiones (.appex) y apps de Watch deben seguir el nuevo Bundle ID.
    private static func renameExtensions(in app: URL, oldID: String, newID: String) throws {
        let fm = FileManager.default
        for sub in ["PlugIns", "Watch"] {
            let dir = app.appendingPathComponent(sub)
            guard let names = try? fm.contentsOfDirectory(atPath: dir.path) else { continue }
            for n in names where n.hasSuffix(".appex") || n.hasSuffix(".app") {
                let plist = dir.appendingPathComponent(n).appendingPathComponent("Info.plist")
                guard let d = NSMutableDictionary(contentsOf: plist),
                      let id = d["CFBundleIdentifier"] as? String, id.hasPrefix(oldID) else { continue }
                d["CFBundleIdentifier"] = newID + id.dropFirst(oldID.count)
                if d["WKCompanionAppBundleIdentifier"] != nil { d["WKCompanionAppBundleIdentifier"] = newID }
                d.write(to: plist, atomically: true)
            }
        }
    }
}
