import Foundation
import ZIPFoundation

struct SignOptions {
    var ipa: URL
    var cert: Certificate
    var tweaks: [URL]
    var bundleID: String
    var displayName: String
    var version: String
    var removeURLSchemes = false
    var removeWatch = false
    var compress = true
    var outputName = ""
    var appendSuffix = true
    var ext = "ipa"
}

enum Signer {
    /// Descomprime el IPA, edita Info.plist, inyecta tweaks, firma y vuelve a empaquetar.
    static func run(_ o: SignOptions, outputFolder: URL,
                    log: @escaping @MainActor (String) -> Void) async throws -> URL {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("azasing-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        await log("Descomprimiendo IPA…")
        try fm.unzipItem(at: o.ipa, to: work)

        let payload = work.appendingPathComponent("Payload")
        guard let appDir = try? fm.contentsOfDirectory(atPath: payload.path).first(where: { $0.hasSuffix(".app") })
        else { throw SignError.invalidIPA }
        let app = payload.appendingPathComponent(appDir)

        if o.removeWatch {
            await log("Quitando Apple Watch…")
            try? fm.removeItem(at: app.appendingPathComponent("Watch"))
            try? fm.removeItem(at: app.appendingPathComponent("com.apple.WatchPlaceholder"))
        }

        // Info.plist
        let infoURL = app.appendingPathComponent("Info.plist")
        guard let info = NSMutableDictionary(contentsOf: infoURL) else { throw SignError.invalidIPA }
        let oldID = info["CFBundleIdentifier"] as? String ?? ""

        if !o.bundleID.isEmpty {
            await log("Bundle ID → \(o.bundleID)")
            info["CFBundleIdentifier"] = o.bundleID
            try renameExtensions(in: app, oldID: oldID, newID: o.bundleID)
        }
        if !o.displayName.isEmpty {
            info["CFBundleDisplayName"] = o.displayName
            info["CFBundleName"] = o.displayName
        }
        if !o.version.isEmpty { info["CFBundleShortVersionString"] = o.version }
        if o.removeURLSchemes { info.removeObject(forKey: "CFBundleURLTypes") }
        guard info.write(to: infoURL, atomically: true) else { throw SignError.invalidIPA }

        // Tweaks
        if !o.tweaks.isEmpty {
            guard let execName = info["CFBundleExecutable"] as? String else { throw SignError.invalidIPA }
            let execURL = app.appendingPathComponent(execName)
            let frameworks = app.appendingPathComponent("Frameworks", isDirectory: true)
            try fm.createDirectory(at: frameworks, withIntermediateDirectories: true)

            for tweak in o.tweaks {
                let name = tweak.lastPathComponent
                await log("Inyectando \(name)…")
                switch tweak.pathExtension.lowercased() {
                case "deb":
                    let tmp = work.appendingPathComponent("deb-\(UUID().uuidString)")
                    try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                    try DebKit.extractDeb(tweak, to: tmp)
                    let found = DebKit.collect(in: tmp)
                    if found.dylibs.isEmpty && found.frameworks.isEmpty && found.bundles.isEmpty {
                        throw SignError.engine("El .deb \(name) no contiene dylibs, frameworks ni bundles.")
                    }
                    for d in found.dylibs { try injectDylib(d, app: app, frameworks: frameworks, exec: execURL) }
                    for f in found.frameworks { try injectFramework(f, app: app, frameworks: frameworks, exec: execURL) }
                    for bnd in found.bundles { try copyBundle(bnd, app: app) }
                case "framework": try injectFramework(tweak, app: app, frameworks: frameworks, exec: execURL)
                case "bundle": try copyBundle(tweak, app: app)
                default: try injectDylib(tweak, app: app, frameworks: frameworks, exec: execURL)
                }
            }
        }

        // Firma
        await log("Firmando con \(o.cert.name)…")
        try await ZsignEngine.sign(appPath: app.path,
                                   p12Path: o.cert.p12URL.path,
                                   password: o.cert.password,
                                   provisionPath: o.cert.provisionURL.path)

        // Empaquetado
        await log("Creando IPA firmado…")
        let base = (appDir as NSString).deletingPathExtension
        let custom = o.outputName.trimmingCharacters(in: .whitespaces)
        let name = (custom.isEmpty ? base : custom) + (o.appendSuffix ? "-AZASing" : "")
        let out = outputFolder.appendingPathComponent("\(name).\(o.ext)")
        if fm.fileExists(atPath: out.path) { try fm.removeItem(at: out) }
        try fm.zipItem(at: payload, to: out, shouldKeepParent: true, compressionMethod: o.compress ? .deflate : .none)
        return out
    }

    private static func injectDylib(_ src: URL, app: URL, frameworks: URL, exec: URL) throws {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = frameworks.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        try MachOInjector.inject(loadPath: "@executable_path/Frameworks/\(name)", into: exec)
    }

    private static func injectFramework(_ src: URL, app: URL, frameworks: URL, exec: URL) throws {
        let fm = FileManager.default
        let name = src.lastPathComponent
        let dest = frameworks.appendingPathComponent(name)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
        let stem = src.deletingPathExtension().lastPathComponent
        let info = NSDictionary(contentsOf: dest.appendingPathComponent("Info.plist"))
        let bin = info?["CFBundleExecutable"] as? String ?? stem
        try MachOInjector.inject(loadPath: "@executable_path/Frameworks/\(name)/\(bin)", into: exec)
    }

    /// Los .bundle (recursos del tweak) van en la raíz de la app.
    private static func copyBundle(_ src: URL, app: URL) throws {
        let fm = FileManager.default
        let dest = app.appendingPathComponent(src.lastPathComponent)
        if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
        try fm.copyItem(at: src, to: dest)
    }

    /// Las extensiones (.appex) y apps de Watch deben seguir el nuevo Bundle ID.
    private static func renameExtensions(in app: URL, oldID: String, newID: String) throws {
        let fm = FileManager.default
        for sub in ["PlugIns", "Watch"] {
            let dir = app.appendingPathComponent(sub)
            guard let names = try? fm.contentsOfDirectory(atPath: dir.path) else { continue }
            for n in names where n.hasSuffix(".appex") || n.hasSuffix(".app") {
                let plist = dir.appendingPathComponent(n).appendingPathComponent("Info.plist")
                guard let d = NSMutableDictionary(contentsOf: plist),
                      let id = d["CFBundleIdentifier"] as? String, id.hasPrefix(oldID) else { continue }
                d["CFBundleIdentifier"] = newID + id.dropFirst(oldID.count)
                if d["WKCompanionAppBundleIdentifier"] != nil { d["WKCompanionAppBundleIdentifier"] = newID }
                d.write(to: plist, atomically: true)
            }
        }
    }
}
