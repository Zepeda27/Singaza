import SwiftUI
import UIKit
import Security

// MARK: - Tema (negro + dorado)

extension Color {
    /// Sigue el color de acento elegido en Ajustes.
    static let gold = Color.accentColor
    static let goldDeep = Color.accentColor.opacity(0.65)
    static let card = Color(white: 0.09)

    init(hex: String) {
        var v: UInt64 = 0
        Scanner(string: hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))).scanHexInt64(&v)
        self.init(red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255, blue: Double(v & 0xFF) / 255)
    }

    var hexString: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

extension LinearGradient {
    static let gold = LinearGradient(colors: [Color.gold, Color.goldDeep], startPoint: .top, endPoint: .bottom)
}

struct GoldButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        let label = configuration.label
            .font(.headline)
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
        Group {
            #if compiler(>=6.2)
            if #available(iOS 26.0, *) {
                label.glassEffect(.regular.tint(Color.gold).interactive(), in: .rect(cornerRadius: 18))
            } else {
                label.background(LinearGradient.gold).clipShape(RoundedRectangle(cornerRadius: 18))
            }
            #else
            label.background(LinearGradient.gold).clipShape(RoundedRectangle(cornerRadius: 18))
            #endif
        }
        .opacity(enabled ? (configuration.isPressed ? 0.85 : 1) : 0.4)
    }
}

// MARK: - Liquid Glass (iOS 26+, con respaldo para versiones anteriores)

extension View {
    @ViewBuilder
    func glassCard(cornerRadius: CGFloat = 22) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius))
        }
        #else
        self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius))
        #endif
    }
}

/// Fondo con destellos del color de acento: negro en oscuro, blanco en claro.
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        let dark = scheme == .dark
        ZStack {
            (dark ? Color.black : Color(white: 0.98))
            Circle().fill(Color.gold.opacity(dark ? 0.30 : 0.20)).frame(width: 340, height: 340)
                .blur(radius: 90).offset(x: -150, y: -290)
            Circle().fill(Color.goldDeep.opacity(dark ? 0.32 : 0.18)).frame(width: 300, height: 300)
                .blur(radius: 100).offset(x: 160, y: 270)
        }
        .ignoresSafeArea()
    }
}
