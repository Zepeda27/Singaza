import SwiftUI
import Security

// MARK: - Tema (negro + dorado)

extension Color {
    static let gold = Color(red: 1.0, green: 0.78, blue: 0.2)
    static let goldDeep = Color(red: 0.72, green: 0.5, blue: 0.08)
    static let card = Color(white: 0.09)
}

extension LinearGradient {
    static let gold = LinearGradient(colors: [Color(red: 1, green: 0.88, blue: 0.4), .gold, .goldDeep],
                                     startPoint: .top, endPoint: .bottom)
}

struct GoldButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(LinearGradient.gold)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .opacity(enabled ? (configuration.isPressed ? 0.8 : 1) : 0.35)
    }
}

// MARK: - Carpetas

enum Folder: String, CaseIterable, Identifiable {
    case ipas = "IPAs"
    case tweaks = "Tweaks"
    case signed = "Firmadas"
    case certs = "Certificados"

    var id: String { rawValue }

    var url: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent(rawValue, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
}

// MARK: - Llavero (contraseñas de los .p12)

enum Keychain {
    private static func query(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "AZASing",
         kSecAttrAccount as String: key]
    }

    static func set(_ value: String, for key: String) {
        SecItemDelete(query(key) as CFDictionary)
        var q = query(key)
        q[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(q as CFDictionary, nil)
    }

    static func get(_ key: String) -> String? {
        var q = query(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(_ key: String) {
        SecItemDelete(query(key) as CFDictionary)
    }
}

// MARK: - Data helpers (Mach-O)

extension Data {
    func u32(_ offset: Int, bigEndian: Bool = false) -> UInt32 {
        let v = withUnsafeBytes { $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self) }
        return bigEndian ? UInt32(bigEndian: v) : UInt32(littleEndian: v)
    }

    mutating func put32(_ value: UInt32, at offset: Int) {
        var le = value.littleEndian
        Swift.withUnsafeBytes(of: &le) { replaceSubrange(offset..<(offset + 4), with: $0) }
    }
}

// MARK: - Archivos recibidos desde "Compartir"

enum Staging {
    /// Copia un archivo a una carpeta temporal (para no depender del acceso original).
    static func copy(_ url: URL) -> URL? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
        do { try FileManager.default.copyItem(at: url, to: dest); return dest } catch { return nil }
    }
}

@MainActor
final class Incoming: ObservableObject {
    @Published var selectedTab = 0
    @Published var showAddCert = false
    @Published var p12: URL?
    @Published var profile: URL?
}
