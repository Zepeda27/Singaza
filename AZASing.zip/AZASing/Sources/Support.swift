import SwiftUI
import UIKit
import Security

// MARK: - Tema (negro + dorado)

extension Color {
    /// Sigue el color de acento elegido en Ajustes.
    static let gold = Color.accentColor
    static let goldDeep = Color.accentColor.opacity(0.65)
    static let card = Color(white: 0.09)

    init(hex: String) {
        var v: UInt64 = 0
        Scanner(string: hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))).scanHexInt64(&v)
        self.init(red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255, blue: Double(v & 0xFF) / 255)
    }

    var hexString: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

extension LinearGradient {
    static let gold = LinearGradient(colors: [Color.gold, Color.goldDeep], startPoint: .top, endPoint: .bottom)
}

struct GoldButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        let label = configuration.label
            .font(.headline)
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
        Group {
            #if compiler(>=6.2)
            if #available(iOS 26.0, *) {
                label.glassEffect(.regular.tint(Color.gold).interactive(), in: .rect(cornerRadius: 18))
            } else {
                label.background(LinearGradient.gold).clipShape(RoundedRectangle(cornerRadius: 18))
            }
            #else
            label.background(LinearGradient.gold).clipShape(RoundedRectangle(cornerRadius: 18))
            #endif
        }
        .opacity(enabled ? (configuration.isPressed ? 0.85 : 1) : 0.4)
    }
}

// MARK: - Liquid Glass (iOS 26+, con respaldo para versiones anteriores)

extension View {
    @ViewBuilder
    func glassCard(cornerRadius: CGFloat = 22) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: .rect(cornerRadius: cornerRadius)).contentShape(RoundedRectangle(cornerRadius: cornerRadius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius)).contentShape(RoundedRectangle(cornerRadius: cornerRadius))
        }
        #else
        self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius)).contentShape(RoundedRectangle(cornerRadius: cornerRadius))
        #endif
    }
}

/// Fondo con destellos del color de acento: negro en oscuro, blanco en claro.
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        let dark = scheme == .dark
        ZStack {
            (dark ? Color.black : Color(white: 0.98))
            Circle().fill(Color.gold.opacity(dark ? 0.30 : 0.20)).frame(width: 340, height: 340)
                .blur(radius: 90).offset(x: -150, y: -290)
            Circle().fill(Color.goldDeep.opacity(dark ? 0.32 : 0.18)).frame(width: 300, height: 300)
                .blur(radius: 100).offset(x: 160, y: 270)
        }
        .ignoresSafeArea()
    }
}

// MARK: - Carpetas

enum Folder: String, CaseIterable, Identifiable {
    case ipas = "IPAs"
    case tweaks = "Tweaks"
    case signed = "Firmadas"
    case certs = "Certificados"
    case workspaces = "Workspaces"

    var id: String { rawValue }

    var url: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent(rawValue, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
}

// MARK: - Llavero (contraseñas de los .p12)

enum Keychain {
    private static func query(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "AZASing",
         kSecAttrAccount as String: key]
    }

    static func set(_ value: String, for key: String) {
        SecItemDelete(query(key) as CFDictionary)
        var q = query(key)
        q[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(q as CFDictionary, nil)
    }

    static func get(_ key: String) -> String? {
        var q = query(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(_ key: String) {
        SecItemDelete(query(key) as CFDictionary)
    }
}

// MARK: - Data helpers (Mach-O)

extension Data {
    func u32(_ offset: Int, bigEndian: Bool = false) -> UInt32 {
        let v = withUnsafeBytes { $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self) }
        return bigEndian ? UInt32(bigEndian: v) : UInt32(littleEndian: v)
    }

    mutating func put32(_ value: UInt32, at offset: Int) {
        var le = value.littleEndian
        Swift.withUnsafeBytes(of: &le) { replaceSubrange(offset..<(offset + 4), with: $0) }
    }
}

// MARK: - Archivos recibidos desde "Compartir"

enum Staging {
    /// Copia un archivo a una carpeta temporal (para no depender del acceso original).
    static func copy(_ url: URL) -> URL? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
        do { try FileManager.default.copyItem(at: url, to: dest); return dest } catch { return nil }
    }
}

@MainActor
final class Incoming: ObservableObject {
    @Published var selectedTab = 0
    @Published var returnTab: Int?      // pestaña a la que volver tras abrir un Payload
    @Published var showAddCert = false
    @Published var p12: URL?
    @Published var profile: URL?
    @Published var openFolder: URL?     // carpeta que debe abrir la pestaña Archivos
    @Published var signRequest: URL?    // IPA (ya en APP) cuya hoja de firmado debe abrirse
    static weak var shared: Incoming?
    init() { Incoming.shared = self }
}


// MARK: - Teclado: se cierra al arrastrar, al tocar «Listo» sobre el teclado

extension View {
    func keyboardDone() -> some View {
        self
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Listo") {
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
                }
            }
    }
}


// MARK: - Deslizar una fila para ver su menú

struct SwipeAction: Identifiable {
    let id = UUID()
    var title: String
    var icon: String
    var tint: Color
    var run: () -> Void
}

private struct SwipeMenuModifier: ViewModifier {
    let actions: [SwipeAction]
    let cornerRadius: CGFloat
    let enabled: Bool
    @State private var offset: CGFloat = 0
    @State private var dragging = false
    @State private var startOffset: CGFloat = 0
    private let w: CGFloat = 70
    private var total: CGFloat { w * CGFloat(actions.count) }

    func body(content: Content) -> some View {
        content
            .offset(x: offset)
            .background(alignment: .trailing) {
                HStack(spacing: 0) {
                    ForEach(actions) { a in
                        Button {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { offset = 0 }
                            a.run()
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: a.icon).font(.title3)
                                Text(a.title).font(.caption2.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.7)
                            }
                            .foregroundColor(.white)
                            .frame(width: w).frame(maxHeight: .infinity)
                            .background(a.tint)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .frame(width: total)
                .opacity(offset < -1 ? 1 : 0)
            }
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            .simultaneousGesture(
                DragGesture(minimumDistance: 12)
                    .onChanged { g in
                        guard enabled else { return }
                        if !dragging {
                            // solo gestos claramente horizontales; el scroll vertical no se toca
                            guard abs(g.translation.width) > abs(g.translation.height) * 1.5 else { return }
                            dragging = true
                            startOffset = offset
                        }
                        offset = min(0, max(-total, startOffset + g.translation.width))
                    }
                    .onEnded { g in
                        guard dragging else { return }
                        dragging = false
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                            offset = offset < -total / 2 ? -total : 0
                        }
                    }
            )
            .onChange(of: enabled) { on in if !on { offset = 0 } }
    }
}

extension View {
    /// Al deslizar la fila hacia la izquierda aparecen botones de acción.
    func swipeMenu(_ actions: [SwipeAction], cornerRadius: CGFloat = 18, enabled: Bool = true) -> some View {
        modifier(SwipeMenuModifier(actions: actions, cornerRadius: cornerRadius, enabled: enabled))
    }
}
