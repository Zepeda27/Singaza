import SwiftUI
import UniformTypeIdentifiers

struct FilesView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var tweaks: FileStore
    @ObservedObject var signed: FileStore

    @State private var tab: Folder = .ipas
    @State private var showImporter = false
    @State private var renaming: FileItem?
    @State private var newName = ""

    private var store: FileStore {
        switch tab {
        case .ipas: return ipas
        case .tweaks: return tweaks
        default: return signed
        }
    }

    private var importTypes: [UTType] {
        switch tab {
        case .ipas: return [UTType(filenameExtension: "ipa") ?? .data, .zip]
        default: return [.item, .folder]
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Carpeta", selection: $tab) {
                    Text("IPAs").tag(Folder.ipas)
                    Text("Tweaks").tag(Folder.tweaks)
                    Text("Firmadas").tag(Folder.signed)
                }
                .pickerStyle(.segmented)
                .padding()

                List {
                    if store.items.isEmpty {
                        Text("No hay archivos todavía.").foregroundStyle(.secondary)
                    }
                    ForEach(store.items) { item in
                        row(item)
                            .swipeActions {
                                Button(role: .destructive) { store.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                            .contextMenu {
                                ShareLink(item: item.url) { Label("Compartir", systemImage: "square.and.arrow.up") }
                                Button { renaming = item; newName = item.name } label: {
                                    Label("Renombrar", systemImage: "pencil")
                                }
                                Button(role: .destructive) { store.delete(item) } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .background(Color.black)
            .navigationTitle("Archivos")
            .toolbar {
                if tab != .signed {
                    Button { showImporter = true } label: { Image(systemName: "plus") }
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: importTypes,
                          allowsMultipleSelection: true) { result in
                if case .success(let urls) = result { store.importFiles(urls) }
            }
            .alert("Renombrar", isPresented: Binding(get: { renaming != nil },
                                                      set: { if !$0 { renaming = nil } })) {
                TextField("Nombre", text: $newName)
                Button("Guardar") { if let r = renaming { store.rename(r, to: newName) }; renaming = nil }
                Button("Cancelar", role: .cancel) { renaming = nil }
            }
            .onAppear { store.refresh() }
            .onChange(of: tab) { _ in store.refresh() }
        }
    }

    private func row(_ item: FileItem) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon(item)).foregroundStyle(Color.gold).frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).lineLimit(1)
                Text(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func icon(_ item: FileItem) -> String {
        switch item.url.pathExtension.lowercased() {
        case "ipa": return "app.gift"
        case "dylib": return "puzzlepiece.extension"
        case "framework": return "shippingbox"
        default: return "doc"
        }
    }
}
