import SwiftUI
import ZIPFoundation
import ImageIO

@MainActor
final class Clipboard: ObservableObject {
    @Published var urls: [URL] = []
    @Published var isMove = false
    @Published var basket: [URL] = []      // elementos para crear un .deb
}

enum FKind {
    case folder, app, bundle, framework, executable, plist, provision, image, dylib
    case resource, text, archive, deb, p12, other

    var symbol: String {
        switch self {
        case .folder: return "folder.fill"
        case .app: return "app.badge"
        case .bundle: return "shippingbox.fill"
        case .framework: return "shippingbox"
        case .executable: return "terminal"
        case .plist: return "curlybraces.square"
        case .provision: return "checkmark.shield"
        case .image: return "photo"
        case .dylib: return "puzzlepiece.extension"
        case .resource: return "square.stack.3d.up"
        case .text: return "doc.text"
        case .archive: return "doc.zipper"
        case .deb: return "archivebox"
        case .p12: return "key"
        case .other: return "doc"
        }
    }

    var isContainer: Bool { self == .folder || self == .app || self == .bundle || self == .framework }
}

struct BrowserItem: Identifiable, Hashable {
    let url: URL
    let kind: FKind
    let size: Int64
    let date: Date
    let count: Int
    var subtitle: String? = nil
    var id: URL { url }
    var name: String { url.lastPathComponent }
    var isDir: Bool { kind.isContainer }
}

struct SimpleError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

// MARK: - Miniatura de imágenes

struct ThumbView: View {
    let item: BrowserItem
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: item.kind.symbol).font(.title2).foregroundColor(.gold)
            }
        }
        .frame(width: 44, height: 44)
        .clipShape(RoundedRectangle(cornerRadius: 9))
        .task(id: item.url) {
            guard item.kind == .image else { return }
            let url = item.url
            image = await Task.detached { () -> UIImage? in
                guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
                let opts: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                                             kCGImageSourceThumbnailMaxPixelSize: 128,
                                             kCGImageSourceCreateThumbnailWithTransform: true]
                guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return UIImage(contentsOfFile: url.path) }
                return UIImage(cgImage: cg)
            }.value
        }
    }
}

// MARK: - Raíz

struct FilesView: View {
    @StateObject private var clipboard = Clipboard()
    @ObservedObject var incoming: Incoming

    var body: some View {
        NavigationStack {
            BrowserView(dir: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0],
                        isRoot: true, clipboard: clipboard,
                        openRequest: incoming.openFolder, onOpened: { incoming.openFolder = nil })
        }
        .safeAreaInset(edge: .bottom, alignment: .leading) {
            if let back = incoming.returnTab, incoming.selectedTab == 2 {
                Button {
                    incoming.returnTab = nil
                    incoming.selectedTab = back
                } label: {
                    Label("Regresar", systemImage: "chevron.left")
                        .font(.subheadline.weight(.semibold)).foregroundColor(.gold)
                        .padding(.horizontal, 16).padding(.vertical, 9)
                }
                .buttonStyle(.plain)
                .glassCard(cornerRadius: 20)
                .padding(.leading, 16).padding(.bottom, 6)
            }
        }
        .onChange(of: incoming.selectedTab) { tab in if tab != 2 { incoming.returnTab = nil } }
    }
}

/// Descomprime un IPA en Workspaces/ (una sola vez) y devuelve su carpeta Payload.
enum WorkspaceOpener {
    static func prepare(ipa: URL) async -> URL? {
        await Task.detached { () -> URL? in
            let fm = FileManager.default
            let dest = Folder.workspaces.url.appendingPathComponent(ipa.deletingPathExtension().lastPathComponent)
            let payload = dest.appendingPathComponent("Payload")
            if !fm.fileExists(atPath: payload.path) {
                try? fm.removeItem(at: dest)
                do {
                    try fm.createDirectory(at: dest, withIntermediateDirectories: true)
                    try fm.unzipItem(at: ipa, to: dest)
                } catch { return nil }
            }
            return fm.fileExists(atPath: payload.path) ? payload : dest
        }.value
    }
}

// MARK: - Explorador

struct BrowserView: View {
    let dir: URL
    var isRoot = false
    @ObservedObject var clipboard: Clipboard
    var openRequest: URL? = nil
    var onOpened: () -> Void = {}

    @State private var items: [BrowserItem] = []
    @State private var results: [BrowserItem] = []
    @State private var query = ""
    @State private var openDir: URL?
    @State private var notice: String?
    @State private var busy = false

    @State private var renameTarget: BrowserItem?
    @State private var showRename = false
    @State private var newName = ""
    @State private var deleteTarget: BrowserItem?
    @State private var showDelete = false
    @State private var showNewFolder = false
    @State private var folderName = ""
    @State private var showDebName = false
    @State private var showTweakImport = false
    @State private var debTarget: URL?
    @State private var showDebExtract = false
    @State private var selecting = false
    @State private var selection = Set<URL>()
    @State private var showDeleteMany = false
    @State private var debName = ""

    @State private var plistURL: URL?
    @State private var textURL: URL?
    @State private var imageURL: URL?

    /// Dentro de Workspaces (Payload) los archivos importados REEMPLAZAN a los existentes.
    private var inWorkspace: Bool { dir.path.contains("/Workspaces/") }

    private var searching: Bool { !query.trimmingCharacters(in: .whitespaces).isEmpty }
    private var shown: [BrowserItem] { searching ? results : items }

    var body: some View {
        ScrollView {
            if shown.isEmpty {
                Text(searching ? "Sin resultados" : "Carpeta vacía").foregroundStyle(.secondary).padding(.top, 80)
            }
            LazyVStack(spacing: 10) {
                ForEach(shown) { item in rowView(item) }
            }
            .padding()
            if busy { ProgressView().padding() }
        }
        .background(AppBackground())
        .navigationTitle(isRoot ? "Archivos" : dir.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Buscar en subcarpetas")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack(spacing: 14) {
                    Button(selecting ? "Listo" : "Seleccionar") {
                        selecting.toggle()
                        if !selecting { selection = [] }
                    }
                    addMenu
                }
            }
        }
        .safeAreaInset(edge: .bottom) { if selecting { selectionBar } }
        .background(
            NavigationLink(isActive: Binding(get: { openDir != nil }, set: { if !$0 { openDir = nil } })) {
                if let d = openDir { BrowserView(dir: d, clipboard: clipboard) }
            } label: { EmptyView() }
            .hidden()
        )
        .task(id: query) { await runSearch() }
        .sheet(isPresented: $showTweakImport) { TweakImportView { importHere($0) } }
        .sheet(item: $plistURL) { PlistEditorView(url: $0).onDisappear { load() } }
        .sheet(item: $textURL) { TextFileEditor(url: $0).onDisappear { load() } }
        .sheet(item: $imageURL) { ImagePreview(url: $0) }
        .alert("Renombrar", isPresented: $showRename) {
            TextField("Nombre", text: $newName)
            Button("Guardar") { rename() }
            Button("Cancelar", role: .cancel) {}
        }
        .alert("Nueva carpeta", isPresented: $showNewFolder) {
            TextField("Nombre", text: $folderName)
            Button("Crear") { createFolder() }
            Button("Cancelar", role: .cancel) {}
        }
        .confirmationDialog("Extraer \(debTarget?.lastPathComponent ?? "")", isPresented: $showDebExtract, titleVisibility: .visible) {
            Button("Archivos completos") { if let u = debTarget { extractDeb(u, onlyDylibs: false) } }
            Button("Solo los dylib") { if let u = debTarget { extractDeb(u, onlyDylibs: true) } }
            Button("Cancelar", role: .cancel) {}
        } message: { Text("Completos: todo el contenido del .deb en una carpeta. Solo dylib: únicamente las librerías .dylib.") }
        .alert("Crear .deb", isPresented: $showDebName) {
            TextField("Nombre del paquete", text: $debName)
            Button("Crear") { createDeb() }
            Button("Cancelar", role: .cancel) {}
        } message: { Text("Se empaquetarán \(clipboard.basket.count) elemento(s).") }
        .confirmationDialog("¿Eliminar \(selection.count) elemento(s)?", isPresented: $showDeleteMany, titleVisibility: .visible) {
            Button("Eliminar", role: .destructive) { deleteSelected() }
        }
        .confirmationDialog("¿Eliminar \(deleteTarget?.name ?? "")?", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Eliminar", role: .destructive) { delete() }
        }
        .alert("AZASing", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(notice ?? "") }
        .onAppear {
            load()
            if let r = openRequest { openDir = r; onOpened() }
        }
        .onChange(of: openRequest) { r in
            if let r { openDir = r; onOpened() }
        }
    }

    // MARK: Interfaz

    @ViewBuilder
    private func rowView(_ item: BrowserItem) -> some View {
        if selecting {
            Button {
                if selection.contains(item.url) { selection.remove(item.url) } else { selection.insert(item.url) }
            } label: { row(item) }
            .buttonStyle(.plain)
        } else if item.isDir {
            Button { openDir = item.url } label: { row(item) }
                .buttonStyle(.plain)
                .contextMenu { menu(item) }
        } else if let tap = defaultAction(item) {
            Button(action: tap) { row(item) }
                .buttonStyle(.plain)
                .contextMenu { menu(item) }
        } else {
            Menu { menu(item) } label: { row(item) }
                .buttonStyle(.plain)
        }
    }

    private func defaultAction(_ item: BrowserItem) -> (() -> Void)? {
        let ext = item.url.pathExtension.lowercased()
        switch item.kind {
        case .deb: return { debTarget = item.url; showDebExtract = true }
        case .plist: return { plistURL = item.url }
        case .image: return { imageURL = item.url }
        case .text: return { textURL = item.url }
        default:
            if ext == "entitlements" { return { plistURL = item.url } }
            return nil
        }
    }

    private var addMenu: some View {
        Menu {
            Button { DocPicker.present { importHere($0) } } label: {
                Label("Importar archivos", systemImage: "square.and.arrow.down")
            }
            Button { DocPicker.presentFolders { importHere($0) } } label: {
                Label("Importar carpeta", systemImage: "folder.badge.gearshape")
            }
            Button { showTweakImport = true } label: {
                Label("Importar desde Tweaks", systemImage: "puzzlepiece.extension")
            }
            Button { folderName = ""; showNewFolder = true } label: {
                Label("Nueva carpeta", systemImage: "folder.badge.plus")
            }
            if !clipboard.urls.isEmpty {
                Button { paste() } label: {
                    Label(clipboard.isMove ? "Mover aquí" : "Pegar aquí", systemImage: "doc.on.clipboard")
                }
            }
            if !clipboard.basket.isEmpty {
                Button { debName = ""; showDebName = true } label: {
                    Label("Crear .deb (\(clipboard.basket.count))", systemImage: "archivebox")
                }
                Button(role: .destructive) { clipboard.basket = [] } label: {
                    Label("Vaciar paquete .deb", systemImage: "xmark.bin")
                }
            }
        } label: { Image(systemName: "plus") }
    }

    private func row(_ item: BrowserItem) -> some View {
        HStack(spacing: 14) {
            if selecting {
                Image(systemName: selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
                    .font(.title3).foregroundColor(selection.contains(item.url) ? .gold : .secondary)
            }
            ThumbView(item: item)
            VStack(alignment: .leading, spacing: 3) {
                Text(item.name).font(.headline).foregroundStyle(.primary).lineLimit(1)
                Text(item.subtitle ?? subtitle(item)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            if item.isDir && !selecting { Image(systemName: "chevron.right").foregroundStyle(.secondary) }
        }
        .padding(12)
        .glassCard(cornerRadius: 18)
    }

    @ViewBuilder
    private func menu(_ item: BrowserItem) -> some View {
        if item.isDir || item.kind == .archive {
            Button { item.isDir ? (openDir = item.url) : extract(item) } label: {
                Label("Mostrar archivos", systemImage: "folder")
            }
        }
        if item.kind == .plist || item.url.pathExtension.lowercased() == "entitlements" {
            Button { plistURL = item.url } label: { Label("Editar plist", systemImage: "curlybraces.square") }
        }
        if item.kind != .image && !item.isDir && item.kind != .archive && item.kind != .p12 && item.kind != .provision && item.kind != .deb {
            Button { textURL = item.url } label: { Label("Editar como texto", systemImage: "pencil.and.list.clipboard") }
        }
        if item.kind == .deb {
            Button { extractDeb(item.url, onlyDylibs: false) } label: { Label("Extraer archivos completos", systemImage: "archivebox") }
            Button { extractDeb(item.url, onlyDylibs: true) } label: { Label("Extraer solo los dylib", systemImage: "puzzlepiece.extension") }
        }
        Button { share(item) } label: { Label("Compartir", systemImage: "square.and.arrow.up") }
        if item.kind == .dylib || item.kind == .framework || item.kind == .bundle || item.kind == .folder {
            Button {
                if !clipboard.basket.contains(item.url) { clipboard.basket.append(item.url) }
                notice = "Añadido al paquete .deb (\(clipboard.basket.count)). Toca + › Crear .deb cuando termines."
            } label: { Label("Añadir a un .deb", systemImage: "archivebox") }
        }
        if ["dylib", "deb", "framework", "bundle"].contains(item.url.pathExtension.lowercased()) {
            Button { sendToTweaks([item.url]) } label: { Label("Enviar a Tweaks", systemImage: "puzzlepiece.extension") }
        }
        if item.isDir {
            Button { pack(item) } label: { Label("Empaquetar IPA", systemImage: "shippingbox") }
        }
        Button { renameTarget = item; newName = item.name; showRename = true } label: {
            Label("Renombrar", systemImage: "pencil")
        }
        Button { clipboard.urls = [item.url]; clipboard.isMove = false; notice = "Copiado. Abre la carpeta destino y toca + › Pegar aquí." } label: {
            Label("Copiar", systemImage: "doc.on.doc")
        }
        Button { clipboard.urls = [item.url]; clipboard.isMove = true; notice = "Listo para mover. Abre la carpeta destino y toca + › Mover aquí." } label: {
            Label("Mover", systemImage: "folder.badge.gearshape")
        }
        Button(role: .destructive) { deleteTarget = item; showDelete = true } label: {
            Label("Eliminar", systemImage: "trash")
        }
    }

    private var selectedItems: [BrowserItem] { shown.filter { selection.contains($0.url) } }

    private var selectionBar: some View {
        HStack(spacing: 6) {
            Button {
                if selection.count == shown.count { selection = [] } else { selection = Set(shown.map(\.url)) }
            } label: { barLabel(selection.count == shown.count && !shown.isEmpty ? "Ninguno" : "Todo", "checklist") }
            Button { shareSelected() } label: { barLabel("Compartir", "square.and.arrow.up") }
            Button(role: .destructive) { showDeleteMany = true } label: { barLabel("Eliminar", "trash") }
            Menu {
                Button { clipboard.urls = Array(selection); clipboard.isMove = false; notice = "Copiado (\(selection.count)). Abre la carpeta destino y toca + › Pegar aquí." } label: { Label("Copiar", systemImage: "doc.on.doc") }
                Button { clipboard.urls = Array(selection); clipboard.isMove = true; notice = "Listo para mover (\(selection.count)). Abre la carpeta destino y toca + › Mover aquí." } label: { Label("Mover", systemImage: "folder.badge.gearshape") }
                Button { sendToTweaks(Array(selection)) } label: { Label("Enviar a Tweaks", systemImage: "puzzlepiece.extension") }
                Button {
                    for u in selection where !clipboard.basket.contains(u) { clipboard.basket.append(u) }
                    notice = "Añadidos al paquete .deb (\(clipboard.basket.count)). Toca + › Crear .deb."
                } label: { Label("Añadir a un .deb", systemImage: "archivebox") }
            } label: { barLabel("Más", "ellipsis.circle") }
        }
        .disabled(shown.isEmpty)
        .padding(.horizontal, 10).padding(.vertical, 8)
        .glassCard(cornerRadius: 26)
        .padding(.horizontal).padding(.bottom, 4)
    }

    private func barLabel(_ text: String, _ symbol: String) -> some View {
        VStack(spacing: 3) {
            Image(systemName: symbol).font(.title3)
            Text(text).font(.caption2)
        }
        .frame(maxWidth: .infinity)
        .foregroundColor(selection.isEmpty && text != "Todo" && text != "Ninguno" ? .secondary : .gold)
    }

    private func shareSelected() {
        let items = selectedItems
        guard !items.isEmpty else { notice = "Selecciona al menos un elemento."; return }
        if items.allSatisfy({ !$0.isDir }) { Share.present(items.map(\.url)); return }
        // Con carpetas: se comparte todo en un .zip
        let urls = items.map(\.url)
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("Selección-\(UUID().uuidString.prefix(6)).zip")
        perform {
            let fm = FileManager.default
            let staging = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try fm.createDirectory(at: staging, withIntermediateDirectories: true)
            defer { try? fm.removeItem(at: staging) }
            for u in urls { try fm.copyItem(at: u, to: staging.appendingPathComponent(u.lastPathComponent)) }
            try fm.zipItem(at: staging, to: tmp, shouldKeepParent: false, compressionMethod: .deflate)
            DispatchQueue.main.async { Share.present(tmp) }
            return ""
        }
    }

    private func deleteSelected() {
        for u in selection {
            try? FileManager.default.removeItem(at: u)
            clipboard.urls.removeAll { $0 == u }
        }
        selection = []
        load()
        if searching { Task { await runSearch() } }
    }

    private func subtitle(_ item: BrowserItem) -> String {
        let date = item.date.formatted(date: .abbreviated, time: .shortened)
        if item.isDir { return "\(item.count) elementos · \(date)" }
        return ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file) + " · " + date
    }

    // MARK: Carga y búsqueda

    nonisolated static func kind(of u: URL, isDir: Bool) -> FKind {
        let ext = u.pathExtension.lowercased()
        if isDir {
            switch ext {
            case "app": return .app
            case "bundle": return .bundle
            case "framework": return .framework
            default: return .folder
            }
        }
        switch ext {
        case "plist", "entitlements": return .plist
        case "mobileprovision": return .provision
        case "png", "jpg", "jpeg", "gif", "heic", "webp", "tiff", "bmp": return .image
        case "dylib": return .dylib
        case "nib", "car", "storyboardc", "momd", "mom", "strings", "ttf", "otf", "caf", "mp3", "m4a", "mp4", "mov", "wav": return .resource
        case "json", "txt", "xml", "js", "html", "css", "md", "yml", "yaml", "conf", "sh", "log", "csv", "swift", "h", "m": return .text
        case "ipa", "tipa", "zip": return .archive
        case "deb": return .deb
        case "p12", "pfx": return .p12
        case "":
            // Ejecutable Mach-O sin extensión
            if let h = try? FileHandle(forReadingFrom: u) {
                defer { try? h.close() }
                let magic = h.readData(ofLength: 4)
                if magic == Data([0xCF, 0xFA, 0xED, 0xFE]) || magic == Data([0xCA, 0xFE, 0xBA, 0xBE]) { return .executable }
            }
            return .other
        default: return .other
        }
    }

    private func load() {
        let fm = FileManager.default
        if isRoot { Folder.allCases.forEach { _ = $0.url } }
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])) ?? []
        items = urls.compactMap { u -> BrowserItem? in
            if isRoot && ["Certificados", "Inbox"].contains(u.lastPathComponent) { return nil }
            let v = try? u.resourceValues(forKeys: Set(keys))
            let isDir = v?.isDirectory ?? false
            let count = isDir ? ((try? fm.contentsOfDirectory(atPath: u.path))?.count ?? 0) : 0
            return BrowserItem(url: u, kind: Self.kind(of: u, isDir: isDir), size: Int64(v?.fileSize ?? 0),
                               date: v?.contentModificationDate ?? .distantPast, count: count)
        }.sorted { ($0.isDir ? 0 : 1, $0.name.lowercased()) < ($1.isDir ? 0 : 1, $1.name.lowercased()) }
    }

    private func runSearch() async {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { results = []; return }
        try? await Task.sleep(nanoseconds: 250_000_000)
        if Task.isCancelled { return }
        let base = dir
        results = await Task.detached { Self.search(base, q) }.value
    }

    nonisolated private static func search(_ base: URL, _ q: String) -> [BrowserItem] {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        guard let en = fm.enumerator(at: base, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        var out: [BrowserItem] = []
        for case let u as URL in en {
            if u.lastPathComponent.range(of: q, options: [.caseInsensitive, .diacriticInsensitive]) != nil {
                let v = try? u.resourceValues(forKeys: Set(keys))
                let isDir = v?.isDirectory ?? false
                var rel = String(u.deletingLastPathComponent().path.dropFirst(base.path.count))
                if rel.isEmpty { rel = "/" }
                out.append(BrowserItem(url: u, kind: kind(of: u, isDir: isDir), size: Int64(v?.fileSize ?? 0),
                                       date: v?.contentModificationDate ?? .distantPast, count: 0, subtitle: rel))
                if out.count >= 300 { break }
            }
        }
        return out
    }

    // MARK: Operaciones

    private func unique(_ name: String, in folder: URL) -> URL {
        let fm = FileManager.default
        var url = folder.appendingPathComponent(name)
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 1
        while fm.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent(ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)")
            n += 1
        }
        return url
    }

    /// Ejecuta trabajo pesado fuera del hilo principal y muestra el resultado.
    private func perform(_ work: @escaping () throws -> String) {
        busy = true
        Task.detached {
            let msg: String
            do { msg = try work() } catch { msg = "Error: \(error.localizedDescription)" }
            await MainActor.run {
                busy = false
                if !msg.isEmpty { notice = msg }
                load()
            }
        }
    }

    private func importHere(_ urls: [URL]) {
        let fm = FileManager.default
        var ok = 0
        var failure: String?
        for src in urls {
            let dest = inWorkspace ? dir.appendingPathComponent(src.lastPathComponent) : unique(src.lastPathComponent, in: dir)
            do {
                if inWorkspace, fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
                if src.path.contains("/tmp/") { try fm.moveItem(at: src, to: dest) }
                else { try fm.copyItem(at: src, to: dest) }
                ok += 1
            } catch { failure = "\(src.lastPathComponent): \(error.localizedDescription)" }
        }
        notice = failure.map { "No se pudo importar. \($0)" } ?? (inWorkspace ? "Reemplazado: \(ok) archivo(s) en el Payload." : "Importado: \(ok) archivo(s).")
        load()
    }

    private func sendToTweaks(_ urls: [URL]) {
        let fm = FileManager.default
        var ok = 0
        for u in urls where ["dylib", "deb", "framework", "bundle"].contains(u.pathExtension.lowercased()) {
            let dest = unique(u.lastPathComponent, in: Folder.tweaks.url)
            if (try? fm.copyItem(at: u, to: dest)) != nil { ok += 1 }
        }
        notice = ok > 0 ? "Enviado a Tweaks: \(ok) elemento(s). Ya puedes elegirlos al firmar." : "Solo se pueden enviar .dylib, .deb, .framework y .bundle."
    }

    private func createFolder() {
        let n = folderName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty else { return }
        do { try FileManager.default.createDirectory(at: unique(n, in: dir), withIntermediateDirectories: false) }
        catch { notice = "Error: \(error.localizedDescription)" }
        load()
    }

    private func extractDeb(_ deb: URL, onlyDylibs: Bool) {
        let stem = deb.deletingPathExtension().lastPathComponent
        let dest = unique(onlyDylibs ? "\(stem) (dylib)" : stem, in: deb.deletingLastPathComponent())
        perform {
            let fm = FileManager.default
            if onlyDylibs {
                let tmp = fm.temporaryDirectory.appendingPathComponent("debx-\(UUID().uuidString)")
                defer { try? fm.removeItem(at: tmp) }
                try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                try DebKit.extractDeb(deb, to: tmp)
                let libs = DebKit.collect(in: tmp).dylibs
                guard !libs.isEmpty else { return "Este .deb no contiene ningún .dylib." }
                try fm.createDirectory(at: dest, withIntermediateDirectories: true)
                for l in libs {
                    var target = dest.appendingPathComponent(l.lastPathComponent)
                    var n = 2
                    while fm.fileExists(atPath: target.path) {
                        target = dest.appendingPathComponent("\(l.deletingPathExtension().lastPathComponent) \(n).dylib"); n += 1
                    }
                    try fm.copyItem(at: l, to: target)
                }
                return "Extraídos \(libs.count) dylib en “\(dest.lastPathComponent)”."
            } else {
                try fm.createDirectory(at: dest, withIntermediateDirectories: true)
                try DebKit.extractDeb(deb, to: dest)
                return "Extraído en “\(dest.lastPathComponent)”."
            }
        }
    }

    private func createDeb() {
        let n = debName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty else { return }
        let items = clipboard.basket
        let out = unique(n + ".deb", in: Folder.tweaks.url)
        clipboard.basket = []
        perform {
            try DebKit.createDeb(name: n, items: items, output: out)
            return "Paquete creado en Tweaks: \(out.lastPathComponent). Ya puedes elegirlo al firmar."
        }
    }

    private func rename() {
        guard let t = renameTarget else { return }
        let n = newName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty, n != t.name else { return }
        let dest = t.url.deletingLastPathComponent().appendingPathComponent(n)
        if FileManager.default.fileExists(atPath: dest.path) { notice = "Ya existe “\(n)”."; return }
        do { try FileManager.default.moveItem(at: t.url, to: dest) }
        catch { notice = "Error: \(error.localizedDescription)" }
        load()
        if searching { Task { await runSearch() } }
    }

    private func delete() {
        guard let t = deleteTarget else { return }
        do { try FileManager.default.removeItem(at: t.url) }
        catch { notice = "Error: \(error.localizedDescription)" }
        clipboard.urls.removeAll { $0 == t.url }
        load()
        if searching { Task { await runSearch() } }
    }

    private func paste() {
        let fm = FileManager.default
        var done = 0
        for source in clipboard.urls {
            if dir.path.hasPrefix(source.path) { notice = "No puedes pegar una carpeta dentro de sí misma."; continue }
            let dest = inWorkspace ? dir.appendingPathComponent(source.lastPathComponent) : unique(source.lastPathComponent, in: dir)
            do {
                if inWorkspace, fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
                if clipboard.isMove { try fm.moveItem(at: source, to: dest) } else { try fm.copyItem(at: source, to: dest) }
                done += 1
            } catch { notice = "Error: \(error.localizedDescription)" }
        }
        if clipboard.isMove { clipboard.urls = [] }
        if done > 0 && notice == nil { notice = "Listo: \(done) elemento(s)." }
        load()
    }

    private func share(_ item: BrowserItem) {
        if !item.isDir { Share.present(item.url); return }
        // Las carpetas se comparten comprimidas en .zip
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(item.name + ".zip")
        let src = item.url
        perform {
            let fm = FileManager.default
            try? fm.removeItem(at: tmp)
            try fm.zipItem(at: src, to: tmp, shouldKeepParent: true, compressionMethod: .deflate)
            DispatchQueue.main.async { Share.present(tmp) }
            return ""
        }
    }

    private func extract(_ item: BrowserItem) {
        let dest = unique(item.url.deletingPathExtension().lastPathComponent, in: item.url.deletingLastPathComponent())
        let src = item.url
        perform {
            let fm = FileManager.default
            try fm.createDirectory(at: dest, withIntermediateDirectories: true)
            try fm.unzipItem(at: src, to: dest)
            return "Extraído en “\(dest.lastPathComponent)”."
        }
    }

    /// Crea un .ipa (Payload/X.app) a partir de una carpeta .app o que contenga una.
    private func pack(_ item: BrowserItem) {
        let fm = FileManager.default
        guard let app = Self.findApp(in: item.url) else { notice = "No encontré ninguna carpeta .app aquí."; return }
        let out = unique(app.deletingPathExtension().lastPathComponent + ".ipa", in: Folder.ipas.url)
        perform {
            let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let payload = tmp.appendingPathComponent("Payload")
            try fm.createDirectory(at: payload, withIntermediateDirectories: true)
            defer { try? fm.removeItem(at: tmp) }
            try fm.copyItem(at: app, to: payload.appendingPathComponent(app.lastPathComponent))
            try fm.zipItem(at: payload, to: out, shouldKeepParent: true, compressionMethod: .deflate)
            return "IPA creado en Proyectos: \(out.lastPathComponent)"
        }
    }

    private static func findApp(in url: URL) -> URL? {
        let fm = FileManager.default
        if url.pathExtension == "app" { return url }
        let payload = url.appendingPathComponent("Payload")
        for base in [payload, url] {
            if let kids = try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: nil),
               let app = kids.first(where: { $0.pathExtension == "app" }) { return app }
        }
        return nil
    }
}

// URL como elemento de sheet(item:)
extension URL: Identifiable { public var id: String { absoluteString } }
