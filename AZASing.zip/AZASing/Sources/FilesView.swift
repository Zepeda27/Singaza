import SwiftUI
import ZIPFoundation

@MainActor
final class Clipboard: ObservableObject {
    @Published var url: URL?
    @Published var isMove = false
}

struct BrowserItem: Identifiable, Hashable {
    let url: URL
    let isDir: Bool
    let size: Int64
    let date: Date
    let count: Int
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

struct SimpleError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

struct FilesView: View {
    @StateObject private var clipboard = Clipboard()
    var body: some View {
        NavigationStack {
            BrowserView(dir: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0],
                        isRoot: true, clipboard: clipboard)
        }
    }
}

struct BrowserView: View {
    let dir: URL
    var isRoot = false
    @ObservedObject var clipboard: Clipboard

    @State private var items: [BrowserItem] = []
    @State private var openDir: URL?
    @State private var notice: String?
    @State private var busy = false

    @State private var renameTarget: BrowserItem?
    @State private var showRename = false
    @State private var newName = ""
    @State private var deleteTarget: BrowserItem?
    @State private var showDelete = false
    @State private var showNewFolder = false
    @State private var folderName = ""

    var body: some View {
        ScrollView {
            if items.isEmpty {
                Text("Carpeta vacía").foregroundStyle(.secondary).padding(.top, 80)
            }
            LazyVStack(spacing: 10) {
                ForEach(items) { item in
                    if item.isDir {
                        Button { openDir = item.url } label: { row(item) }
                            .buttonStyle(.plain)
                            .contextMenu { menu(item) }
                    } else {
                        Menu { menu(item) } label: { row(item) }
                            .buttonStyle(.plain)
                    }
                }
            }
            .padding()
            if busy { ProgressView().padding() }
        }
        .background(AppBackground())
        .navigationTitle(isRoot ? "Archivos" : dir.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { addMenu } }
        .background(
            NavigationLink(isActive: Binding(get: { openDir != nil }, set: { if !$0 { openDir = nil } })) {
                if let d = openDir { BrowserView(dir: d, clipboard: clipboard) }
            } label: { EmptyView() }
            .hidden()
        )
        .alert("Renombrar", isPresented: $showRename) {
            TextField("Nombre", text: $newName)
            Button("Guardar") { rename() }
            Button("Cancelar", role: .cancel) {}
        }
        .alert("Nueva carpeta", isPresented: $showNewFolder) {
            TextField("Nombre", text: $folderName)
            Button("Crear") { createFolder() }
            Button("Cancelar", role: .cancel) {}
        }
        .confirmationDialog("¿Eliminar \(deleteTarget?.name ?? "")?", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Eliminar", role: .destructive) { delete() }
        }
        .alert("AZASing", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(notice ?? "") }
        .onAppear { load() }
    }

    // MARK: Interfaz

    private var addMenu: some View {
        Menu {
            Button { DocPicker.present { importHere($0) } } label: {
                Label("Importar archivos", systemImage: "square.and.arrow.down")
            }
            Button { folderName = ""; showNewFolder = true } label: {
                Label("Nueva carpeta", systemImage: "folder.badge.plus")
            }
            if let c = clipboard.url {
                Button { paste(c) } label: {
                    Label(clipboard.isMove ? "Mover aquí" : "Pegar aquí", systemImage: "doc.on.clipboard")
                }
            }
        } label: { Image(systemName: "plus") }
    }

    private func row(_ item: BrowserItem) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon(item)).font(.title2).foregroundColor(.gold).frame(width: 44, height: 44)
            VStack(alignment: .leading, spacing: 3) {
                Text(item.name).font(.headline).foregroundStyle(.primary).lineLimit(1)
                Text(subtitle(item)).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            if item.isDir { Image(systemName: "chevron.right").foregroundStyle(.secondary) }
        }
        .padding(12)
        .glassCard(cornerRadius: 18)
    }

    @ViewBuilder
    private func menu(_ item: BrowserItem) -> some View {
        if item.isDir || isArchive(item) {
            Button { item.isDir ? (openDir = item.url) : extract(item) } label: {
                Label("Mostrar archivos", systemImage: "folder")
            }
        }
        Button { share(item) } label: { Label("Compartir", systemImage: "square.and.arrow.up") }
        if item.isDir {
            Button { pack(item) } label: { Label("Empaquetar IPA", systemImage: "shippingbox") }
        }
        Button { renameTarget = item; newName = item.name; showRename = true } label: {
            Label("Renombrar", systemImage: "pencil")
        }
        Button { clipboard.url = item.url; clipboard.isMove = false; notice = "Copiado. Abre la carpeta destino y toca + › Pegar aquí." } label: {
            Label("Copiar", systemImage: "doc.on.doc")
        }
        Button { clipboard.url = item.url; clipboard.isMove = true; notice = "Listo para mover. Abre la carpeta destino y toca + › Mover aquí." } label: {
            Label("Mover", systemImage: "folder.badge.gearshape")
        }
        Button(role: .destructive) { deleteTarget = item; showDelete = true } label: {
            Label("Eliminar", systemImage: "trash")
        }
    }

    private func isArchive(_ item: BrowserItem) -> Bool {
        ["ipa", "tipa", "zip"].contains(item.url.pathExtension.lowercased())
    }

    private func icon(_ item: BrowserItem) -> String {
        if item.isDir { return item.url.pathExtension == "app" ? "app.badge" : "folder.fill" }
        switch item.url.pathExtension.lowercased() {
        case "ipa", "tipa": return "app.gift"
        case "dylib": return "puzzlepiece.extension"
        case "p12", "pfx": return "key"
        case "mobileprovision": return "doc.badge.gearshape"
        case "zip": return "doc.zipper"
        default: return "doc"
        }
    }

    private func subtitle(_ item: BrowserItem) -> String {
        let date = item.date.formatted(date: .abbreviated, time: .shortened)
        if item.isDir { return "\(item.count) elementos · \(date)" }
        return ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file) + " · " + date
    }

    // MARK: Operaciones

    private func load() {
        let fm = FileManager.default
        if isRoot { Folder.allCases.forEach { _ = $0.url } }
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])) ?? []
        items = urls.compactMap { u -> BrowserItem? in
            if isRoot && ["Certificados", "Inbox"].contains(u.lastPathComponent) { return nil }
            let v = try? u.resourceValues(forKeys: Set(keys))
            let isDir = v?.isDirectory ?? false
            let count = isDir ? ((try? fm.contentsOfDirectory(atPath: u.path))?.count ?? 0) : 0
            return BrowserItem(url: u, isDir: isDir, size: Int64(v?.fileSize ?? 0),
                               date: v?.contentModificationDate ?? .distantPast, count: count)
        }.sorted { ($0.isDir ? 0 : 1, $0.name.lowercased()) < ($1.isDir ? 0 : 1, $1.name.lowercased()) }
    }

    private func unique(_ name: String, in folder: URL) -> URL {
        let fm = FileManager.default
        var url = folder.appendingPathComponent(name)
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 1
        while fm.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent(ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)")
            n += 1
        }
        return url
    }

    /// Ejecuta trabajo pesado fuera del hilo principal y muestra el resultado.
    private func perform(_ work: @escaping () throws -> String) {
        busy = true
        Task.detached {
            let msg: String
            do { msg = try work() } catch { msg = "Error: \(error.localizedDescription)" }
            await MainActor.run {
                busy = false
                if !msg.isEmpty { notice = msg }
                load()
            }
        }
    }

    private func importHere(_ urls: [URL]) {
        let fm = FileManager.default
        var ok = 0
        var failure: String?
        for src in urls {
            let dest = unique(src.lastPathComponent, in: dir)
            do {
                if src.path.contains("/tmp/") { try fm.moveItem(at: src, to: dest) }
                else { try fm.copyItem(at: src, to: dest) }
                ok += 1
            } catch { failure = "\(src.lastPathComponent): \(error.localizedDescription)" }
        }
        notice = failure.map { "No se pudo importar. \($0)" } ?? "Importado: \(ok) archivo(s)."
        load()
    }

    private func createFolder() {
        let n = folderName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty else { return }
        do { try FileManager.default.createDirectory(at: unique(n, in: dir), withIntermediateDirectories: false) }
        catch { notice = "Error: \(error.localizedDescription)" }
        load()
    }

    private func rename() {
        guard let t = renameTarget else { return }
        let n = newName.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty, n != t.name else { return }
        let dest = dir.appendingPathComponent(n)
        if FileManager.default.fileExists(atPath: dest.path) { notice = "Ya existe “\(n)”."; return }
        do { try FileManager.default.moveItem(at: t.url, to: dest) }
        catch { notice = "Error: \(error.localizedDescription)" }
        load()
    }

    private func delete() {
        guard let t = deleteTarget else { return }
        do { try FileManager.default.removeItem(at: t.url) }
        catch { notice = "Error: \(error.localizedDescription)" }
        if clipboard.url == t.url { clipboard.url = nil }
        load()
    }

    private func paste(_ source: URL) {
        let fm = FileManager.default
        if dir.path.hasPrefix(source.path) { notice = "No puedes pegar una carpeta dentro de sí misma."; return }
        let dest = unique(source.lastPathComponent, in: dir)
        do {
            if clipboard.isMove { try fm.moveItem(at: source, to: dest); clipboard.url = nil }
            else { try fm.copyItem(at: source, to: dest) }
        } catch { notice = "Error: \(error.localizedDescription)" }
        load()
    }

    private func share(_ item: BrowserItem) {
        if !item.isDir { Share.present(item.url); return }
        // Las carpetas se comparten comprimidas en .zip
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(item.name + ".zip")
        let src = item.url
        perform {
            let fm = FileManager.default
            try? fm.removeItem(at: tmp)
            try fm.zipItem(at: src, to: tmp, shouldKeepParent: true, compressionMethod: .deflate)
            DispatchQueue.main.async { Share.present(tmp) }
            return ""
        }
    }

    private func extract(_ item: BrowserItem) {
        let dest = unique(item.url.deletingPathExtension().lastPathComponent, in: dir)
        let src = item.url
        perform {
            let fm = FileManager.default
            try fm.createDirectory(at: dest, withIntermediateDirectories: true)
            try fm.unzipItem(at: src, to: dest)
            return "Extraído en “\(dest.lastPathComponent)”."
        }
    }

    /// Crea un .ipa (Payload/X.app) a partir de una carpeta .app o que contenga una.
    private func pack(_ item: BrowserItem) {
        let fm = FileManager.default
        guard let app = Self.findApp(in: item.url) else { notice = "No encontré ninguna carpeta .app aquí."; return }
        let out = unique(app.deletingPathExtension().lastPathComponent + ".ipa", in: dir)
        perform {
            let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            let payload = tmp.appendingPathComponent("Payload")
            try fm.createDirectory(at: payload, withIntermediateDirectories: true)
            defer { try? fm.removeItem(at: tmp) }
            try fm.copyItem(at: app, to: payload.appendingPathComponent(app.lastPathComponent))
            try fm.zipItem(at: payload, to: out, shouldKeepParent: true, compressionMethod: .deflate)
            return "IPA creado: \(out.lastPathComponent)"
        }
    }

    private static func findApp(in url: URL) -> URL? {
        let fm = FileManager.default
        if url.pathExtension == "app" { return url }
        let payload = url.appendingPathComponent("Payload")
        for base in [payload, url] {
            if let kids = try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: nil),
               let app = kids.first(where: { $0.pathExtension == "app" }) { return app }
        }
        return nil
    }
}
