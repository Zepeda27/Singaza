import SwiftUI

// MARK: - Modelo

struct RepoSource: Codable, Identifiable, Hashable {
    var id = UUID()
    var url: String
    var name: String
    var icon: String?
}

struct RepoApp: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var bundleID: String
    var version: String
    var size: Int64?
    var icon: URL?
    var download: URL
    var detail: String
}

enum RepoParser {
    /// Acepta repositorios estilo AltStore (v1 y v2) y variantes comunes.
    static func parse(_ data: Data) -> (name: String?, icon: String?, apps: [RepoApp])? {
        guard let root = try? JSONSerialization.jsonObject(with: data) else { return nil }
        var list: [[String: Any]] = []
        var name: String?, icon: String?
        if let d = root as? [String: Any] {
            name = d["name"] as? String
            icon = (d["iconURL"] ?? d["icon"] ?? d["image"]) as? String
            list = (d["apps"] as? [[String: Any]]) ?? (d["data"] as? [[String: Any]]) ?? (d["list"] as? [[String: Any]]) ?? []
        } else if let a = root as? [[String: Any]] { list = a }
        else { return nil }

        func str(_ d: [String: Any], _ keys: [String]) -> String? {
            for k in keys { if let v = d[k] as? String, !v.isEmpty { return v } }
            return nil
        }
        let apps: [RepoApp] = list.compactMap { a in
            let v0 = (a["versions"] as? [[String: Any]])?.first
            guard let dl = str(a, ["downloadURL", "down", "url", "ipa"]) ?? v0.flatMap({ str($0, ["downloadURL", "url"]) }),
                  let dlURL = URL(string: dl.trimmingCharacters(in: .whitespaces)) else { return nil }
            let n = str(a, ["name", "title"]) ?? dlURL.deletingPathExtension().lastPathComponent
            let sizeAny = a["size"] ?? v0?["size"]
            let size = (sizeAny as? NSNumber)?.int64Value ?? Int64((sizeAny as? String) ?? "")
            return RepoApp(name: n,
                           bundleID: str(a, ["bundleIdentifier", "bundleID", "bundle"]) ?? "",
                           version: str(a, ["version"]) ?? v0.flatMap { str($0, ["version"]) } ?? "",
                           size: size,
                           icon: str(a, ["iconURL", "icon", "image"]).flatMap(URL.init(string:)),
                           download: dlURL,
                           detail: str(a, ["subtitle", "versionDescription", "localizedDescription"]) ?? v0.flatMap { str($0, ["localizedDescription"]) } ?? "")
        }
        return (name, icon, apps)
    }

    static func fetch(_ url: URL) async throws -> Data {
        var req = URLRequest(url: url); req.timeoutInterval = 25
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) {
            throw URLError(.badServerResponse)
        }
        return data
    }
}

enum Downloader {
    /// Descarga un IPA y lo deja en el almacén de Proyectos.
    @MainActor
    static func download(_ url: URL, name: String, version: String, into ipas: FileStore) async throws {
        var req = URLRequest(url: url); req.timeoutInterval = 600
        let (tmp, resp) = try await URLSession.shared.download(for: req)
        if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) { throw URLError(.badServerResponse) }
        let safe = name.replacingOccurrences(of: "/", with: "-")
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(version.isEmpty ? "\(safe).ipa" : "\(safe)_\(version).ipa")
        try? FileManager.default.removeItem(at: file)
        try FileManager.default.moveItem(at: tmp, to: file)
        ipas.importFiles([file])
    }
}

// MARK: - Fuentes

struct SourcesView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var incoming: Incoming
    @AppStorage("sources") private var stored = ""
    @State private var sources: [RepoSource] = []
    @State private var link = ""
    @State private var ipaLink = ""
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        Image(systemName: "plus").font(.title3).foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Añadir fuente").font(.headline)
                            TextField("Introduce o pega el enlace de la fuente", text: $link)
                                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                                .onSubmit { addSource() }
                        }
                        if !link.isEmpty {
                            Button { addSource() } label: { Image(systemName: "arrow.right.circle.fill").font(.title2).foregroundColor(.gold) }
                                .buttonStyle(.plain)
                        }
                    }
                    HStack {
                        Image(systemName: "arrow.down.circle").font(.title3).foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Descargar IPA desde un enlace").font(.headline)
                            TextField("https://…/app.ipa", text: $ipaLink)
                                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                                .onSubmit { downloadLink() }
                        }
                        if !ipaLink.isEmpty {
                            Button { downloadLink() } label: { Image(systemName: "arrow.down.circle.fill").font(.title2).foregroundColor(.gold) }
                                .buttonStyle(.plain)
                        }
                    }
                    if busy { HStack { ProgressView(); Text("Trabajando…").foregroundStyle(.secondary) } }
                }

                Section("Todas las fuentes") {
                    if sources.isEmpty {
                        Text("Aún no hay fuentes. Pega el enlace de un repositorio (formato AltStore / ESign).")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(sources) { src in
                        NavigationLink { SourceDetailView(source: src, ipas: ipas, incoming: incoming) } label: {
                            HStack(spacing: 12) {
                                AsyncImage(url: src.icon.flatMap(URL.init(string:))) { img in img.resizable().scaledToFill() }
                                    placeholder: { Image(systemName: "square.stack.3d.up.fill").foregroundColor(.gold) }
                                    .frame(width: 44, height: 44).background(Color.gold.opacity(0.12)).clipShape(Circle())
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(src.name).font(.headline)
                                    Text(src.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                        }
                        .contextMenu {
                            Button { UIPasteboard.general.string = src.url } label: { Label("Copiar enlace", systemImage: "doc.on.doc") }
                            Button(role: .destructive) { remove(src) } label: { Label("Eliminar", systemImage: "trash") }
                        }
                    }
                    .onDelete { idx in sources.remove(atOffsets: idx); save() }
                }
            }
            .scrollContentBackground(.hidden)
            .keyboardDone()
            .background(AppBackground())
            .navigationTitle("Fuentes")
            .onAppear { load() }
            .alert("Fuentes", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func load() {
        if let d = stored.data(using: .utf8), let arr = try? JSONDecoder().decode([RepoSource].self, from: d) { sources = arr }
    }
    private func save() {
        if let d = try? JSONEncoder().encode(sources) { stored = String(decoding: d, as: UTF8.self) }
    }
    private func remove(_ s: RepoSource) { sources.removeAll { $0 == s }; save() }

    private func addSource() {
        let t = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        let full = t.hasPrefix("http") ? t : "https://" + t
        guard let url = URL(string: full) else { message = "El enlace no es válido."; return }
        if sources.contains(where: { $0.url == full }) { message = "Esa fuente ya está añadida."; return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let data = try await RepoParser.fetch(url)
                guard let parsed = RepoParser.parse(data) else { message = "No reconozco ese formato de fuente."; return }
                sources.append(RepoSource(url: full, name: parsed.name ?? (url.host ?? "Fuente"), icon: parsed.icon))
                save(); link = ""
            } catch { message = "No se pudo leer la fuente: \(error.localizedDescription)" }
        }
    }

    private func downloadLink() {
        let t = ipaLink.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: t), t.hasPrefix("http") else { message = "El enlace no es válido."; return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let n = url.deletingPathExtension().lastPathComponent
                try await Downloader.download(url, name: n.isEmpty ? "App" : n, version: "", into: ipas)
                ipaLink = ""
                incoming.selectedTab = 0
            } catch { message = "No se pudo descargar: \(error.localizedDescription)" }
        }
    }
}

// MARK: - Apps de una fuente

struct SourceDetailView: View {
    let source: RepoSource
    @ObservedObject var ipas: FileStore
    @ObservedObject var incoming: Incoming
    @State private var apps: [RepoApp] = []
    @State private var loading = true
    @State private var query = ""
    @State private var downloading: Set<UUID> = []
    @State private var message: String?
    @State private var done: String?

    private var shown: [RepoApp] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        return q.isEmpty ? apps : apps.filter { $0.name.lowercased().contains(q) || $0.bundleID.lowercased().contains(q) }
    }

    var body: some View {
        List {
            if loading { HStack { ProgressView(); Text("Cargando…").foregroundStyle(.secondary) } }
            if !loading && apps.isEmpty { Text("Esta fuente no tiene apps.").foregroundStyle(.secondary) }
            ForEach(shown) { app in
                HStack(spacing: 12) {
                    AsyncImage(url: app.icon) { img in img.resizable().scaledToFill() }
                        placeholder: { Image(systemName: "app.fill").foregroundColor(.gold) }
                        .frame(width: 52, height: 52).background(Color.gold.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(app.name).font(.headline)
                        Text([app.version, app.size.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) }]
                                .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.caption).foregroundStyle(.secondary)
                        if !app.detail.isEmpty { Text(app.detail).font(.caption2).foregroundStyle(.secondary).lineLimit(2) }
                    }
                    Spacer()
                    if downloading.contains(app.id) { ProgressView() }
                    else {
                        Button("Obtener") { get(app) }
                            .buttonStyle(.borderedProminent).tint(.gold).foregroundColor(.black)
                            .font(.footnote.weight(.bold))
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .keyboardDone()
        .background(AppBackground())
        .navigationTitle(source.name)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Buscar app")
        .task { await load() }
        .alert("Fuente", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(message ?? "") }
        .alert("Descargada", isPresented: Binding(get: { done != nil }, set: { if !$0 { done = nil } })) {
            Button("Abrir Proyectos") { incoming.selectedTab = 0 }
            Button("Seguir aquí", role: .cancel) {}
        } message: { Text(done ?? "") }
    }

    private func load() async {
        loading = true
        defer { loading = false }
        guard let url = URL(string: source.url) else { return }
        do {
            let data = try await RepoParser.fetch(url)
            apps = RepoParser.parse(data)?.apps ?? []
        } catch { message = "No se pudo cargar la fuente: \(error.localizedDescription)" }
    }

    private func get(_ app: RepoApp) {
        downloading.insert(app.id)
        Task {
            defer { downloading.remove(app.id) }
            do {
                try await Downloader.download(app.download, name: app.name, version: app.version, into: ipas)
                done = "\(app.name) ya está en Proyectos, lista para firmar."
            } catch { message = "No se pudo descargar \(app.name): \(error.localizedDescription)" }
        }
    }
}
