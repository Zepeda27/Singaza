import SwiftUI

// MARK: - Modelo

struct RepoSource: Codable, Identifiable, Hashable {
    var id = UUID()
    var url: String
    var name: String
    var icon: String?
}

struct RepoApp: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var bundleID: String
    var version: String
    var size: Int64?
    var icon: URL?
    var download: URL
    var detail: String
    var developer: String = ""
    var date: Date?
    var dateRaw: String = ""
    var minOS: String = ""
    var about: String = ""
    var whatsNew: String = ""
    var screenshots: [URL] = []
    var history: [RepoVersion] = []
}

struct RepoVersion: Identifiable, Hashable {
    let id = UUID()
    var version: String
    var date: Date?
    var dateRaw: String
    var size: Int64?
    var notes: String
    var download: URL?
}

enum RepoParser {
    /// Acepta repositorios estilo AltStore (v1 y v2) y variantes comunes.
    static func parse(_ data: Data) -> (name: String?, icon: String?, apps: [RepoApp])? {
        guard let root = try? JSONSerialization.jsonObject(with: data) else { return nil }
        var list: [[String: Any]] = []
        var name: String?, icon: String?
        if let d = root as? [String: Any] {
            name = d["name"] as? String
            icon = (d["iconURL"] ?? d["icon"] ?? d["image"]) as? String
            list = (d["apps"] as? [[String: Any]]) ?? (d["data"] as? [[String: Any]]) ?? (d["list"] as? [[String: Any]]) ?? []
        } else if let a = root as? [[String: Any]] { list = a }
        else { return nil }

        func str(_ d: [String: Any], _ keys: [String]) -> String? {
            for k in keys { if let v = d[k] as? String, !v.isEmpty { return v } }
            return nil
        }
        func parseDate(_ raw: String?) -> Date? {
            guard let raw, !raw.isEmpty else { return nil }
            let iso = ISO8601DateFormatter()
            iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let d = iso.date(from: raw) { return d }
            iso.formatOptions = [.withInternetDateTime]
            if let d = iso.date(from: raw) { return d }
            for f in ["yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd", "dd/MM/yyyy", "MM/dd/yyyy"] {
                let df = DateFormatter(); df.locale = Locale(identifier: "en_US_POSIX"); df.dateFormat = f
                if let d = df.date(from: raw) { return d }
            }
            return nil
        }
        func urls(_ any: Any?) -> [URL] {
            if let arr = any as? [String] { return arr.compactMap(URL.init(string:)) }
            if let arr = any as? [[String: Any]] {
                return arr.compactMap { ($0["imageURL"] ?? $0["url"]) as? String }.compactMap(URL.init(string:))
            }
            if let d = any as? [String: Any] { return d.values.flatMap { urls($0) } }
            return []
        }
        let apps: [RepoApp] = list.compactMap { a in
            let v0 = (a["versions"] as? [[String: Any]])?.first
            guard let dl = str(a, ["downloadURL", "down", "url", "ipa"]) ?? v0.flatMap({ str($0, ["downloadURL", "url"]) }),
                  let dlURL = URL(string: dl.trimmingCharacters(in: .whitespaces)) else { return nil }
            let n = str(a, ["name", "title"]) ?? dlURL.deletingPathExtension().lastPathComponent
            let sizeAny = a["size"] ?? v0?["size"]
            let size = (sizeAny as? NSNumber)?.int64Value ?? Int64((sizeAny as? String) ?? "")
            let dateRaw = str(a, ["versionDate", "date", "time", "updated"]) ?? v0.flatMap { str($0, ["date", "versionDate"]) } ?? ""
            let notes = v0.flatMap { str($0, ["localizedDescription", "versionDescription"]) } ?? str(a, ["versionDescription"]) ?? ""
            let about = str(a, ["localizedDescription", "description", "desc"]) ?? ""
            let shots = urls(a["screenshotURLs"] ?? a["screenshots"])
            let history: [RepoVersion] = ((a["versions"] as? [[String: Any]]) ?? []).map { v in
                let raw = str(v, ["date", "versionDate"]) ?? ""
                let sz = v["size"]
                return RepoVersion(version: str(v, ["version"]) ?? "", date: parseDate(raw), dateRaw: raw,
                                   size: (sz as? NSNumber)?.int64Value ?? Int64((sz as? String) ?? ""),
                                   notes: str(v, ["localizedDescription", "versionDescription"]) ?? "",
                                   download: str(v, ["downloadURL", "url"]).flatMap(URL.init(string:)))
            }
            return RepoApp(name: n,
                           bundleID: str(a, ["bundleIdentifier", "bundleID", "bundle"]) ?? "",
                           version: str(a, ["version"]) ?? v0.flatMap { str($0, ["version"]) } ?? "",
                           size: size,
                           icon: str(a, ["iconURL", "icon", "image"]).flatMap(URL.init(string:)),
                           download: dlURL,
                           detail: str(a, ["subtitle"]) ?? (notes.isEmpty ? about : notes),
                           developer: str(a, ["developerName", "developer", "author"]) ?? "",
                           date: parseDate(dateRaw), dateRaw: dateRaw,
                           minOS: str(a, ["minOSVersion", "minOS"]) ?? v0.flatMap { str($0, ["minOSVersion"]) } ?? "",
                           about: about, whatsNew: notes, screenshots: shots, history: history)
        }
        return (name, icon, apps)
    }

    static func fetch(_ url: URL) async throws -> Data {
        var req = URLRequest(url: url); req.timeoutInterval = 25
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) {
            throw URLError(.badServerResponse)
        }
        return data
    }
}

enum Downloader {
    /// Descarga un IPA y lo deja en el almacén de Proyectos.
    @MainActor
    static func download(_ url: URL, name: String, version: String, into ipas: FileStore) async throws {
        var req = URLRequest(url: url); req.timeoutInterval = 600
        let (tmp, resp) = try await URLSession.shared.download(for: req)
        if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) { throw URLError(.badServerResponse) }
        let safe = name.replacingOccurrences(of: "/", with: "-")
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(version.isEmpty ? "\(safe).ipa" : "\(safe)_\(version).ipa")
        try? FileManager.default.removeItem(at: file)
        try FileManager.default.moveItem(at: tmp, to: file)
        ipas.importFiles([file])
    }
}

// MARK: - Fuentes

struct SourcesView: View {
    @ObservedObject var ipas: FileStore
    @ObservedObject var incoming: Incoming
    @AppStorage("sources") private var stored = ""
    @State private var sources: [RepoSource] = []
    @State private var link = ""
    @State private var ipaLink = ""
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        Image(systemName: "plus").font(.title3).foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Añadir fuente").font(.headline)
                            TextField("Introduce o pega el enlace de la fuente", text: $link)
                                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                                .onSubmit { addSource() }
                        }
                        if !link.isEmpty {
                            Button { addSource() } label: { Image(systemName: "arrow.right.circle.fill").font(.title2).foregroundColor(.gold) }
                                .buttonStyle(.plain)
                        }
                    }
                    HStack {
                        Image(systemName: "arrow.down.circle").font(.title3).foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Descargar IPA desde un enlace").font(.headline)
                            TextField("https://…/app.ipa", text: $ipaLink)
                                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                                .onSubmit { downloadLink() }
                        }
                        if !ipaLink.isEmpty {
                            Button { downloadLink() } label: { Image(systemName: "arrow.down.circle.fill").font(.title2).foregroundColor(.gold) }
                                .buttonStyle(.plain)
                        }
                    }
                    if busy { HStack { ProgressView(); Text("Trabajando…").foregroundStyle(.secondary) } }
                }

                Section("Todas las fuentes") {
                    if sources.isEmpty {
                        Text("Aún no hay fuentes. Pega el enlace de un repositorio (formato AltStore / ESign).")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(sources) { src in
                        NavigationLink { SourceDetailView(source: src, ipas: ipas, incoming: incoming) } label: {
                            HStack(spacing: 12) {
                                AsyncImage(url: src.icon.flatMap(URL.init(string:))) { img in img.resizable().scaledToFill() }
                                    placeholder: { Image(systemName: "square.stack.3d.up.fill").foregroundColor(.gold) }
                                    .frame(width: 44, height: 44).background(Color.gold.opacity(0.12)).clipShape(Circle())
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(src.name).font(.headline)
                                    Text(src.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                        }
                        .contextMenu {
                            Button { UIPasteboard.general.string = src.url } label: { Label("Copiar enlace", systemImage: "doc.on.doc") }
                            Button(role: .destructive) { remove(src) } label: { Label("Eliminar", systemImage: "trash") }
                        }
                    }
                    .onDelete { idx in sources.remove(atOffsets: idx); save() }
                }
            }
            .scrollContentBackground(.hidden)
            .keyboardDone()
            .background(AppBackground())
            .navigationTitle("Fuentes")
            .onAppear { load() }
            .alert("Fuentes", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(message ?? "") }
        }
    }

    private func load() {
        if let d = stored.data(using: .utf8), let arr = try? JSONDecoder().decode([RepoSource].self, from: d) { sources = arr }
    }
    private func save() {
        if let d = try? JSONEncoder().encode(sources) { stored = String(decoding: d, as: UTF8.self) }
    }
    private func remove(_ s: RepoSource) { sources.removeAll { $0 == s }; save() }

    private func addSource() {
        let t = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        let full = t.hasPrefix("http") ? t : "https://" + t
        guard let url = URL(string: full) else { message = "El enlace no es válido."; return }
        if sources.contains(where: { $0.url == full }) { message = "Esa fuente ya está añadida."; return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let data = try await RepoParser.fetch(url)
                guard let parsed = RepoParser.parse(data) else { message = "No reconozco ese formato de fuente."; return }
                sources.append(RepoSource(url: full, name: parsed.name ?? (url.host ?? "Fuente"), icon: parsed.icon))
                save(); link = ""
            } catch { message = "No se pudo leer la fuente: \(error.localizedDescription)" }
        }
    }

    private func downloadLink() {
        let t = ipaLink.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: t), t.hasPrefix("http") else { message = "El enlace no es válido."; return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let n = url.deletingPathExtension().lastPathComponent
                try await Downloader.download(url, name: n.isEmpty ? "App" : n, version: "", into: ipas)
                ipaLink = ""
                incoming.selectedTab = 0
            } catch { message = "No se pudo descargar: \(error.localizedDescription)" }
        }
    }
}

// MARK: - Apps de una fuente

struct SourceDetailView: View {
    let source: RepoSource
    @ObservedObject var ipas: FileStore
    @ObservedObject var incoming: Incoming
    @State private var apps: [RepoApp] = []
    @State private var loading = true
    @State private var query = ""
    @State private var downloading: Set<UUID> = []
    @State private var message: String?
    @State private var done: String?
    @State private var detail: RepoApp?
    @State private var sort = "default"

    private func infoLine(_ app: RepoApp) -> String {
        [app.version, app.size.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) }]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · ")
    }

    private func dateText(_ app: RepoApp) -> String? {
        if let d = app.date { return d.formatted(date: .abbreviated, time: .omitted) }
        return app.dateRaw.isEmpty ? nil : app.dateRaw
    }

    private var shown: [RepoApp] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        return q.isEmpty ? apps : apps.filter { $0.name.lowercased().contains(q) || $0.bundleID.lowercased().contains(q) }
    }

    private var sorted: [RepoApp] {
        switch sort {
        case "name": return shown.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case "date": return shown.sorted { ($0.date ?? .distantPast) > ($1.date ?? .distantPast) }
        default: return shown
        }
    }

    /// Para "Fecha": grupos por día, del más reciente al más antiguo.
    private var groups: [(title: String, apps: [RepoApp])] {
        var out: [(title: String, apps: [RepoApp])] = []
        for a in sorted {
            let t = a.date.map { $0.formatted(date: .long, time: .omitted) } ?? (a.dateRaw.isEmpty ? "Sin fecha" : a.dateRaw)
            if let i = out.firstIndex(where: { $0.title == t }) { out[i].apps.append(a) } else { out.append((t, [a])) }
        }
        return out
    }

    @ViewBuilder
    private func appRow(_ app: RepoApp) -> some View {
        HStack(spacing: 12) {
            HStack(spacing: 12) {
                AsyncImage(url: app.icon) { img in img.resizable().scaledToFill() }
                    placeholder: { Image(systemName: "app.fill").foregroundColor(.gold) }
                    .frame(width: 56, height: 56).background(Color.gold.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                VStack(alignment: .leading, spacing: 3) {
                    Text(app.name).font(.headline).lineLimit(2)
                    Text([app.version, app.detail].filter { !$0.isEmpty }.joined(separator: " · "))
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    HStack(spacing: 8) {
                        if let sz = app.size { Text(ByteCountFormatter.string(fromByteCount: sz, countStyle: .file)) }
                        if sort != "date", let d = dateText(app) { Text(d) }
                    }
                    .font(.caption2).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
            .onTapGesture { detail = app }
            if downloading.contains(app.id) { ProgressView() }
            else {
                Button("Obtener") { get(app) }
                    .buttonStyle(.borderedProminent).tint(.gold).foregroundColor(.black)
                    .font(.footnote.weight(.bold))
            }
        }
    }

    var body: some View {
        List {
            if loading { HStack { ProgressView(); Text("Cargando…").foregroundStyle(.secondary) } }
            if !loading && apps.isEmpty { Text("Esta fuente no tiene apps.").foregroundStyle(.secondary) }
            if sort == "date" {
                ForEach(groups, id: \.title) { g in
                    Section(g.title) { ForEach(g.apps) { appRow($0) } }
                }
            } else {
                ForEach(sorted) { appRow($0) }
            }
        }
        .scrollContentBackground(.hidden)
        .keyboardDone()
        .background(AppBackground())
        .navigationTitle(source.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Picker("Ordenar por", selection: $sort) {
                        Text("Predeterminado").tag("default")
                        Text("Nombre").tag("name")
                        Text("Fecha").tag("date")
                    }
                } label: { Image(systemName: "line.3.horizontal.decrease.circle") }
            }
        }
        .searchable(text: $query, prompt: "Buscar app")
        .task { await load() }
        .sheet(item: $detail) { app in
            RepoAppDetail(app: app, downloading: downloading.contains(app.id)) { get(app); detail = nil }
        }
        .alert("Fuente", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(message ?? "") }
        .alert("Descargada", isPresented: Binding(get: { done != nil }, set: { if !$0 { done = nil } })) {
            Button("Abrir Proyectos") { incoming.selectedTab = 0 }
            Button("Seguir aquí", role: .cancel) {}
        } message: { Text(done ?? "") }
    }

    private func load() async {
        loading = true
        defer { loading = false }
        guard let url = URL(string: source.url) else { return }
        do {
            let data = try await RepoParser.fetch(url)
            apps = RepoParser.parse(data)?.apps ?? []
        } catch { message = "No se pudo cargar la fuente: \(error.localizedDescription)" }
    }

    private func get(_ app: RepoApp) {
        downloading.insert(app.id)
        Task {
            defer { downloading.remove(app.id) }
            do {
                try await Downloader.download(app.download, name: app.name, version: app.version, into: ipas)
                done = "\(app.name) ya está en Proyectos, lista para firmar."
            } catch { message = "No se pudo descargar \(app.name): \(error.localizedDescription)" }
        }
    }
}


// MARK: - Ficha de una app de la fuente

struct RepoAppDetail: View {
    let app: RepoApp
    let downloading: Bool
    let onGet: () -> Void
    @Environment(\.dismiss) private var dismiss

    private func fmt(_ d: Date?, _ raw: String) -> String? {
        if let d { return d.formatted(date: .long, time: .shortened) }
        return raw.isEmpty ? nil : raw
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 14) {
                        AsyncImage(url: app.icon) { img in img.resizable().scaledToFill() }
                            placeholder: { Image(systemName: "app.fill").foregroundColor(.gold) }
                            .frame(width: 72, height: 72).background(Color.gold.opacity(0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text(app.name).font(.title3.weight(.bold))
                            if !app.developer.isEmpty { Text(app.developer).font(.subheadline).foregroundStyle(.secondary) }
                            if !app.detail.isEmpty { Text(app.detail).font(.caption).foregroundStyle(.secondary).lineLimit(2) }
                        }
                        Spacer(minLength: 0)
                    }
                    Button { onGet() } label: { Text(downloading ? "Descargando…" : "Obtener").frame(maxWidth: .infinity) }
                        .buttonStyle(.borderedProminent).tint(.gold).foregroundColor(.black).disabled(downloading)
                }
                Section("Información") {
                    row("Versión", app.version)
                    row("Subida", fmt(app.date, app.dateRaw))
                    row("Tamaño", app.size.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) })
                    row("Bundle ID", app.bundleID)
                    row("iOS mínimo", app.minOS)
                    row("Desarrollador", app.developer)
                }
                if !app.whatsNew.isEmpty {
                    Section("Novedades") { Text(app.whatsNew).font(.callout) }
                }
                if !app.about.isEmpty {
                    Section("Descripción") { Text(app.about).font(.callout) }
                }
                if !app.screenshots.isEmpty {
                    Section("Capturas") {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(app.screenshots, id: \.self) { u in
                                    AsyncImage(url: u) { img in img.resizable().scaledToFit() } placeholder: { ProgressView() }
                                        .frame(height: 320).clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                        }
                    }
                }
                if app.history.count > 1 {
                    Section("Versiones anteriores") {
                        ForEach(app.history) { v in
                            VStack(alignment: .leading, spacing: 2) {
                                Text([v.version, v.size.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) }]
                                        .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · ")).font(.subheadline.weight(.semibold))
                                if let d = fmt(v.date, v.dateRaw) { Text(d).font(.caption).foregroundStyle(.secondary) }
                                if !v.notes.isEmpty { Text(v.notes).font(.caption2).foregroundStyle(.secondary).lineLimit(3) }
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("Detalles")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Cerrar") { dismiss() } } }
        }
    }

    @ViewBuilder
    private func row(_ title: String, _ value: String?) -> some View {
        if let value, !value.isEmpty {
            HStack { Text(title); Spacer(); Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing).textSelection(.enabled) }
        }
    }
}
