import Foundation

/// Inyecta un LC_LOAD_DYLIB en un binario Mach-O de 64 bits (delgado o fat).
/// Usa el espacio libre que hay tras los load commands; no cambia el tamaño del archivo.
enum MachOInjector {
    struct Failure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    private enum SliceResult { case injected, present, skipped }

    static func inject(loadPath: String, into url: URL) throws {
        var data = try Data(contentsOf: url)
        var done = 0

        if data.count > 8, data.u32(0, bigEndian: true) == 0xCAFEBABE {
            let count = Int(data.u32(4, bigEndian: true))
            for i in 0..<count {
                let entry = 8 + i * 20
                let offset = Int(data.u32(entry + 8, bigEndian: true))
                if try injectSlice(&data, at: offset, loadPath: loadPath) != .skipped { done += 1 }
            }
        } else if try injectSlice(&data, at: 0, loadPath: loadPath) != .skipped {
            done += 1
        }

        guard done > 0 else { throw Failure(message: "El binario no es Mach-O de 64 bits.") }
        // Escritura directa (no atómica) para conservar los permisos de ejecución.
        try data.write(to: url)
    }

    private static func injectSlice(_ data: inout Data, at base: Int, loadPath: String) throws -> SliceResult {
        guard base + 32 <= data.count, data.u32(base) == 0xFEEDFACF else { return .skipped }

        let ncmds = Int(data.u32(base + 16))
        let sizeofcmds = Int(data.u32(base + 20))
        var off = base + 32
        var firstSection = Int.max

        for _ in 0..<ncmds {
            guard off + 8 <= data.count else { break }
            let cmd = data.u32(off)
            let size = Int(data.u32(off + 4))
            guard size >= 8 else { break }

            if cmd == 0xC || cmd == 0x8000_0018 { // LOAD_DYLIB / LOAD_WEAK_DYLIB
                let nameOff = Int(data.u32(off + 8))
                if nameOff < size {
                    let bytes = data[(off + nameOff)..<(off + size)].prefix { $0 != 0 }
                    if String(decoding: bytes, as: UTF8.self) == loadPath { return .present }
                }
            }
            if cmd == 0x19 { // LC_SEGMENT_64
                let nsects = Int(data.u32(off + 64))
                var s = off + 72
                for _ in 0..<nsects {
                    let secOffset = Int(data.u32(s + 48))
                    if secOffset > 0 { firstSection = min(firstSection, secOffset) }
                    s += 80
                }
            }
            off += size
        }

        let path = Array(loadPath.utf8) + [0]
        let cmdSize = (24 + path.count + 7) & ~7
        let end = 32 + sizeofcmds
        guard firstSection != Int.max, firstSection - end >= cmdSize else {
            throw Failure(message: "No hay espacio libre en el binario para inyectar el tweak.")
        }

        var cmd = Data(count: cmdSize)
        cmd.put32(0xC, at: 0)               // LC_LOAD_DYLIB
        cmd.put32(UInt32(cmdSize), at: 4)
        cmd.put32(24, at: 8)                // offset del nombre
        cmd.put32(2, at: 12)                // timestamp
        cmd.put32(0x0001_0000, at: 16)      // current_version
        cmd.put32(0x0001_0000, at: 20)      // compatibility_version
        cmd.replaceSubrange(24..<(24 + path.count), with: path)

        data.replaceSubrange((base + end)..<(base + end + cmdSize), with: cmd)
        data.put32(UInt32(ncmds + 1), at: base + 16)
        data.put32(UInt32(sizeofcmds + cmdSize), at: base + 20)
        return .injected
    }

    // MARK: Listar / quitar librerías

    /// Rutas de librerías incluidas en la app (las del sistema se omiten).
    static func dylibs(in data: Data) -> [String] {
        var out: [String] = []
        func slice(_ base: Int) {
            guard base + 32 <= data.count, data.u32(base) == 0xFEEDFACF else { return }
            let ncmds = Int(data.u32(base + 16))
            var off = base + 32
            for _ in 0..<ncmds {
                guard off + 12 <= data.count else { break }
                let cmd = data.u32(off), size = Int(data.u32(off + 4))
                guard size >= 8 else { break }
                if cmd == 0xC || cmd == 0x8000_0018 {
                    let nameOff = Int(data.u32(off + 8))
                    if nameOff < size, off + size <= data.count {
                        let bytes = data[(off + nameOff)..<(off + size)].prefix { $0 != 0 }
                        let name = String(decoding: bytes, as: UTF8.self)
                        if name.hasPrefix("@") && !out.contains(name) { out.append(name) }
                    }
                }
                off += size
            }
        }
        if data.count > 8, data.u32(0, bigEndian: true) == 0xCAFEBABE {
            let count = Int(data.u32(4, bigEndian: true))
            for i in 0..<count {
                let offset = Int(data.u32(8 + i * 20 + 8, bigEndian: true))
                slice(offset)
                if !out.isEmpty { break }
            }
        } else { slice(0) }
        return out
    }

    /// Elimina los load commands de las librerías indicadas.
    static func remove(names: Set<String>, from url: URL) throws {
        var data = try Data(contentsOf: url)
        func slice(_ base: Int) {
            guard base + 32 <= data.count, data.u32(base) == 0xFEEDFACF else { return }
            let ncmds = Int(data.u32(base + 16))
            let total = Int(data.u32(base + 20))
            var off = base + 32
            var kept = Data()
            var removed = 0
            var newCount = 0
            for _ in 0..<ncmds {
                let cmd = data.u32(off), size = Int(data.u32(off + 4))
                var drop = false
                if cmd == 0xC || cmd == 0x8000_0018 {
                    let nameOff = Int(data.u32(off + 8))
                    let bytes = data[(off + nameOff)..<(off + size)].prefix { $0 != 0 }
                    drop = names.contains(String(decoding: bytes, as: UTF8.self))
                }
                if drop { removed += 1 } else { kept.append(data.subdata(in: off..<(off + size))); newCount += 1 }
                off += size
            }
            guard removed > 0 else { return }
            let start = base + 32
            data.replaceSubrange(start..<(start + kept.count), with: kept)
            data.replaceSubrange((start + kept.count)..<(start + total), with: Data(count: total - kept.count))
            data.put32(UInt32(newCount), at: base + 16)
            data.put32(UInt32(kept.count), at: base + 20)
        }
        if data.count > 8, data.u32(0, bigEndian: true) == 0xCAFEBABE {
            let count = Int(data.u32(4, bigEndian: true))
            for i in 0..<count { slice(Int(data.u32(8 + i * 20 + 8, bigEndian: true))) }
        } else { slice(0) }
        try data.write(to: url)
    }

    /// Reescribe rutas de LC_LOAD_DYLIB en el sitio (si la nueva cabe). Devuelve (cambiadas, no caben).
    static func rewriteDependencies(in url: URL, map: (String) -> String?) throws -> (Int, Int) {
        var data = try Data(contentsOf: url)
        var changed = 0, skipped = 0
        func slice(_ base: Int) {
            guard base + 32 <= data.count, data.u32(base) == 0xFEEDFACF else { return }
            let ncmds = Int(data.u32(base + 16))
            var off = base + 32
            for _ in 0..<ncmds {
                guard off + 12 <= data.count else { break }
                let cmd = data.u32(off), size = Int(data.u32(off + 4))
                guard size >= 8 else { break }
                if cmd == 0xC || cmd == 0x8000_0018 {
                    let nameOff = Int(data.u32(off + 8))
                    if nameOff < size, off + size <= data.count {
                        let bytes = data[(off + nameOff)..<(off + size)].prefix { $0 != 0 }
                        let old = String(decoding: bytes, as: UTF8.self)
                        if let new = map(old) {
                            let nb = Array(new.utf8) + [0]
                            if nb.count <= size - nameOff {
                                var field = Data(nb)
                                field.append(Data(count: size - nameOff - nb.count))
                                data.replaceSubrange((off + nameOff)..<(off + size), with: field)
                                changed += 1
                            } else { skipped += 1 }
                        }
                    }
                }
                off += size
            }
        }
        if data.count > 8, data.u32(0, bigEndian: true) == 0xCAFEBABE {
            let count = Int(data.u32(4, bigEndian: true))
            for i in 0..<count { slice(Int(data.u32(8 + i * 20 + 8, bigEndian: true))) }
        } else { slice(0) }
        if changed > 0 { try data.write(to: url) }
        return (changed, skipped)
    }
}
